<?php
   $link= $_SERVER['PHP_SELF'];

switch ($link) {
  case "/parcel.php":
?>
<?php ob_start();
$title = "সকল পার্সেল";
 include 'menu.php';?>
<script>
  window.onload=function(){
        document.getElementById('loder').style.display="none";
        document.getElementById('content').style.display="block";
  };
</script>
<style>
  #content {display: none;}
  #content img{width: 100%;}
  #loder{
    position: absolute;
    margin: auto;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    width: 300px;
    height: 300px;
  }
  #loder img{width: 300px;}
</style>
<div id="loder">
<img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
</div>

<?php
include 'config.php';
if (isset($_REQUEST['delete_m_data'])) {
  $c_heros = $_REQUEST['c_heros'];
  $c_actions = $_REQUEST['c_actions'];
  $check_data = $_REQUEST['check_data'];
  $all_marked = implode(",",$check_data);

  $query = "UPDATE parcel SET
   c_action = '$c_actions',
   c_hero = '$c_heros'
   WHERE parcel_id in ($all_marked);";

   if ($c_actions == 5) {
     $query .= "UPDATE parcel SET
       p_Pay ='1'
        WHERE parcel_id in ($all_marked);";
   }else {
     $query .= "UPDATE parcel SET
       p_Pay ='0'
       WHERE parcel_id in ($all_marked);";
   }

     $ALLDATAS = $_REQUEST['check_data'];
     if ($ALLDATAS) {
       foreach ($ALLDATAS as $c) {
         $query .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('".mysqli_real_escape_string($connection,$c)."','$c_actions','{$_SESSION["name"]}','$c_heros');";
       }


  $result = mysqli_multi_query($connection,$query) or die("Query Faield.");

   }
     }

   ?>
<main id="content">
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                       <div class="container-fluid">
                           <div class="page-header-content">
                               <div class="row align-items-center justify-content-between pt-3">
                                   <div class="col-auto mb-3">
                                   </div>
<?php include 'submenu.php';?>
                               </div>
                           </div>
                       </div>
                   </header>
                   <!-- Main page content-->
   <!-- Main page content-->
                 <form class="" action="" method="post">
   <div class="container">
      <div class="card mb-4">
         <div class="card-header">


            <!-- Multi Select -->
            <div class="row">
               <div class="col-xl-5">
                 <a title="নতুন একটি পার্সেল এড করুন" href="addParcel.php" class="btn btn-outline-primary btn-icon">
                 <i class="fas fa-plus-circle"></i>
                 </a>


                 <a title="নতুন বাল্ক ফাইল আপলোড করুন" href="addParcelcsv.php" class="btn btn-outline-primary btn-icon">
                 <i class="fas fa-file-csv"></i>
                 </a>
                 </div>
               <div class="col-xl-5">
                 <div class="row">
                    <div class="col-xl-6">
                      <?php if ($_SESSION['role'] =='5') {?>
            <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
                <option selected value="">একটি স্টাটাস বাছুন</option>
                <?php
                       include 'config.php';
                       $query_s = "SELECT * FROM action";
                       $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                       if (mysqli_num_rows($result_s) > 0) {
                         while ($row_S = mysqli_fetch_assoc($result_s)) {

                           if ($row['c_action'] == $row_S['action_id']) {
                             $selected = "selected";
                           }else {
                             $selected = "";
                           }

                           echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                         }
                       }
                        ?>
            </select>
            </div>
            <div class="col-xl-6">
              <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
                  <option selected value="">একজন হিরো বাছুন</option>
                  <?php
                         include 'config.php';
                         $query_h = "SELECT * FROM hero";
                         $result_h = mysqli_query($connection,$query_h)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                         if (mysqli_num_rows($result_h) > 0) {
                           while ($row_h = mysqli_fetch_assoc($result_h)) {

                             if ($row['c_hero'] == "2") {
                               $selected = "selected";
                             }else {
                               $selected = "";
                             }

                             echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                           }
                         }
                          ?>
              </select>

            </div>
            </div>
            </div>
            <div class="col-xl-2">
              <input required class="btn btn-primary" type="submit" name="delete_m_data" value="পরিবর্তন">

              <?php
              include 'config.php';
              if (isset($_REQUEST['Paysubmit'])) {
                $check_datap = $_REQUEST['check_data'];
                $all_markedp = implode(",",$check_datap);
                $queryp = "UPDATE parcel SET
                 p_Pay ='2'
                 WHERE parcel_id in ($all_markedp)";

                $resultp = mysqli_query($connection,$queryp) or die("Query Faield.");
                 }
               ?>
              <form class="" action="" method="post">
               <input class="btn btn-outline-black btn-icon" type="submit" name="Paysubmit" value="&#2547;">
              </form>
<?php } ?>
            </div>
            </div>
            <!-- Multi Select -->
         </div>

         <div class="card-body">
            <div class="datatable">




               <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

<?php
                     include 'config.php';
                     // Pagination
                     $limit = 300;
                     if (isset($_GET['page'])) {
                       $page = $_GET['page'];
                     }else {
                       $page = 1;
                     }

                     $offset = ($page - 1) * $limit;
                     // Pagination
                     if ($_SESSION['role']== '5') {
                     $query = "SELECT * FROM parcel
                     LEFT JOIN services ON parcel.c_service = services.id
                     LEFT JOIN area ON parcel.c_area = area.id
                     LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                     LEFT JOIN action ON parcel.c_action = action.action_id
                     LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                     LEFT JOIN pay ON parcel.p_Pay = pay.payID
                     ORDER BY parcel.parcel_id  DESC LIMIT {$offset},{$limit}";
                     }elseif ($_SESSION['role']== '1') {
                     $query = "SELECT * FROM parcel
                     LEFT JOIN services ON parcel.c_service = services.id
                     LEFT JOIN area ON parcel.c_area = area.id
                     LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                     LEFT JOIN action ON parcel.c_action = action.action_id
                     LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                     WHERE parcel.c_m_business = {$_SESSION['id']}
                     ORDER BY parcel.parcel_id DESC LIMIT {$offset},{$limit}";
                     }else {
                     ?>
                  <div class="container p-5">
                     <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                     </div>
                     <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                        <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                        <hr>
                        <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                     </div>
                  </div>
                  <?php
                     die;
                     }
                    ?>
                    <?php
                    $result = mysqli_query($connection,$query) or die("Query Faield.");
                    $count = mysqli_num_rows($result);
                    ?>
                    <tfoot>


                    <tr>
                      <?php if ($_SESSION['role'] =='5') {?>
                       <th><i class="fas fa-clipboard-check"></i></th>
                     <?php } ?>
                       <th>আইডি</th>
                       <th>প্রেরক</th>
                       <th>প্রাপক</th>
                       <th>নোট</th>
                       <th>স্টাটাস</th>
                       <th>অ্যাকশান</th>
                    </tr>
                    </tfoot>
                    <tfoot>
                    <tr>
                      <?php if ($_SESSION['role'] =='5') {?>
                       <th><i class="fas fa-clipboard-check"></i></th>
                     <?php } ?>
                       <th>আইডি</th>
                       <th>প্রেরক</th>
                       <th>প্রাপক</th>
                       <th>নোট</th>
                       <th>স্টাটাস</th>
                       <th>অ্যাকশান</th>
                    </tr>
                    </tfoot>
                    <tbody>
                    <?php
                       if ($count>0) {
                       while ($row = mysqli_fetch_assoc($result)) {
                         ?>
                    <tr>
                      <?php if ($_SESSION['role'] =='5') {?>
                       <td class="th-sm">
                         <input  type="hidden" name="businesss" value="<?php echo $row['business']; ?>">
                         <input type="hidden" name="c_prices" value="<?php echo $row['c_price']; ?>">
                         <input type="hidden" name="c_names" value="<?php echo $row['c_name']; ?>">
                         <label class="checkbox path">
                                <input type="checkbox" name="check_data[]"  value="<?php echo $row['parcel_id']; ?>">
                                <svg viewBox="0 0 21 21">
                                    <path d="M5,10.75 L8.5,14.25 L19.4,2.3 C18.8333333,1.43333333 18.0333333,1 17,1 L4,1 C2.35,1 1,2.35 1,4 L1,17 C1,18.65 2.35,20 4,20 L17,20 C18.65,20 20,18.65 20,17 L20,7.99769186"></path>
                                </svg>
                            </label>
                       </td>
                     <?php } ?>
                       <td class="th-sm">
                    <?php
                    if ($row['trId']=="") {
                      echo "<span class='text-green'>PEON786592". $row['parcel_id']."</span><br>";
                    }else {
                      echo "<span class='text-green'>". $row['trId']."</span><br>";
                    }
                     ?>



                          M.Inv:<?php echo $row['c_Inv']; ?><br>
                          <?php echo $row['Ptime']; ?> <br>
                          <?php echo $row['Pdate']; ?>

                       </td>
                       <td class="th-sm cb">
                         <span class="font-weight-bolder"><?php echo $row['business']; ?></span><br>
                          <?php echo $row['number']; ?>  <br>
                          <?php echo $row['address']; ?>
                          <div class="row ">
                             <div class="col-md-12">
                                <div class="row">
                                   <div class="col-md-6">
                                      <span class="text-green font-weight-900"> ওজন: <?php echo $row['weight']; ?> কেজি</span>
                                   </div>
                                   <div class="col-md-6">
                                      <span class="text-green font-weight-900">
                                         চার্জ:  <?php

                                       echo $row['c_charge'];

                                          ?> &#2547;

                                       </span>
                                   </div>
                                </div>
                             </div>
                          </div>
                          <div class="row ">
                             <div class="col-md-12">
                                <div class="row">
                                   <div class="col-md-6">
                                      <span class="text-green font-weight-900"> COD: <?php echo $row['c_price']; ?>&#2547;</span>
                                   </div>
                                   <div class="col-md-6">
                                      <span class="text-green font-weight-900">
                                        Payable:  <?php echo $payble =  $row['c_price'] - $row['c_charge']; ?> &#2547;

                                       </span>
                                   </div>
                                </div>
                             </div>
                          </div>
                       </td>
                       <td class="th-sm cb">
                          <?php echo $row['c_name'];?> <br>
                          <?php echo $row['c_number']; ?>,  <?php echo $row['c_b_number']; ?>  <br>
                          <?php echo $row['c_address']; ?>

                          <div class="row ">
                             <div class="col-md-12">
                                <div class="row">
                                   <div class="col-md-12">
                                      <span class="text-green"> এরিয়া: <?php echo $row['area_name']; ?></span>
                                   </div>
                                </div>
                             </div>
                          </div>

                       </td>
                       <td class="th-sm cbNote">
                       <?php echo $row['note'];?>
                       </td>
                       <td>
                          <?php
                             if ($row['c_action']==1) {
                                 echo "<div class='badge badge-danger badge-pill'><i class='fas fa-spinner'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                             }
                             else if($row['c_action']==2){
                                 echo "<div class='badge badge-primary badge-pill'><i class='fas fa-biking'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                             }
                             else if($row['c_action']==3){
                                 echo "<div class='badge badge-primary badge-pill'><i class='fas fa-warehouse'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                             }
                             else if($row['c_action']==4){
                                 echo "<div class='badge badge-primary badge-pill'><i class='fas fa-shipping-fast'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                             }
                             else if($row['c_action']==5){
                                 echo "<div class='badge badge-green badge-pill'><i class='fa fa-check-circle'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                             }
                             else if($row['c_action']==6){
                                 echo "<div class='badge badge-dark badge-pill'><i class='fas fa-history'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                             }
                             else if($row['c_action']==7){
                                 echo "<div class='badge badge-primary badge-pill'><i class='fas fa-exchange-alt'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                             }
                             else if($row['c_action']==8){
                                 echo "<div class='badge badge-dark badge-pill'><i class='fas fa-file-import'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                             }
                             else {
                               echo "<div class='badge badge-warning badge-pill'><i class='fas fa-window-close'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                             }
                             ?>
                          <br>
                          <?php
                             if ($row['p_Pay']==1) {
                                 echo "<div class='badge badge-blue badge-pill'><i class='far fa-hourglass'></i>&nbsp;&nbsp;".$row['payName']."</div><br>";
                             }
                             else if($row['p_Pay']==2){
                                 echo "<div class='badge badge-green badge-pill'><i class='fas fa-hourglass'></i>&nbsp;&nbsp;".$row['payName']."</div> <br>";
                             }
                             else {

                             }
                             ?>
                          <?php
                             if ($row['c_service']==1) {
                                 echo "<div class='badge badge-orange badge-pill'>".$row['sName']."</div>";
                             }
                             else if($row['c_service']==2){
                                 echo "<div class='badge badge-primary badge-pill'>".$row['sName']."</div>";
                             }
                             else {
                               echo "<div class='badge badge-warning badge-pill'>".$row['sName']."</div>";
                             }
                             ?>

                             <?php if ($_SESSION['role'] =='5') {?>
                             <br>
                             <div class="bg-light rounded mt-2"><?php echo $row['hero_name'];?></div>
                           <?php } ?>
                       </td>
                       <td>
                            <?php if ($_SESSION['role'] =='5') {?>
                    <button data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="dropdownFadeInUp<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm">
                    <i data-feather="more-vertical"></i>
                    </button>
                    <?php } ?>
                    <div class="dropdown-menu animated--fade-in-up" aria-labelledby="dropdownFadeInUp<?php echo $row['parcel_id'];?>">
                    <!-- Delete Dropdown Button -->
                    <a data-toggle="modal" data-target="#exampleModalSm<?php echo $row['parcel_id']; ?>" class="dropdown-item text-danger" >ডিলিট</a>

                    <!-- Delete Dropdown Button -->
                          </div>
                          <!-- Small modal -->
                          <div class="modal fade" id="exampleModalSm<?php echo $row['parcel_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                             <div class="modal-dialog modal-sm" role="document">
                                <div class="modal-content">
                                   <div class="modal-header">
                                      <h5 class="modal-title">গুরুত্বপূর্ণ ব্যাপার</h5>
                                      <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                   </div>
                                   <div class="modal-body">
                                      <p>আপনি কি <?php
                                      if ($row['trId']=="") {
                                        echo "PEON786592". $row['parcel_id'];
                                      }else {
                                        echo  $row['trId'];
                                      }
                                       ?> পার্সেল ডিলিট করতে চাচ্ছেন?</p>
                                   </div>
                                   <div class="modal-footer">
                                      <button class="btn btn-primary" type="button" data-dismiss="modal">না! থাক</button>
                    <a class="btn btn-danger" type="button" href="delete_parcel.php?MasRiaKib=<?php echo $row['parcel_id']; ?>">ডিলিট</a>
                                   </div>
                                </div>
                             </div>
                          </div>

                          <a href="viewParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="fas fa-eye"></i></a>
                             <?php if ($_SESSION['role'] =='5') {?>
                          <a target="_blank" href="updateParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="far fa-edit"></i></a>
                        <?php } ?>
                          <a class="btn btn-outline-primary btn-icon btn-sm" target="_blank" href="print_parcel.php?id=<?php echo $row['parcel_id']; ?>"><i class="fas fa-print"></i></a>
                       </td>
                    </tr>
                    <?php } ?>
                    </tbody>
                    <?php } ?>
                    </table>

                    </form>
                    <!-- pagination -->
                    <?php
                    include 'config.php';
                    if ($_SESSION['role']== '5') {
                    $queryPagi = "SELECT * FROM parcel";
                  }elseif ($_SESSION['role']== '1') {
                    $queryPagi = "SELECT * FROM parcel
                    WHERE parcel.c_m_business = {$_SESSION['id']}";
                  }
                    $ResultPagi = mysqli_query($connection,$queryPagi) or die("Pagination Err");
                    if (mysqli_num_rows($ResultPagi)) {
                      $total_records = mysqli_num_rows($ResultPagi);
                      $totalPage = ceil($total_records/$limit);
                      echo "<nav aria-label='Page navigation example mt-5'>
                        <ul class='pagination justify-content-center'>";
                          if ($page > 1) {
                            echo "<li class='page-item'><a class='page-link' href='{$_SERVER['PHP_SELF']}?page=".($page-1)."' tabindex='-1' aria-disabled='true'>আাগে</a>
                            </li>";
                          }else {
                            echo "<li class='page-item disabled'><a class='page-link' href='{$_SERVER['PHP_SELF']}?page=".($page-1)."' tabindex='-1' aria-disabled='true'>আাগে</a>
                            </li>";
                          }


                      for ($i= 1; $i <= $totalPage; $i++) {
                        if ($i == $page) {
                          $active = "active";
                        }else {
                          $active = "";
                        }

                        echo "<li class='page-item ".$active."'><a class='page-link' href='{$_SERVER['PHP_SELF']}?page=".$i."'>".$i."</a></li>";


                      }
                      if ($totalPage > $page) {
                        echo "
                        <li class='page-item '>
                         <a class='page-link' href='{$_SERVER['PHP_SELF']}?page=".($page+1)."'>পরে</a>
                            </li>";
                      }else {
                        echo "
                        <li class='page-item disabled'>
                         <a class='page-link' href=''>পরে</a>
                            </li>";
                      }


                          echo "</ul>
                      </nav>";
                    }


                    ?>





                    <!-- pagination -->
                    </div>
                    </div>
                    </div>
                    </div>
                    </main>


<?php
    break;
  case "/AllPending.php":
    ?><?php ob_start(); ?>
    <?php $title = "নতুন অর্ডার পার্সেল"; ?>
    <?php include 'menu.php';?>
    <script>
      window.onload=function(){
            document.getElementById('loder').style.display="none";
            document.getElementById('content').style.display="block";
      };
    </script>
    <style>
      #content {display: none;}
      #content img{width: 100%;}
      #loder{
        position: absolute;
        margin: auto;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        width: 300px;
        height: 300px;
      }
      #loder img{width: 300px;}
    </style>
    <div id="loder">
    <img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
    </div>

    <?php
    include 'config.php';
    if (isset($_REQUEST['delete_m_data'])) {
      $c_heros = $_REQUEST['c_heros'];
      $c_actions = $_REQUEST['c_actions'];
      $check_data = $_REQUEST['check_data'];
      $all_marked = implode(",",$check_data);

      $query = "UPDATE parcel SET
       c_action = '$c_actions',
       c_hero = '$c_heros'
       WHERE parcel_id in ($all_marked);";

       if ($c_actions == 5) {
         $query .= "UPDATE parcel SET
           p_Pay ='1'
            WHERE parcel_id in ($all_marked);";
       }else {
         $query .= "UPDATE parcel SET
           p_Pay ='0'
           WHERE parcel_id in ($all_marked);";
       }

         $ALLDATAS = $_REQUEST['check_data'];
         if ($ALLDATAS) {
           foreach ($ALLDATAS as $c) {
             $query .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('".mysqli_real_escape_string($connection,$c)."','$c_actions','{$_SESSION["name"]}','$c_heros');";
           }


      $result = mysqli_multi_query($connection,$query) or die("Query Faield.");
       }
       }

       ?>
    <main id="content">
       <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                           <div class="container-fluid">
                               <div class="page-header-content">
                                   <div class="row align-items-center justify-content-between pt-3">
                                       <div class="col-auto mb-3">
                                       </div>
    <?php include 'submenu.php';?>
                                   </div>
                               </div>
                           </div>
                       </header>
                       <!-- Main page content-->
       <!-- Main page content-->
                     <form class="" action="" method="post">
       <div class="container">
          <div class="card mb-4">
             <div class="card-header">


                <!-- Multi Select -->
                <div class="row">
                   <div class="col-xl-5">
                     <a title="নতুন একটি পার্সেল এড করুন" href="addParcel.php" class="btn btn-outline-primary btn-icon">
                     <i class="fas fa-plus-circle"></i>
                     </a>


                     <a title="নতুন বাল্ক ফাইল আপলোড করুন" href="addParcelcsv.php" class="btn btn-outline-primary btn-icon">
                     <i class="fas fa-file-csv"></i>
                     </a>
                     <a title="বাল্ক ফাইল ডাউনলোড করুন" href="X2!dswsDsfb.php?idDFsdfgxcgvbdgrgdxfbdtgbrtxb=1" class="btn btn-outline-dark btn-icon">
                     <i class="fas fa-arrow-circle-down"></i>
                     </a>
                     </div>
                   <div class="col-xl-5">
                     <div class="row">
                        <div class="col-xl-6">
                          <?php if ($_SESSION['role'] =='5') {?>
                <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
                    <option selected value="">একটি স্টাটাস বাছুন</option>
                    <?php
                           include 'config.php';
                           $query_s = "SELECT * FROM action";
                           $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                           if (mysqli_num_rows($result_s) > 0) {
                             while ($row_S = mysqli_fetch_assoc($result_s)) {

                               if ($row['c_action'] == $row_S['action_id']) {
                                 $selected = "selected";
                               }else {
                                 $selected = "";
                               }

                               echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                             }
                           }
                            ?>
                </select>
                </div>
                <div class="col-xl-6">
                  <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
                      <option selected value="">একজন হিরো বাছুন</option>
                      <?php
                             include 'config.php';
                             $query_h = "SELECT * FROM hero";
                             $result_h = mysqli_query($connection,$query_h)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                             if (mysqli_num_rows($result_h) > 0) {
                               while ($row_h = mysqli_fetch_assoc($result_h)) {

                                 if ($row['c_hero'] == "2") {
                                   $selected = "selected";
                                 }else {
                                   $selected = "";
                                 }

                                 echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                               }
                             }
                              ?>
                  </select>

                </div>
                </div>
                </div>
                <div class="col-xl-2">
                  <input required class="btn btn-primary" type="submit" name="delete_m_data" value="পরিবর্তন">

                  <?php
                  include 'config.php';
                  if (isset($_REQUEST['Paysubmit'])) {
                    $check_datap = $_REQUEST['check_data'];
                    $all_markedp = implode(",",$check_datap);
                    $queryp = "UPDATE parcel SET
                     p_Pay ='2'
                     WHERE parcel_id in ($all_markedp)";

                    $resultp = mysqli_query($connection,$queryp) or die("Query Faield.");
                     }
                   ?>
                  <form class="" action="" method="post">
                   <input class="btn btn-outline-black btn-icon" type="submit" name="Paysubmit" value="&#2547;">
                  </form>




    <?php } ?>
                </div>
                </div>
                <!-- Multi Select -->
             </div>

             <div class="card-body">
                <div class="datatable">






                   <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

    <?php
                         include 'config.php';

                         if ($_SESSION['role']== '5') {
                         $query = "SELECT * FROM parcel
                         LEFT JOIN services ON parcel.c_service = services.id
                         LEFT JOIN area ON parcel.c_area = area.id
                         LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                         LEFT JOIN action ON parcel.c_action = action.action_id
                         LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                         LEFT JOIN pay ON parcel.p_Pay = pay.payID
                         WHERE action.action_id = 1
                         ORDER BY parcel.parcel_id  DESC";
                         }elseif ($_SESSION['role']== '1') {
                         $query = "SELECT * FROM parcel
                         LEFT JOIN services ON parcel.c_service = services.id
                         LEFT JOIN area ON parcel.c_area = area.id
                         LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                         LEFT JOIN action ON parcel.c_action = action.action_id
                         LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                         WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 1
                         ORDER BY parcel.parcel_id DESC";
                         }else {
                         ?>
                      <div class="container p-5">
                         <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                            </button>
                         </div>
                         <div class="alert alert-success" role="alert">
                            <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                            <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                            <hr>
                            <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                         </div>
                      </div>
                      <?php
                         die;
                         }
                        ?>
                        <?php
                        $result = mysqli_query($connection,$query) or die("Query Faield.");
                        $count = mysqli_num_rows($result);
                        ?>
                        <thead>


                        <tr>
                          <?php if ($_SESSION['role'] =='5') {?>
                           <th><i class="fas fa-clipboard-check"></i></th>
                         <?php } ?>
                           <th>আইডি</th>
                           <th>প্রেরক</th>
                           <th>প্রাপক</th>
                           <th>নোট</th>
                           <th>স্টাটাস</th>
                           <th>অ্যাকশান</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                          <?php if ($_SESSION['role'] =='5') {?>
                           <th><i class="fas fa-clipboard-check"></i></th>
                         <?php } ?>
                           <th>আইডি</th>
                           <th>প্রেরক</th>
                           <th>প্রাপক</th>
                           <th>নোট</th>
                           <th>স্টাটাস</th>
                           <th>অ্যাকশান</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        <?php
                           if ($count>0) {
                           while ($row = mysqli_fetch_assoc($result)) {
                             ?>
                        <tr>
                          <?php if ($_SESSION['role'] =='5') {?>
                           <td class="th-sm">
                             <input  type="hidden" name="businesss[]" value="<?php echo $row['business']; ?>">
                             <input  type="hidden" name="c_number[]" value="<?php echo $row['c_number']; ?>">
                             <input type="hidden" name="c_prices[]" value="<?php echo $row['c_price']; ?>">
                             <input type="hidden" name="c_names[]" value="<?php echo $row['c_name']; ?>">
                             <label class="checkbox path">
                                    <input type="checkbox" name="check_data[]"  value="<?php echo $row['parcel_id']; ?>">
                                    <svg viewBox="0 0 21 21">
                                        <path d="M5,10.75 L8.5,14.25 L19.4,2.3 C18.8333333,1.43333333 18.0333333,1 17,1 L4,1 C2.35,1 1,2.35 1,4 L1,17 C1,18.65 2.35,20 4,20 L17,20 C18.65,20 20,18.65 20,17 L20,7.99769186"></path>
                                    </svg>
                                </label>
                           </td>
                         <?php } ?>
                           <td class="th-sm">
                        <?php
                        if ($row['trId']=="") {
                          echo "<span class='text-green'>PEON786592". $row['parcel_id']."</span><br>";
                        }else {
                          echo "<span class='text-green'>". $row['trId']."</span><br>";
                        }
                         ?>



                              M.Inv:<?php echo $row['c_Inv']; ?><br>
                              <?php echo $row['Ptime']; ?> <br>
                              <?php echo $row['Pdate']; ?>

                           </td>
                           <td class="th-sm cb">
                             <span class="font-weight-bolder"><?php echo $row['business']; ?></span><br>
                              <?php echo $row['number']; ?>  <br>
                              <?php echo $row['address']; ?>
                              <div class="row ">
                                 <div class="col-md-12">
                                    <div class="row">
                                       <div class="col-md-6">
                                          <span class="text-green font-weight-900"> ওজন: <?php echo $row['weight']; ?> কেজি</span>
                                       </div>
                                       <div class="col-md-6">
                                          <span class="text-green font-weight-900">
                                             চার্জ:  <?php

                                           echo $row['c_charge'];

                                              ?> &#2547;

                                           </span>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </td>
                           <td class="th-sm cb">
                              <?php echo $row['c_name'];?> <br>
                              <?php echo $row['c_number']; ?>,  <?php echo $row['c_b_number']; ?>  <br>
                              <?php echo $row['c_address']; ?>
                              <span class="text font-weight-900"> এরিয়া: <?php echo $row['area_name']; ?></span>
                              <div class="row ">
                                 <div class="col-md-12">
                                    <span class="text-green font-weight-900"> ক্যাশ কালেকশান: <?php echo $row['c_price']; ?> &#2547;</span>
                                 </div>
                              </div>
                           </td>
                           <td class="th-sm cbNote">
                           <?php echo $row['note'];?>
                           </td>
                           <td>
                              <?php
                                 if ($row['c_action']==1) {
                                     echo "<div class='badge badge-danger badge-pill'><i class='fas fa-spinner'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                                 }
                                 else if($row['c_action']==2){
                                     echo "<div class='badge badge-primary badge-pill'><i class='fas fa-biking'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                                 }
                                 else if($row['c_action']==3){
                                     echo "<div class='badge badge-primary badge-pill'><i class='fas fa-warehouse'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                                 }
                                 else if($row['c_action']==4){
                                     echo "<div class='badge badge-primary badge-pill'><i class='fas fa-shipping-fast'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                                 }
                                 else if($row['c_action']==5){
                                     echo "<div class='badge badge-green badge-pill'><i class='fa fa-check-circle'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                                 }
                                 else if($row['c_action']==6){
                                     echo "<div class='badge badge-dark badge-pill'><i class='fas fa-history'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                                 }
                                 else if($row['c_action']==7){
                                     echo "<div class='badge badge-primary badge-pill'><i class='fas fa-exchange-alt'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                                 }
                                 else if($row['c_action']==8){
                                     echo "<div class='badge badge-dark badge-pill'><i class='fas fa-file-import'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                                 }
                                 else {
                                   echo "<div class='badge badge-warning badge-pill'><i class='fas fa-window-close'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
                                 }
                                 ?>
                              <br>
                              <?php
                                 if ($row['p_Pay']==1) {
                                     echo "<div class='badge badge-blue badge-pill'><i class='far fa-hourglass'></i>&nbsp;&nbsp;".$row['payName']."</div><br>";
                                 }
                                 else if($row['p_Pay']==2){
                                     echo "<div class='badge badge-green badge-pill'><i class='fas fa-hourglass'></i>&nbsp;&nbsp;".$row['payName']."</div> <br>";
                                 }
                                 else {

                                 }
                                 ?>
                              <?php
                                 if ($row['c_service']==1) {
                                     echo "<div class='badge badge-orange badge-pill'>".$row['sName']."</div>";
                                 }
                                 else if($row['c_service']==2){
                                     echo "<div class='badge badge-primary badge-pill'>".$row['sName']."</div>";
                                 }
                                 else {
                                   echo "<div class='badge badge-warning badge-pill'>".$row['sName']."</div>";
                                 }
                                 ?>

                                 <?php if ($_SESSION['role'] =='5') {?>
                                 <br>
                                 <div class="bg-light rounded mt-2"><?php echo $row['hero_name'];?></div>
                               <?php } ?>
                           </td>
                           <td>
                                <?php if ($_SESSION['role'] =='5') {?>
                        <button href="view_merchant.php?id=<?php echo $row['id']; ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="dropdownFadeInUp<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm">
                        <i data-feather="more-vertical"></i>
                        </button>
                        <?php } ?>
                        <div class="dropdown-menu animated--fade-in-up" aria-labelledby="dropdownFadeInUp<?php echo $row['parcel_id'];?>">
                        <!-- Delete Dropdown Button -->
                        <a data-toggle="modal" data-target="#exampleModalSm<?php echo $row['parcel_id']; ?>" class="dropdown-item text-danger" >ডিলিট</a>

                        <!-- Delete Dropdown Button -->
                              </div>
                              <!-- Small modal -->
                              <div class="modal fade" id="exampleModalSm<?php echo $row['parcel_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                 <div class="modal-dialog modal-sm" role="document">
                                    <div class="modal-content">
                                       <div class="modal-header">
                                          <h5 class="modal-title">গুরুত্বপূর্ণ ব্যাপার</h5>
                                          <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                       </div>
                                       <div class="modal-body">
                                          <p>আপনি কি <?php
                                          if ($row['trId']=="") {
                                            echo "PEON786592". $row['parcel_id'];
                                          }else {
                                            echo  $row['trId'];
                                          }
                                           ?> পার্সেল ডিলিট করতে চাচ্ছেন?</p>
                                       </div>
                                       <div class="modal-footer">
                                          <button class="btn btn-primary" type="button" data-dismiss="modal">না! থাক</button>
                        <a class="btn btn-danger" type="button" href="delete_parcel.php?MasRiaKib=<?php echo $row['parcel_id']; ?>">ডিলিট</a>
                                       </div>
                                    </div>
                                 </div>
                              </div>

                              <a href="viewParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="fas fa-eye"></i></a>
                              <a target="_blank" href="updateParcelpending.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="far fa-edit"></i></a>
                              <a class="btn btn-outline-primary btn-icon btn-sm" target="_blank" href="print_parcel.php?id=<?php echo $row['parcel_id']; ?>"><i class="fas fa-print"></i></a>
                           </td>
                        </tr>
                        <?php } ?>
                        </tbody>
                        <?php } ?>
                        </table>

                        </form>

                        </div>
                        </div>
                        </div>
                        </div>
                        </main>
<?php
    break;
  case "/AllPick.php":
?>
<?php ob_start();
$title = "পিকআপ অ্যাসাইন";
include 'menu.php';?>
<script>
  window.onload=function(){
        document.getElementById('loder').style.display="none";
        document.getElementById('content').style.display="block";
  };
</script>
<style>
  #content {display: none;}
  #content img{width: 100%;}
  #loder{
    position: absolute;
    margin: auto;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    width: 300px;
    height: 300px;
  }
  #loder img{width: 300px;}
</style>
<div id="loder">
<img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
</div>
<?php
include 'config.php';
if (isset($_REQUEST['delete_m_data'])) {
  $c_heros = $_REQUEST['c_heros'];
  $c_actions = $_REQUEST['c_actions'];
  $check_data = $_REQUEST['check_data'];
  $all_marked = implode(",",$check_data);

  $query = "UPDATE parcel SET
   c_action = '$c_actions',
   c_hero = '$c_heros'
   WHERE parcel_id in ($all_marked);";

   if ($c_actions == 5) {
     $query .= "UPDATE parcel SET
       p_Pay ='1'
        WHERE parcel_id in ($all_marked);";
   }else {
     $query .= "UPDATE parcel SET
       p_Pay ='0'
       WHERE parcel_id in ($all_marked);";
   }

     $ALLDATAS = $_REQUEST['check_data'];
     if ($ALLDATAS) {
       foreach ($ALLDATAS as $c) {
         $query .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('".mysqli_real_escape_string($connection,$c)."','$c_actions','{$_SESSION["name"]}','$c_heros');";
       }


  $result = mysqli_multi_query($connection,$query) or die("Query Faield.");

   }
     }
 ?>

<main id="content">
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                       <div class="container-fluid">
                           <div class="page-header-content">
                               <div class="row align-items-center justify-content-between pt-3">
                                   <div class="col-auto mb-3">
                                   </div>
<?php include 'submenu.php';?>
                               </div>
                           </div>
                       </div>
                   </header>
                   <!-- Main page content-->
   <!-- Main page content-->
                 <form class="" action="" method="post">
   <div class="container">
      <div class="card mb-4">
         <div class="card-header">


            <!-- Multi Select -->
            <div class="row">
               <div class="col-xl-5">
                 <a title="নতুন একটি পার্সেল এড করুন" href="addParcel.php" class="btn btn-outline-primary btn-icon">
                 <i class="fas fa-plus-circle"></i>
                 </a>


                 <a title="নতুন বাল্ক ফাইল আপলোড করুন" href="addParcelcsv.php" class="btn btn-outline-primary btn-icon">
                 <i class="fas fa-file-csv"></i>
                 </a>
                 <a title="বাল্ক ফাইল ডাউনলোড করুন" href="X2!dswsDsfb.php?idDFsdfgxcgvbdgrgdxfbdtgbrtxb=2" class="btn btn-outline-dark btn-icon">
                 <i class="fas fa-arrow-circle-down"></i>
                 </a>
                 </div>
               <div class="col-xl-5">
                 <div class="row">
                    <div class="col-xl-6">
                      <?php if ($_SESSION['role'] =='5') {?>
            <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
                <option selected value="">একটি স্টাটাস বাছুন</option>
                <?php
                       include 'config.php';
                       $query_s = "SELECT * FROM action";
                       $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                       if (mysqli_num_rows($result_s) > 0) {
                         while ($row_S = mysqli_fetch_assoc($result_s)) {

                           if ($row['c_action'] == $row_S['action_id']) {
                             $selected = "selected";
                           }else {
                             $selected = "";
                           }

                           echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                         }
                       }
                        ?>
            </select>
            </div>
            <div class="col-xl-6">
              <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
                  <option selected value="">একজন হিরো বাছুন</option>
                  <?php
                         include 'config.php';
                         $query_h = "SELECT * FROM hero";
                         $result_h = mysqli_query($connection,$query_h)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                         if (mysqli_num_rows($result_h) > 0) {
                           while ($row_h = mysqli_fetch_assoc($result_h)) {

                             if ($row['c_hero'] == "2") {
                               $selected = "selected";
                             }else {
                               $selected = "";
                             }

                             echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                           }
                         }
                          ?>
              </select>

            </div>
            </div>
            </div>
            <div class="col-xl-2">
              <input required class="btn btn-primary" type="submit" name="delete_m_data" value="পরিবর্তন">

              <?php
              include 'config.php';
              if (isset($_REQUEST['Paysubmit'])) {
                $check_datap = $_REQUEST['check_data'];
                $all_markedp = implode(",",$check_datap);
                $queryp = "UPDATE parcel SET
                 p_Pay ='2'
                 WHERE parcel_id in ($all_markedp)";

                $resultp = mysqli_query($connection,$queryp) or die("Query Faield.");
                 }
               ?>
              <form class="" action="" method="post">
               <input class="btn btn-outline-black btn-icon" type="submit" name="Paysubmit" value="&#2547;">
              </form>
<?php } ?>
            </div>
            </div>
            <!-- Multi Select -->
         </div>

         <div class="card-body">
            <div class="datatable">






               <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

<?php
                     include 'config.php';
                     if ($_SESSION['role']== '5') {
                     $query = "SELECT * FROM parcel
                     LEFT JOIN services ON parcel.c_service = services.id
                     LEFT JOIN area ON parcel.c_area = area.id
                     LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                     LEFT JOIN action ON parcel.c_action = action.action_id
                     LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                     LEFT JOIN pay ON parcel.p_Pay = pay.payID
                     WHERE action.action_id = 2
                     ORDER BY parcel.parcel_id DESC limit 200";
                     }elseif ($_SESSION['role']== '1') {
                     $query = "SELECT * FROM parcel
                     LEFT JOIN services ON parcel.c_service = services.id
                     LEFT JOIN area ON parcel.c_area = area.id
                     LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                     LEFT JOIN action ON parcel.c_action = action.action_id
                     LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                     WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 2
                     ORDER BY parcel.parcel_id DESC";
                     }else {
                     ?>
                  <div class="container p-5">
                     <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                     </div>
                     <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                        <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                        <hr>
                        <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                     </div>
                  </div>
                  <?php
                     die;
                     }
                    ?>
<?php
    break;
    case "/AllRecived.php":
?><?php ob_start(); ?>
<?php $title = "রিসিভ পার্সেল"; ?>
<?php include 'menu.php';?>
<script>
  window.onload=function(){
        document.getElementById('loder').style.display="none";
        document.getElementById('content').style.display="block";
  };
</script>
<style>
  #content {display: none;}
  #content img{width: 100%;}
  #loder{
    position: absolute;
    margin: auto;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    width: 300px;
    height: 300px;
  }
  #loder img{width: 300px;}
</style>
<div id="loder">
<img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
</div>
<?php
include 'config.php';
if (isset($_REQUEST['delete_m_data'])) {
  $c_heros = $_REQUEST['c_heros'];
  $c_actions = $_REQUEST['c_actions'];
  $check_data = $_REQUEST['check_data'];
  $all_marked = implode(",",$check_data);

  $query = "UPDATE parcel SET
   c_action = '$c_actions',
   c_hero = '$c_heros'
   WHERE parcel_id in ($all_marked);";

   if ($c_actions == 5) {
     $query .= "UPDATE parcel SET
       p_Pay ='1'
        WHERE parcel_id in ($all_marked);";
   }else {
     $query .= "UPDATE parcel SET
       p_Pay ='0'
       WHERE parcel_id in ($all_marked);";
   }

     $ALLDATAS = $_REQUEST['check_data'];
     if ($ALLDATAS) {
       foreach ($ALLDATAS as $c) {
         $query .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('".mysqli_real_escape_string($connection,$c)."','$c_actions','{$_SESSION["name"]}','$c_heros');";
       }


  $result = mysqli_multi_query($connection,$query) or die("Query Faield.");

   }
     }
 ?>

<main id="content">
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                       <div class="container-fluid">
                           <div class="page-header-content">
                               <div class="row align-items-center justify-content-between pt-3">
                                   <div class="col-auto mb-3">
                                   </div>
<?php include 'submenu.php';?>
                               </div>
                           </div>
                       </div>
                   </header>
                   <!-- Main page content-->
   <!-- Main page content-->
                 <form class="" action="" method="post">
   <div class="container">
      <div class="card mb-4">
         <div class="card-header">


            <!-- Multi Select -->
            <div class="row">
               <div class="col-xl-5">
                 <a title="নতুন একটি পার্সেল এড করুন" href="addParcel.php" class="btn btn-outline-primary btn-icon">
                 <i class="fas fa-plus-circle"></i>
                 </a>


                 <a title="নতুন বাল্ক ফাইল আপলোড করুন" href="addParcelcsv.php" class="btn btn-outline-primary btn-icon">
                 <i class="fas fa-file-csv"></i>
                 </a>
                 <a title="বাল্ক ফাইল ডাউনলোড করুন" href="X2!dswsDsfb.php?idDFsdfgxcgvbdgrgdxfbdtgbrtxb=3" class="btn btn-outline-dark btn-icon">
                 <i class="fas fa-arrow-circle-down"></i>
                 </a>
                 </div>
               <div class="col-xl-5">
                 <div class="row">
                    <div class="col-xl-6">
                      <?php if ($_SESSION['role'] =='5') {?>
            <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
                <option selected value="">একটি স্টাটাস বাছুন</option>
                <?php
                       include 'config.php';
                       $query_s = "SELECT * FROM action";
                       $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                       if (mysqli_num_rows($result_s) > 0) {
                         while ($row_S = mysqli_fetch_assoc($result_s)) {

                           if ($row['c_action'] == $row_S['action_id']) {
                             $selected = "selected";
                           }else {
                             $selected = "";
                           }

                           echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                         }
                       }
                        ?>
            </select>
            </div>
            <div class="col-xl-6">
              <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
                  <option selected value="">একজন হিরো বাছুন</option>
                  <?php
                         include 'config.php';
                         $query_h = "SELECT * FROM hero";
                         $result_h = mysqli_query($connection,$query_h)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                         if (mysqli_num_rows($result_h) > 0) {
                           while ($row_h = mysqli_fetch_assoc($result_h)) {

                             if ($row['c_hero'] == "2") {
                               $selected = "selected";
                             }else {
                               $selected = "";
                             }

                             echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                           }
                         }
                          ?>
              </select>

            </div>
            </div>
            </div>
            <div class="col-xl-2">
              <input required class="btn btn-primary" type="submit" name="delete_m_data" value="পরিবর্তন">

              <?php
              include 'config.php';
              if (isset($_REQUEST['Paysubmit'])) {
                $check_datap = $_REQUEST['check_data'];
                $all_markedp = implode(",",$check_datap);
                $queryp = "UPDATE parcel SET
                 p_Pay ='2'
                 WHERE parcel_id in ($all_markedp)";

                $resultp = mysqli_query($connection,$queryp) or die("Query Faield.");
                 }
               ?>
              <form class="" action="" method="post">
               <input class="btn btn-outline-black btn-icon" type="submit" name="Paysubmit" value="&#2547;">
              </form>
<?php } ?>
            </div>
            </div>
            <!-- Multi Select -->
         </div>

         <div class="card-body">
            <div class="datatable">

               <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

<?php
                     include 'config.php';
                     if ($_SESSION['role']== '5') {
                     $query = "SELECT * FROM parcel
                     LEFT JOIN services ON parcel.c_service = services.id
                     LEFT JOIN area ON parcel.c_area = area.id
                     LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                     LEFT JOIN action ON parcel.c_action = action.action_id
                     LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                     LEFT JOIN pay ON parcel.p_Pay = pay.payID
                     WHERE action.action_id = 3
                     ORDER BY parcel.parcel_id DESC";
                     }elseif ($_SESSION['role']== '1') {
                     $query = "SELECT * FROM parcel
                     LEFT JOIN services ON parcel.c_service = services.id
                     LEFT JOIN area ON parcel.c_area = area.id
                     LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                     LEFT JOIN action ON parcel.c_action = action.action_id
                     LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                     WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 3
                     ORDER BY parcel.parcel_id DESC";
                     }else {
                     ?>
                  <div class="container p-5">
                     <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                     </div>
                     <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                        <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                        <hr>
                        <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                     </div>
                  </div>
                  <?php
                     die;
                     }
                    ?><?php
      break;
      case "/AllDelivaryAssign.php":
?><?php ob_start(); ?>
<?php $title = "ডেলিভারি অ্যাসাইন পার্সেল"; ?>
<?php include 'menu.php';?>
<script>
  window.onload=function(){
        document.getElementById('loder').style.display="none";
        document.getElementById('content').style.display="block";
  };
</script>
<style>
  #content {display: none;}
  #content img{width: 100%;}
  #loder{
    position: absolute;
    margin: auto;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    width: 300px;
    height: 300px;
  }
  #loder img{width: 300px;}
</style>
<div id="loder">
<img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
</div>
<?php
include 'config.php';
if (isset($_REQUEST['delete_m_data'])) {
  $c_heros = $_REQUEST['c_heros'];
  $c_actions = $_REQUEST['c_actions'];
  $check_data = $_REQUEST['check_data'];
  $all_marked = implode(",",$check_data);

  $query = "UPDATE parcel SET
   c_action = '$c_actions',
   c_hero = '$c_heros'
   WHERE parcel_id in ($all_marked);";

   if ($c_actions == 5) {
     $query .= "UPDATE parcel SET
       p_Pay ='1'
        WHERE parcel_id in ($all_marked);";
   }else {
     $query .= "UPDATE parcel SET
       p_Pay ='0'
       WHERE parcel_id in ($all_marked);";
   }

     $ALLDATAS = $_REQUEST['check_data'];
     if ($ALLDATAS) {
       foreach ($ALLDATAS as $c) {
         $query .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('".mysqli_real_escape_string($connection,$c)."','$c_actions','{$_SESSION["name"]}','$c_heros');";
       }


  $result = mysqli_multi_query($connection,$query) or die("Query Faield.");

   }
     }
 ?>


<main id="content">
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                       <div class="container-fluid">
                           <div class="page-header-content">
                               <div class="row align-items-center justify-content-between pt-3">
                                   <div class="col-auto mb-3">
                                   </div>
<?php include 'submenu.php';?>
                               </div>
                           </div>
                       </div>
                   </header>
                   <!-- Main page content-->
   <!-- Main page content-->
                 <form class="" action="" method="post">
   <div class="container">
      <div class="card mb-4">
         <div class="card-header">


            <!-- Multi Select -->
            <div class="row">
               <div class="col-xl-5">
                 <a title="নতুন একটি পার্সেল এড করুন" href="addParcel.php" class="btn btn-outline-primary btn-icon">
                 <i class="fas fa-plus-circle"></i>
                 </a>


                 <a title="নতুন বাল্ক ফাইল আপলোড করুন" href="addParcelcsv.php" class="btn btn-outline-primary btn-icon">
                 <i class="fas fa-file-csv"></i>
                 </a>
                 <a title="বাল্ক ফাইল ডাউনলোড করুন" href="X2!dswsDsfb.php?idDFsdfgxcgvbdgrgdxfbdtgbrtxb=4" class="btn btn-outline-dark btn-icon">
                 <i class="fas fa-arrow-circle-down"></i>
                 </a>
                 </div>
               <div class="col-xl-5">
                 <div class="row">
                    <div class="col-xl-6">
                      <?php if ($_SESSION['role'] =='5') {?>
            <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
                <option selected value="">একটি স্টাটাস বাছুন</option>
                <?php
                       include 'config.php';
                       $query_s = "SELECT * FROM action";
                       $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                       if (mysqli_num_rows($result_s) > 0) {
                         while ($row_S = mysqli_fetch_assoc($result_s)) {

                           if ($row['c_action'] == $row_S['action_id']) {
                             $selected = "selected";
                           }else {
                             $selected = "";
                           }

                           echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                         }
                       }
                        ?>
            </select>
            </div>
            <div class="col-xl-6">
              <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
                  <option selected value="">একজন হিরো বাছুন</option>
                  <?php
                         include 'config.php';
                         $query_h = "SELECT * FROM hero";
                         $result_h = mysqli_query($connection,$query_h)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                         if (mysqli_num_rows($result_h) > 0) {
                           while ($row_h = mysqli_fetch_assoc($result_h)) {

                             if ($row['c_hero'] == "2") {
                               $selected = "selected";
                             }else {
                               $selected = "";
                             }

                             echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                           }
                         }
                          ?>
              </select>

            </div>
            </div>
            </div>
            <div class="col-xl-2">
              <input required class="btn btn-primary" type="submit" name="delete_m_data" value="পরিবর্তন">

              <?php
              include 'config.php';
              if (isset($_REQUEST['Paysubmit'])) {
                $check_datap = $_REQUEST['check_data'];
                $all_markedp = implode(",",$check_datap);
                $queryp = "UPDATE parcel SET
                 p_Pay ='2'
                 WHERE parcel_id in ($all_markedp)";

                $resultp = mysqli_query($connection,$queryp) or die("Query Faield.");
                 }
               ?>
              <form class="" action="" method="post">
               <input class="btn btn-outline-black btn-icon" type="submit" name="Paysubmit" value="&#2547;">
              </form>
<?php } ?>
            </div>
            </div>
            <!-- Multi Select -->
         </div>

         <div class="card-body">
            <div class="datatable">





               <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

<?php
                     include 'config.php';
                     if ($_SESSION['role']== '5') {
                     $query = "SELECT * FROM parcel
                     LEFT JOIN services ON parcel.c_service = services.id
                     LEFT JOIN area ON parcel.c_area = area.id
                     LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                     LEFT JOIN action ON parcel.c_action = action.action_id
                     LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                     LEFT JOIN pay ON parcel.p_Pay = pay.payID
                     WHERE action.action_id = 4
                     ORDER BY parcel.parcel_id DESC limit 200";
                     }elseif ($_SESSION['role']== '1') {
                     $query = "SELECT * FROM parcel
                     LEFT JOIN services ON parcel.c_service = services.id
                     LEFT JOIN area ON parcel.c_area = area.id
                     LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                     LEFT JOIN action ON parcel.c_action = action.action_id
                     LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                     WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 4
                     ORDER BY parcel.parcel_id DESC";
                     }else {
                     ?>
                  <div class="container p-5">
                     <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                     </div>
                     <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                        <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                        <hr>
                        <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                     </div>
                  </div>
                  <?php
                     die;
                     }
                    ?><?php
        break;
        case "/AllDelivared.php":
        ?><?php ob_start(); ?>
        <?php $title = "ডেলিভার্ড পার্সেল"; ?>
        <?php include 'menu.php';?>
        <script>
          window.onload=function(){
                document.getElementById('loder').style.display="none";
                document.getElementById('content').style.display="block";
          };
        </script>
        <style>
          #content {display: none;}
          #content img{width: 100%;}
          #loder{
            position: absolute;
            margin: auto;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            width: 300px;
            height: 300px;
          }
          #loder img{width: 300px;}
        </style>
        <div id="loder">
        <img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
        </div>
        <?php
        include 'config.php';
        if (isset($_REQUEST['delete_m_data'])) {
          $c_heros = $_REQUEST['c_heros'];
          $c_actions = $_REQUEST['c_actions'];
          $check_data = $_REQUEST['check_data'];
          $all_marked = implode(",",$check_data);

          $query = "UPDATE parcel SET
           c_action = '$c_actions',
           c_hero = '$c_heros'
           WHERE parcel_id in ($all_marked);";

           if ($c_actions == 5) {
             $query .= "UPDATE parcel SET
               p_Pay ='1'
                WHERE parcel_id in ($all_marked);";
           }else {
             $query .= "UPDATE parcel SET
               p_Pay ='0'
               WHERE parcel_id in ($all_marked);";
           }

             $ALLDATAS = $_REQUEST['check_data'];
             if ($ALLDATAS) {
               foreach ($ALLDATAS as $c) {
                 $query .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('".mysqli_real_escape_string($connection,$c)."','$c_actions','{$_SESSION["name"]}','$c_heros');";
               }


          $result = mysqli_multi_query($connection,$query) or die("Query Faield.");

           }
             }
         ?>


        <main id="content">
           <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                               <div class="container-fluid">
                                   <div class="page-header-content">
                                       <div class="row align-items-center justify-content-between pt-3">
                                           <div class="col-auto mb-3">
                                           </div>
        <?php include 'submenu.php';?>
                                       </div>
                                   </div>
                               </div>
                           </header>
                           <!-- Main page content-->
           <!-- Main page content-->
                         <form class="" action="" method="post">
           <div class="container">
              <div class="card mb-4">
                 <div class="card-header">


                    <!-- Multi Select -->
                    <div class="row">
                       <div class="col-xl-5">
                         <a title="নতুন একটি পার্সেল এড করুন" href="addParcel.php" class="btn btn-outline-primary btn-icon">
                         <i class="fas fa-plus-circle"></i>
                         </a>


                         <a title="নতুন বাল্ক ফাইল আপলোড করুন" href="addParcelcsv.php" class="btn btn-outline-primary btn-icon">
                         <i class="fas fa-file-csv"></i>
                         </a>
                         <a title="বাল্ক ফাইল ডাউনলোড করুন" href="X2!dswsDsfb.php?idDFsdfgxcgvbdgrgdxfbdtgbrtxb=5" class="btn btn-outline-dark btn-icon">
                         <i class="fas fa-arrow-circle-down"></i>
                         </a>

                         </div>
                       <div class="col-xl-5">
                         <div class="row">
                            <div class="col-xl-6">
                              <?php if ($_SESSION['role'] =='5') {?>
                    <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
                        <option selected value="">একটি স্টাটাস বাছুন</option>
                        <?php
                               include 'config.php';
                               $query_s = "SELECT * FROM action";
                               $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                               if (mysqli_num_rows($result_s) > 0) {
                                 while ($row_S = mysqli_fetch_assoc($result_s)) {

                                   if ($row['c_action'] == $row_S['action_id']) {
                                     $selected = "selected";
                                   }else {
                                     $selected = "";
                                   }

                                   echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                                 }
                               }
                                ?>
                    </select>
                    </div>
                    <div class="col-xl-6">
                      <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
                          <option selected value="">একজন হিরো বাছুন</option>
                          <?php
                                 include 'config.php';
                                 $query_h = "SELECT * FROM hero";
                                 $result_h = mysqli_query($connection,$query_h)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                 if (mysqli_num_rows($result_h) > 0) {
                                   while ($row_h = mysqli_fetch_assoc($result_h)) {

                                     if ($row['c_hero'] == "2") {
                                       $selected = "selected";
                                     }else {
                                       $selected = "";
                                     }

                                     echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                                   }
                                 }
                                  ?>
                      </select>

                    </div>
                    </div>
                    </div>
                    <div class="col-xl-2">
                      <input required class="btn btn-primary" type="submit" name="delete_m_data" value="পরিবর্তন">

                      <?php
                      include 'config.php';
                      if (isset($_REQUEST['Paysubmit'])) {
                        $check_datap = $_REQUEST['check_data'];
                        $all_markedp = implode(",",$check_datap);
                        $queryp = "UPDATE parcel SET
                         p_Pay ='2'
                         WHERE parcel_id in ($all_markedp)";

                        $resultp = mysqli_query($connection,$queryp) or die("Query Faield.");
                         }
                       ?>
                      <form class="" action="" method="post">
                       <input class="btn btn-outline-black btn-icon" type="submit" name="Paysubmit" value="&#2547;">
                      </form>
        <?php } ?>
                    </div>
                    </div>
                    <!-- Multi Select -->
                 </div>

                 <div class="card-body">
                    <div class="datatable">





                       <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

        <?php
                             include 'config.php';
                             if ($_SESSION['role']== '5') {
                             $query = "SELECT * FROM parcel
                             LEFT JOIN services ON parcel.c_service = services.id
                             LEFT JOIN area ON parcel.c_area = area.id
                             LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                             LEFT JOIN action ON parcel.c_action = action.action_id
                             LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                             LEFT JOIN pay ON parcel.p_Pay = pay.payID
                             WHERE action.action_id = 5
                             ORDER BY parcel.parcel_id DESC limit 200";
                             }elseif ($_SESSION['role']== '1') {
                             $query = "SELECT * FROM parcel
                             LEFT JOIN services ON parcel.c_service = services.id
                             LEFT JOIN area ON parcel.c_area = area.id
                             LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                             LEFT JOIN action ON parcel.c_action = action.action_id
                             LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                             WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 5
                             ORDER BY parcel.parcel_id DESC";
                             }else {
                             ?>
                          <div class="container p-5">
                             <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                             </div>
                             <div class="alert alert-success" role="alert">
                                <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                                <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                                <hr>
                                <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                             </div>
                          </div>
                          <?php
                             die;
                             }
                            ?><?php
          break;
          case "/AllReschedule.php":
          ?><?php ob_start(); ?>
          <?php $title = "রিশিডিউল পার্সেল"; ?>
          <?php include 'menu.php';?>
          <script>
            window.onload=function(){
                  document.getElementById('loder').style.display="none";
                  document.getElementById('content').style.display="block";
            };
          </script>
          <style>
            #content {display: none;}
            #content img{width: 100%;}
            #loder{
              position: absolute;
              margin: auto;
              top: 0;
              right: 0;
              bottom: 0;
              left: 0;
              width: 300px;
              height: 300px;
            }
            #loder img{width: 300px;}
          </style>
          <div id="loder">
          <img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
          </div>
          <?php
          include 'config.php';
          if (isset($_REQUEST['delete_m_data'])) {
            $c_heros = $_REQUEST['c_heros'];
            $c_actions = $_REQUEST['c_actions'];
            $check_data = $_REQUEST['check_data'];
            $all_marked = implode(",",$check_data);

            $query = "UPDATE parcel SET
             c_action = '$c_actions',
             c_hero = '$c_heros'
             WHERE parcel_id in ($all_marked);";

             if ($c_actions == 5) {
               $query .= "UPDATE parcel SET
                 p_Pay ='1'
                  WHERE parcel_id in ($all_marked);";
             }else {
               $query .= "UPDATE parcel SET
                 p_Pay ='0'
                 WHERE parcel_id in ($all_marked);";
             }

               $ALLDATAS = $_REQUEST['check_data'];
               if ($ALLDATAS) {
                 foreach ($ALLDATAS as $c) {
                   $query .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('".mysqli_real_escape_string($connection,$c)."','$c_actions','{$_SESSION["name"]}','$c_heros');";
                 }


            $result = mysqli_multi_query($connection,$query) or die("Query Faield.");

             }
               }
           ?>


          <main id="content">
             <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                                 <div class="container-fluid">
                                     <div class="page-header-content">
                                         <div class="row align-items-center justify-content-between pt-3">
                                             <div class="col-auto mb-3">
                                             </div>
          <?php include 'submenu.php';?>
                                         </div>
                                     </div>
                                 </div>
                             </header>
                             <!-- Main page content-->
             <!-- Main page content-->
                           <form class="" action="" method="post">
             <div class="container">
                <div class="card mb-4">
                   <div class="card-header">


                      <!-- Multi Select -->
                      <div class="row">
                         <div class="col-xl-5">
                           <a title="নতুন একটি পার্সেল এড করুন" href="addParcel.php" class="btn btn-outline-primary btn-icon">
                           <i class="fas fa-plus-circle"></i>
                           </a>


                           <a title="নতুন বাল্ক ফাইল আপলোড করুন" href="addParcelcsv.php" class="btn btn-outline-primary btn-icon">
                           <i class="fas fa-file-csv"></i>
                           </a>
                           <a title="বাল্ক ফাইল ডাউনলোড করুন" href="X2!dswsDsfb.php?idDFsdfgxcgvbdgrgdxfbdtgbrtxb=6" class="btn btn-outline-dark btn-icon">
                           <i class="fas fa-arrow-circle-down"></i>
                           </a>
                           </div>
                         <div class="col-xl-5">
                           <div class="row">
                              <div class="col-xl-6">
                                <?php if ($_SESSION['role'] =='5') {?>
                      <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
                          <option selected value="">একটি স্টাটাস বাছুন</option>
                          <?php
                                 include 'config.php';
                                 $query_s = "SELECT * FROM action";
                                 $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                 if (mysqli_num_rows($result_s) > 0) {
                                   while ($row_S = mysqli_fetch_assoc($result_s)) {

                                     if ($row['c_action'] == $row_S['action_id']) {
                                       $selected = "selected";
                                     }else {
                                       $selected = "";
                                     }

                                     echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                                   }
                                 }
                                  ?>
                      </select>
                      </div>
                      <div class="col-xl-6">
                        <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
                            <option selected value="">একজন হিরো বাছুন</option>
                            <?php
                                   include 'config.php';
                                   $query_h = "SELECT * FROM hero";
                                   $result_h = mysqli_query($connection,$query_h)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                   if (mysqli_num_rows($result_h) > 0) {
                                     while ($row_h = mysqli_fetch_assoc($result_h)) {

                                       if ($row['c_hero'] == "2") {
                                         $selected = "selected";
                                       }else {
                                         $selected = "";
                                       }

                                       echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                                     }
                                   }
                                    ?>
                        </select>

                      </div>
                      </div>
                      </div>
                      <div class="col-xl-2">
                        <input required class="btn btn-primary" type="submit" name="delete_m_data" value="পরিবর্তন">

                        <?php
                        include 'config.php';
                        if (isset($_REQUEST['Paysubmit'])) {
                          $check_datap = $_REQUEST['check_data'];
                          $all_markedp = implode(",",$check_datap);
                          $queryp = "UPDATE parcel SET
                           p_Pay ='2'
                           WHERE parcel_id in ($all_markedp)";

                          $resultp = mysqli_query($connection,$queryp) or die("Query Faield.");
                           }
                         ?>
                        <form class="" action="" method="post">
                         <input class="btn btn-outline-black btn-icon" type="submit" name="Paysubmit" value="&#2547;">
                        </form>
          <?php } ?>
                      </div>
                      </div>
                      <!-- Multi Select -->
                   </div>

                   <div class="card-body">
                      <div class="datatable">





                         <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

          <?php
                               include 'config.php';
                               if ($_SESSION['role']== '5') {
                               $query = "SELECT * FROM parcel
                               LEFT JOIN services ON parcel.c_service = services.id
                               LEFT JOIN area ON parcel.c_area = area.id
                               LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                               LEFT JOIN action ON parcel.c_action = action.action_id
                               LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                               LEFT JOIN pay ON parcel.p_Pay = pay.payID
                               WHERE action.action_id = 6
                               ORDER BY parcel.parcel_id DESC";
                               }elseif ($_SESSION['role']== '1') {
                               $query = "SELECT * FROM parcel
                               LEFT JOIN services ON parcel.c_service = services.id
                               LEFT JOIN area ON parcel.c_area = area.id
                               LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                               LEFT JOIN action ON parcel.c_action = action.action_id
                               LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                               WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 6
                               ORDER BY parcel.parcel_id DESC";
                               }else {
                               ?>
                            <div class="container p-5">
                               <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                  <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                  </button>
                               </div>
                               <div class="alert alert-success" role="alert">
                                  <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                                  <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                                  <hr>
                                  <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                               </div>
                            </div>
                            <?php
                               die;
                               }
                              ?><?php
            break;
          case "/allBackPeon.php":
            ?><?php ob_start(); ?>
            <?php $title = "ব্যাক টু পিয়ন পার্সেল"; ?>
            <?php include 'menu.php';?>
            <script>
              window.onload=function(){
                    document.getElementById('loder').style.display="none";
                    document.getElementById('content').style.display="block";
              };
            </script>
            <style>
              #content {display: none;}
              #content img{width: 100%;}
              #loder{
                position: absolute;
                margin: auto;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                width: 300px;
                height: 300px;
              }
              #loder img{width: 300px;}
            </style>
            <div id="loder">
            <img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
            </div>
            <?php
            include 'config.php';
            if (isset($_REQUEST['delete_m_data'])) {
              $c_heros = $_REQUEST['c_heros'];
              $c_actions = $_REQUEST['c_actions'];
              $check_data = $_REQUEST['check_data'];
              $all_marked = implode(",",$check_data);

              $query = "UPDATE parcel SET
               c_action = '$c_actions',
               c_hero = '$c_heros'
               WHERE parcel_id in ($all_marked);";

               if ($c_actions == 5) {
                 $query .= "UPDATE parcel SET
                   p_Pay ='1'
                    WHERE parcel_id in ($all_marked);";
               }else {
                 $query .= "UPDATE parcel SET
                   p_Pay ='0'
                   WHERE parcel_id in ($all_marked);";
               }

                 $ALLDATAS = $_REQUEST['check_data'];
                 if ($ALLDATAS) {
                   foreach ($ALLDATAS as $c) {
                     $query .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('".mysqli_real_escape_string($connection,$c)."','$c_actions','{$_SESSION["name"]}','$c_heros');";
                   }


              $result = mysqli_multi_query($connection,$query) or die("Query Faield.");

               }
                 }
             ?>

            <main id="content">
               <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                                   <div class="container-fluid">
                                       <div class="page-header-content">
                                           <div class="row align-items-center justify-content-between pt-3">
                                               <div class="col-auto mb-3">
                                               </div>
            <?php include 'submenu.php';?>
                                           </div>
                                       </div>
                                   </div>
                               </header>
                               <!-- Main page content-->
               <!-- Main page content-->
                             <form class="" action="" method="post">
               <div class="container">
                  <div class="card mb-4">
                     <div class="card-header">


                        <!-- Multi Select -->
                        <div class="row">
                           <div class="col-xl-5">
                             <a title="নতুন একটি পার্সেল এড করুন" href="addParcel.php" class="btn btn-outline-primary btn-icon">
                             <i class="fas fa-plus-circle"></i>
                             </a>


                             <a title="নতুন বাল্ক ফাইল আপলোড করুন" href="addParcelcsv.php" class="btn btn-outline-primary btn-icon">
                             <i class="fas fa-file-csv"></i>
                             </a>
                             <a title="বাল্ক ফাইল ডাউনলোড করুন" href="X2!dswsDsfb.php?idDFsdfgxcgvbdgrgdxfbdtgbrtxb=7" class="btn btn-outline-dark btn-icon">
                             <i class="fas fa-arrow-circle-down"></i>
                             </a>
                             </div>
                           <div class="col-xl-5">
                             <div class="row">
                                <div class="col-xl-6">
                                  <?php if ($_SESSION['role'] =='5') {?>
                        <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
                            <option selected value="">একটি স্টাটাস বাছুন</option>
                            <?php
                                   include 'config.php';
                                   $query_s = "SELECT * FROM action";
                                   $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                   if (mysqli_num_rows($result_s) > 0) {
                                     while ($row_S = mysqli_fetch_assoc($result_s)) {

                                       if ($row['c_action'] == $row_S['action_id']) {
                                         $selected = "selected";
                                       }else {
                                         $selected = "";
                                       }

                                       echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                                     }
                                   }
                                    ?>
                        </select>
                        </div>
                        <div class="col-xl-6">
                          <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
                              <option selected value="">একজন হিরো বাছুন</option>
                              <?php
                                     include 'config.php';
                                     $query_h = "SELECT * FROM hero";
                                     $result_h = mysqli_query($connection,$query_h)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                     if (mysqli_num_rows($result_h) > 0) {
                                       while ($row_h = mysqli_fetch_assoc($result_h)) {

                                         if ($row['c_hero'] == "2") {
                                           $selected = "selected";
                                         }else {
                                           $selected = "";
                                         }

                                         echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                                       }
                                     }
                                      ?>
                          </select>

                        </div>
                        </div>
                        </div>
                        <div class="col-xl-2">
                          <input required class="btn btn-primary" type="submit" name="delete_m_data" value="পরিবর্তন">

                          <?php
                          include 'config.php';
                          if (isset($_REQUEST['Paysubmit'])) {
                            $check_datap = $_REQUEST['check_data'];
                            $all_markedp = implode(",",$check_datap);
                            $queryp = "UPDATE parcel SET
                             p_Pay ='2'
                             WHERE parcel_id in ($all_markedp)";

                            $resultp = mysqli_query($connection,$queryp) or die("Query Faield.");
                             }
                           ?>
                          <form class="" action="" method="post">
                           <input class="btn btn-outline-black btn-icon" type="submit" name="Paysubmit" value="&#2547;">
                          </form>
            <?php } ?>
                        </div>
                        </div>
                        <!-- Multi Select -->
                     </div>

                     <div class="card-body">
                        <div class="datatable">





                           <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

            <?php
                                 include 'config.php';
                                 if ($_SESSION['role']== '5') {
                                 $query = "SELECT * FROM parcel
                                 LEFT JOIN services ON parcel.c_service = services.id
                                 LEFT JOIN area ON parcel.c_area = area.id
                                 LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                                 LEFT JOIN action ON parcel.c_action = action.action_id
                                 LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                                 LEFT JOIN pay ON parcel.p_Pay = pay.payID
                                 WHERE action.action_id = 7
                                 ORDER BY parcel.parcel_id DESC";
                                 }elseif ($_SESSION['role']== '1') {
                                 $query = "SELECT * FROM parcel
                                 LEFT JOIN services ON parcel.c_service = services.id
                                 LEFT JOIN area ON parcel.c_area = area.id
                                 LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                                 LEFT JOIN action ON parcel.c_action = action.action_id
                                 LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                                 WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 7
                                 ORDER BY parcel.parcel_id DESC";
                                 }else {
                                 ?>
                              <div class="container p-5">
                                 <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                 </div>
                                 <div class="alert alert-success" role="alert">
                                    <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                                    <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                                    <hr>
                                    <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                                 </div>
                              </div>
                              <?php
                                 die;
                                 }
                                ?><?php
            break;
          case "/allReturnAssign.php":
?><?php ob_start(); ?>
<?php $title = "রিটার্ণ অ্যাসাইন পার্সেল"; ?>
<?php include 'menu.php';?>
<script>
  window.onload=function(){
        document.getElementById('loder').style.display="none";
        document.getElementById('content').style.display="block";
  };
</script>
<style>
  #content {display: none;}
  #content img{width: 100%;}
  #loder{
    position: absolute;
    margin: auto;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    width: 300px;
    height: 300px;
  }
  #loder img{width: 300px;}
</style>
<div id="loder">
<img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
</div>
<?php
include 'config.php';
if (isset($_REQUEST['delete_m_data'])) {
  $c_heros = $_REQUEST['c_heros'];
  $c_actions = $_REQUEST['c_actions'];
  $check_data = $_REQUEST['check_data'];
  $all_marked = implode(",",$check_data);

  $query = "UPDATE parcel SET
   c_action = '$c_actions',
   c_hero = '$c_heros'
   WHERE parcel_id in ($all_marked);";

   if ($c_actions == 5) {
     $query .= "UPDATE parcel SET
       p_Pay ='1'
        WHERE parcel_id in ($all_marked);";
   }else {
     $query .= "UPDATE parcel SET
       p_Pay ='0'
       WHERE parcel_id in ($all_marked);";
   }

     $ALLDATAS = $_REQUEST['check_data'];
     if ($ALLDATAS) {
       foreach ($ALLDATAS as $c) {
         $query .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('".mysqli_real_escape_string($connection,$c)."','$c_actions','{$_SESSION["name"]}','$c_heros');";
       }


  $result = mysqli_multi_query($connection,$query) or die("Query Faield.");

   }
     }
 ?>

<main id="content">
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                       <div class="container-fluid">
                           <div class="page-header-content">
                               <div class="row align-items-center justify-content-between pt-3">
                                   <div class="col-auto mb-3">
                                   </div>
<?php include 'submenu.php';?>
                               </div>
                           </div>
                       </div>
                   </header>
                   <!-- Main page content-->
   <!-- Main page content-->
                 <form class="" action="" method="post">
   <div class="container">
      <div class="card mb-4">
         <div class="card-header">


            <!-- Multi Select -->
            <div class="row">
               <div class="col-xl-5">
                 <a title="নতুন একটি পার্সেল এড করুন" href="addParcel.php" class="btn btn-outline-primary btn-icon">
                 <i class="fas fa-plus-circle"></i>
                 </a>


                 <a title="নতুন বাল্ক ফাইল আপলোড করুন" href="addParcelcsv.php" class="btn btn-outline-primary btn-icon">
                 <i class="fas fa-file-csv"></i>
                 </a>
                 <a title="বাল্ক ফাইল ডাউনলোড করুন" href="X2!dswsDsfb.php?idDFsdfgxcgvbdgrgdxfbdtgbrtxb=8" class="btn btn-outline-dark btn-icon">
                 <i class="fas fa-arrow-circle-down"></i>
                 </a>
                 </div>
               <div class="col-xl-5">
                 <div class="row">
                    <div class="col-xl-6">
                      <?php if ($_SESSION['role'] =='5') {?>
            <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
                <option selected value="">একটি স্টাটাস বাছুন</option>
                <?php
                       include 'config.php';
                       $query_s = "SELECT * FROM action";
                       $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                       if (mysqli_num_rows($result_s) > 0) {
                         while ($row_S = mysqli_fetch_assoc($result_s)) {

                           if ($row['c_action'] == $row_S['action_id']) {
                             $selected = "selected";
                           }else {
                             $selected = "";
                           }

                           echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                         }
                       }
                        ?>
            </select>
            </div>
            <div class="col-xl-6">
              <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
                  <option selected value="">একজন হিরো বাছুন</option>
                  <?php
                         include 'config.php';
                         $query_h = "SELECT * FROM hero";
                         $result_h = mysqli_query($connection,$query_h)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                         if (mysqli_num_rows($result_h) > 0) {
                           while ($row_h = mysqli_fetch_assoc($result_h)) {

                             if ($row['c_hero'] == "2") {
                               $selected = "selected";
                             }else {
                               $selected = "";
                             }

                             echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                           }
                         }
                          ?>
              </select>

            </div>
            </div>
            </div>
            <div class="col-xl-2">
              <input required class="btn btn-primary" type="submit" name="delete_m_data" value="পরিবর্তন">

              <?php
              include 'config.php';
              if (isset($_REQUEST['Paysubmit'])) {
                $check_datap = $_REQUEST['check_data'];
                $all_markedp = implode(",",$check_datap);
                $queryp = "UPDATE parcel SET
                 p_Pay ='2'
                 WHERE parcel_id in ($all_markedp)";

                $resultp = mysqli_query($connection,$queryp) or die("Query Faield.");
                 }
               ?>
              <form class="" action="" method="post">
               <input class="btn btn-outline-black btn-icon" type="submit" name="Paysubmit" value="&#2547;">
              </form>
<?php } ?>
            </div>
            </div>
            <!-- Multi Select -->
         </div>

         <div class="card-body">
            <div class="datatable">
               <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

<?php
                     include 'config.php';
                     if ($_SESSION['role']== '5') {
                     $query = "SELECT * FROM parcel
                     LEFT JOIN services ON parcel.c_service = services.id
                     LEFT JOIN area ON parcel.c_area = area.id
                     LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                     LEFT JOIN action ON parcel.c_action = action.action_id
                     LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                     LEFT JOIN pay ON parcel.p_Pay = pay.payID
                     WHERE action.action_id = 8
                     ORDER BY parcel.parcel_id DESC";
                     }elseif ($_SESSION['role']== '1') {
                     $query = "SELECT * FROM parcel
                     LEFT JOIN services ON parcel.c_service = services.id
                     LEFT JOIN area ON parcel.c_area = area.id
                     LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                     LEFT JOIN action ON parcel.c_action = action.action_id
                     LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                     WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 8
                     ORDER BY parcel.parcel_id DESC";
                     }else {
                     ?>
                  <div class="container p-5">
                     <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                     </div>
                     <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                        <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                        <hr>
                        <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                     </div>
                  </div>
                  <?php
                     die;
                     }
                    ?><?php
            break;
          case "/AllReturn.php":
          ?><?php ob_start(); ?>
          <?php $title = "রিটার্ণ পার্সেল"; ?>
          <?php include 'menu.php';?>
          <script>
            window.onload=function(){
                  document.getElementById('loder').style.display="none";
                  document.getElementById('content').style.display="block";
            };
          </script>
          <style>
            #content {display: none;}
            #content img{width: 100%;}
            #loder{
              position: absolute;
              margin: auto;
              top: 0;
              right: 0;
              bottom: 0;
              left: 0;
              width: 300px;
              height: 300px;
            }
            #loder img{width: 300px;}
          </style>
          <div id="loder">
          <img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
          </div>
          <?php
          include 'config.php';
          if (isset($_REQUEST['delete_m_data'])) {
            $c_heros = $_REQUEST['c_heros'];
            $c_actions = $_REQUEST['c_actions'];
            $check_data = $_REQUEST['check_data'];
            $all_marked = implode(",",$check_data);

            $query = "UPDATE parcel SET
             c_action = '$c_actions',
             c_hero = '$c_heros'
             WHERE parcel_id in ($all_marked);";

             if ($c_actions == 5) {
               $query .= "UPDATE parcel SET
                 p_Pay ='1'
                  WHERE parcel_id in ($all_marked);";
             }else {
               $query .= "UPDATE parcel SET
                 p_Pay ='0'
                 WHERE parcel_id in ($all_marked);";
             }

               $ALLDATAS = $_REQUEST['check_data'];
               if ($ALLDATAS) {
                 foreach ($ALLDATAS as $c) {
                   $query .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('".mysqli_real_escape_string($connection,$c)."','$c_actions','{$_SESSION["name"]}','$c_heros');";
                 }


            $result = mysqli_multi_query($connection,$query) or die("Query Faield.");

             }
               }
           ?>


          <main id="content">
             <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                                 <div class="container-fluid">
                                     <div class="page-header-content">
                                         <div class="row align-items-center justify-content-between pt-3">
                                             <div class="col-auto mb-3">
                                             </div>
          <?php include 'submenu.php';?>
                                         </div>
                                     </div>
                                 </div>
                             </header>
                             <!-- Main page content-->
             <!-- Main page content-->
                           <form class="" action="" method="post">
             <div class="container">
                <div class="card mb-4">
                   <div class="card-header">


                      <!-- Multi Select -->
                      <div class="row">
                         <div class="col-xl-5">
                           <a title="নতুন একটি পার্সেল এড করুন" href="addParcel.php" class="btn btn-outline-primary btn-icon">
                           <i class="fas fa-plus-circle"></i>
                           </a>


                           <a title="নতুন বাল্ক ফাইল আপলোড করুন" href="addParcelcsv.php" class="btn btn-outline-primary btn-icon">
                           <i class="fas fa-file-csv"></i>
                           </a>
                           <a title="বাল্ক ফাইল ডাউনলোড করুন" href="X2!dswsDsfb.php?idDFsdfgxcgvbdgrgdxfbdtgbrtxb=9" class="btn btn-outline-dark btn-icon">
                           <i class="fas fa-arrow-circle-down"></i>
                           </a>
                           </div>
                         <div class="col-xl-5">
                           <div class="row">
                              <div class="col-xl-6">
                                <?php if ($_SESSION['role'] =='5') {?>
                      <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
                          <option selected value="">একটি স্টাটাস বাছুন</option>
                          <?php
                                 include 'config.php';
                                 $query_s = "SELECT * FROM action";
                                 $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                 if (mysqli_num_rows($result_s) > 0) {
                                   while ($row_S = mysqli_fetch_assoc($result_s)) {

                                     if ($row['c_action'] == $row_S['action_id']) {
                                       $selected = "selected";
                                     }else {
                                       $selected = "";
                                     }

                                     echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                                   }
                                 }
                                  ?>
                      </select>
                      </div>
                      <div class="col-xl-6">
                        <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
                            <option selected value="">একজন হিরো বাছুন</option>
                            <?php
                                   include 'config.php';
                                   $query_h = "SELECT * FROM hero";
                                   $result_h = mysqli_query($connection,$query_h)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                   if (mysqli_num_rows($result_h) > 0) {
                                     while ($row_h = mysqli_fetch_assoc($result_h)) {

                                       if ($row['c_hero'] == "2") {
                                         $selected = "selected";
                                       }else {
                                         $selected = "";
                                       }

                                       echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                                     }
                                   }
                                    ?>
                        </select>

                      </div>
                      </div>
                      </div>
                      <div class="col-xl-2">
                        <input required class="btn btn-primary" type="submit" name="delete_m_data" value="পরিবর্তন">

                        <?php
                        include 'config.php';
                        if (isset($_REQUEST['Paysubmit'])) {
                          $check_datap = $_REQUEST['check_data'];
                          $all_markedp = implode(",",$check_datap);
                          $queryp = "UPDATE parcel SET
                           p_Pay ='2'
                           WHERE parcel_id in ($all_markedp)";

                          $resultp = mysqli_query($connection,$queryp) or die("Query Faield.");
                           }
                         ?>
                        <form class="" action="" method="post">
                         <input class="btn btn-outline-black btn-icon" type="submit" name="Paysubmit" value="&#2547;">
                        </form>
          <?php } ?>
                      </div>
                      </div>
                      <!-- Multi Select -->
                   </div>

                   <div class="card-body">
                      <div class="datatable">




                         <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

          <?php
                               include 'config.php';
                               if ($_SESSION['role']== '5') {
                               $query = "SELECT * FROM parcel
                               LEFT JOIN services ON parcel.c_service = services.id
                               LEFT JOIN area ON parcel.c_area = area.id
                               LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                               LEFT JOIN action ON parcel.c_action = action.action_id
                               LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                               LEFT JOIN pay ON parcel.p_Pay = pay.payID
                               WHERE action.action_id = 9
                               ORDER BY parcel.parcel_id DESC";
                               }elseif ($_SESSION['role']== '1') {
                               $query = "SELECT * FROM parcel
                               LEFT JOIN services ON parcel.c_service = services.id
                               LEFT JOIN area ON parcel.c_area = area.id
                               LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                               LEFT JOIN action ON parcel.c_action = action.action_id
                               LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                               WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 9
                               ORDER BY parcel.parcel_id DESC";
                               }else {
                               ?>
                            <div class="container p-5">
                               <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                  <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                  </button>
                               </div>
                               <div class="alert alert-success" role="alert">
                                  <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                                  <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                                  <hr>
                                  <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                               </div>
                            </div>
                            <?php
                               die;
                               }
                              ?><?php
            break;
          case "/duePay.php":
          ?><?php ob_start(); ?>
          <?php $title = "পেমেন্ট ডিউ পার্সেল"; ?>
          <?php include 'menu.php';?>
          <script>
            window.onload=function(){
                  document.getElementById('loder').style.display="none";
                  document.getElementById('content').style.display="block";
            };
          </script>
          <style>
            #content {display: none;}
            #content img{width: 100%;}
            #loder{
              position: absolute;
              margin: auto;
              top: 0;
              right: 0;
              bottom: 0;
              left: 0;
              width: 300px;
              height: 300px;
            }
            #loder img{width: 300px;}
          </style>
          <div id="loder">
          <img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
          </div>

          <?php
             if (isset($_POST['submit'])) {
             include 'config.php';
           $query1 =   "UPDATE parcel SET
             c_hero ='{$_POST["c_hero"]}',
             c_action ='{$_POST["c_action"]}',
             weight ='{$_POST["weight"]}',
             c_charge ='{$_POST["c_charge"]}'
             WHERE parcel.parcel_id = {$_POST["pid"]};";

             if ($_POST["old_action"] != $_POST["c_action"]) {
               $query1 .= "UPDATE action  SET 	action_parcel= 	action_parcel - 1 WHERE action_id = {$_POST["old_action"]};";
               $query1 .= "UPDATE action  SET 	action_parcel= 	action_parcel + 1 WHERE action_id = {$_POST["c_action"]};";
               $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('{$_POST["pid"]}','{$_POST["c_action"]}','{$_SESSION["name"]}','{$_POST["c_hero"]}');";
             }
             if ($_POST["c_action"] == 5) {
               $query1 .= "UPDATE parcel SET
                 p_Pay ='1'
                 WHERE parcel.parcel_id = {$_POST["pid"]};";
             }else {
               $query1 .= "UPDATE parcel SET
                 p_Pay ='0'
                 WHERE parcel.parcel_id = {$_POST["pid"]};";
             }

          $result1 = mysqli_multi_query($connection,$query1) or die("ডাটা সেন্টার কানেক্ট হয়নি !".mysqli_error());
          if ($result1) {


          if ($_POST["c_action"] == 3) {

            $to = $_POST["c_number"];
            $token = "69a9e1162ef97e9cc0f314fe26475048";
            $message = "Hello  ".$_POST["c_name"]." ! We have received your parcel from ".$_POST["business"]." which payable amount ".$_POST["c_price"]." taka. We will deliver it very soon. Stay well.
          -Peon Courier Ltd.";


            $url = "http://api.greenweb.com.bd/api.php?json";


            $data= array(
            'to'=>"$to",
            'message'=>"$message",
            'token'=>"$token"
            ); // Add parameters in key value
            $ch = curl_init(); // Initialize cURL
            curl_setopt($ch, CURLOPT_URL,$url);
            curl_setopt($ch, CURLOPT_ENCODING, '');
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $smsresult = curl_exec($ch);

          }else if ($_POST["c_action"] == 4) {
                      $to = $_POST["c_number"];
                      $token = "69a9e1162ef97e9cc0f314fe26475048";
                      $message = "হ্যালো ".$_POST["c_name"]." ! ".$_POST["business"]." থেকে আপনার ক্রয়কৃত পার্সেলটি  , আমাদের একজন প্রতিনিধি আজকের ভিতর আপনার কাছে পৌছেঁ দিবেন ।
                    -Peon Courier Ltd.";


                      $url = "http://api.greenweb.com.bd/api.php?json";


                      $data= array(
                      'to'=>"$to",
                      'message'=>"$message",
                      'token'=>"$token"
                      ); // Add parameters in key value
                      $ch = curl_init(); // Initialize cURL
                      curl_setopt($ch, CURLOPT_URL,$url);
                      curl_setopt($ch, CURLOPT_ENCODING, '');
                      curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                      $smsresult = curl_exec($ch);

          }
          }
          }

             ?>
          <main id="content">
             <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                                 <div class="container-fluid">
                                     <div class="page-header-content">
                                         <div class="row align-items-center justify-content-between pt-3">
                                             <div class="col-auto mb-3">
                                             </div>
          <?php include 'submenu.php';?>
                                         </div>
                                     </div>
                                 </div>
                             </header>
                             <!-- Main page content-->
             <!-- Main page content-->
                           <form class="" action="" method="post">
             <div class="container">
                <div class="card mb-4">
                   <div class="card-header">


                      <!-- Multi Select -->
                      <div class="row">
                         <div class="col-xl-5">
                           <a title="নতুন একটি পার্সেল এড করুন" href="addParcel.php" class="btn btn-outline-primary btn-icon">
                           <i class="fas fa-plus-circle"></i>
                           </a>


                           <a title="নতুন বাল্ক ফাইল আপলোড করুন" href="addParcelcsv.php" class="btn btn-outline-primary btn-icon">
                           <i class="fas fa-file-csv"></i>
                           </a>
                           </div>
                         <div class="col-xl-5">
                           <div class="row">
                              <div class="col-xl-6">
                                <?php if ($_SESSION['role'] =='5') {?>
                      <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
                          <option selected value="">একটি স্টাটাস বাছুন</option>
                          <?php
                                 include 'config.php';
                                 $query_s = "SELECT * FROM action";
                                 $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                 if (mysqli_num_rows($result_s) > 0) {
                                   while ($row_S = mysqli_fetch_assoc($result_s)) {

                                     if ($row['c_action'] == $row_S['action_id']) {
                                       $selected = "selected";
                                     }else {
                                       $selected = "";
                                     }

                                     echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                                   }
                                 }
                                  ?>
                      </select>
                      </div>
                      <div class="col-xl-6">
                        <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
                            <option selected value="">একজন হিরো বাছুন</option>
                            <?php
                                   include 'config.php';
                                   $query_h = "SELECT * FROM hero";
                                   $result_h = mysqli_query($connection,$query_h)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                   if (mysqli_num_rows($result_h) > 0) {
                                     while ($row_h = mysqli_fetch_assoc($result_h)) {

                                       if ($row['c_hero'] == "2") {
                                         $selected = "selected";
                                       }else {
                                         $selected = "";
                                       }

                                       echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                                     }
                                   }
                                    ?>
                        </select>

                      </div>
                      </div>
                      </div>
                      <div class="col-xl-2">
                        <input required class="btn btn-primary" type="submit" name="delete_m_data" value="পরিবর্তন">

                        <?php
                        include 'config.php';
                        if (isset($_REQUEST['Paysubmit'])) {
                          $check_datap = $_REQUEST['check_data'];
                          $all_markedp = implode(",",$check_datap);
                          $queryp = "UPDATE parcel SET
                           p_Pay ='2'
                           WHERE parcel_id in ($all_markedp)";

                          $resultp = mysqli_query($connection,$queryp) or die("Query Faield.");
                           }
                         ?>
                        <form class="" action="" method="post">
                         <input class="btn btn-outline-black btn-icon" type="submit" name="Paysubmit" value="&#2547;">
                        </form>
          <?php } ?>
                      </div>
                      </div>
                      <!-- Multi Select -->
                   </div>

                   <div class="card-body">
                      <div class="datatable">

          <?php
          include 'config.php';
          if (isset($_REQUEST['delete_m_data'])) {
            $c_heros = $_REQUEST['c_heros'];
            $c_actions = $_REQUEST['c_actions'];
            $check_data = $_REQUEST['check_data'];
            $all_marked = implode(",",$check_data);

            $query = "UPDATE parcel SET
             c_action = '$c_actions',
             c_hero = '$c_heros'
             WHERE parcel_id in ($all_marked);";

             if ($c_actions == 5) {
               $query .= "UPDATE parcel SET
                 p_Pay ='1'
                  WHERE parcel_id in ($all_marked);";
             }else {
               $query .= "UPDATE parcel SET
                 p_Pay ='0'
                 WHERE parcel_id in ($all_marked);";
             }

               $ALLDATAS = $_REQUEST['check_data'];
               if ($ALLDATAS) {
                 foreach ($ALLDATAS as $c) {
                   $query .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('".mysqli_real_escape_string($connection,$c)."','$c_actions','{$_SESSION["name"]}','$c_heros');";
                 }


            $result = mysqli_multi_query($connection,$query) or die("Query Faield.");

             }
               }
           ?>




                         <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

          <?php
                               include 'config.php';
                               if ($_SESSION['role']== '5') {
                               $query = "SELECT * FROM parcel
                               LEFT JOIN services ON parcel.c_service = services.id
                               LEFT JOIN area ON parcel.c_area = area.id
                               LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                               LEFT JOIN action ON parcel.c_action = action.action_id
                               LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                               LEFT JOIN pay ON parcel.p_Pay = pay.payID
                               WHERE pay.payID = 1
                               ORDER BY parcel.parcel_id DESC";
                               }elseif ($_SESSION['role']== '1') {
                               $query = "SELECT * FROM parcel
                               LEFT JOIN services ON parcel.c_service = services.id
                               LEFT JOIN area ON parcel.c_area = area.id
                               LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                               LEFT JOIN action ON parcel.c_action = action.action_id
                               LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                               LEFT JOIN pay ON parcel.p_Pay = pay.payID
                               WHERE parcel.c_m_business = {$_SESSION['id']} and pay.payID = 1
                               ORDER BY parcel.parcel_id DESC";
                               }else {
                               ?>
                            <div class="container p-5">
                               <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                  <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                  </button>
                               </div>
                               <div class="alert alert-success" role="alert">
                                  <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                                  <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                                  <hr>
                                  <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                               </div>
                            </div>
                            <?php
                               die;
                               }
                              ?><?php
            break;
          case "/Paid.php":
          ?><?php ob_start();
          $title = "পেমেন্ট সম্পন্ন";
           include 'menu.php';?>
          <script>
            window.onload=function(){
                  document.getElementById('loder').style.display="none";
                  document.getElementById('content').style.display="block";
            };
          </script>
          <style>
            #content {display: none;}
            #content img{width: 100%;}
            #loder{
              position: absolute;
              margin: auto;
              top: 0;
              right: 0;
              bottom: 0;
              left: 0;
              width: 300px;
              height: 300px;
            }
            #loder img{width: 300px;}
          </style>
          <div id="loder">
          <img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
          </div>

          <?php
             if (isset($_POST['submit'])) {
             include 'config.php';
           $query1 =   "UPDATE parcel SET
             c_hero ='{$_POST["c_hero"]}',
             c_action ='{$_POST["c_action"]}',
             weight ='{$_POST["weight"]}',
             c_charge ='{$_POST["c_charge"]}'
             WHERE parcel.parcel_id = {$_POST["pid"]};";

             if ($_POST["old_action"] != $_POST["c_action"]) {
               $query1 .= "UPDATE action  SET 	action_parcel= 	action_parcel - 1 WHERE action_id = {$_POST["old_action"]};";
               $query1 .= "UPDATE action  SET 	action_parcel= 	action_parcel + 1 WHERE action_id = {$_POST["c_action"]};";
               $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('{$_POST["pid"]}','{$_POST["c_action"]}','{$_SESSION["name"]}','{$_POST["c_hero"]}');";
             }
             if ($_POST["c_action"] == 5) {
               $query1 .= "UPDATE parcel SET
                 p_Pay ='1'
                 WHERE parcel.parcel_id = {$_POST["pid"]};";
             }else {
               $query1 .= "UPDATE parcel SET
                 p_Pay ='0'
                 WHERE parcel.parcel_id = {$_POST["pid"]};";
             }

          $result1 = mysqli_multi_query($connection,$query1) or die("ডাটা সেন্টার কানেক্ট হয়নি !".mysqli_error());
          if ($result1) {


          if ($_POST["c_action"] == 3) {

            $to = $_POST["c_number"];
            $token = "69a9e1162ef97e9cc0f314fe26475048";
            $message = "Hello  ".$_POST["c_name"]." ! We have received your parcel from ".$_POST["business"]." which payable amount ".$_POST["c_price"]." taka. We will deliver it very soon. Stay well.
          -Peon Courier Ltd.";


            $url = "http://api.greenweb.com.bd/api.php?json";


            $data= array(
            'to'=>"$to",
            'message'=>"$message",
            'token'=>"$token"
            ); // Add parameters in key value
            $ch = curl_init(); // Initialize cURL
            curl_setopt($ch, CURLOPT_URL,$url);
            curl_setopt($ch, CURLOPT_ENCODING, '');
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $smsresult = curl_exec($ch);

          }else if ($_POST["c_action"] == 4) {
                      $to = $_POST["c_number"];
                      $token = "69a9e1162ef97e9cc0f314fe26475048";
                      $message = "হ্যালো ".$_POST["c_name"]." ! ".$_POST["business"]." থেকে আপনার ক্রয়কৃত পার্সেলটি  , আমাদের একজন প্রতিনিধি আজকের ভিতর আপনার কাছে পৌছেঁ দিবেন ।
                    -Peon Courier Ltd.";


                      $url = "http://api.greenweb.com.bd/api.php?json";


                      $data= array(
                      'to'=>"$to",
                      'message'=>"$message",
                      'token'=>"$token"
                      ); // Add parameters in key value
                      $ch = curl_init(); // Initialize cURL
                      curl_setopt($ch, CURLOPT_URL,$url);
                      curl_setopt($ch, CURLOPT_ENCODING, '');
                      curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                      $smsresult = curl_exec($ch);

          }
          }
          }

             ?>
          <main id="content">
             <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                                 <div class="container-fluid">
                                     <div class="page-header-content">
                                         <div class="row align-items-center justify-content-between pt-3">
                                             <div class="col-auto mb-3">
                                             </div>
          <?php include 'submenu.php';?>
                                         </div>
                                     </div>
                                 </div>
                             </header>
                             <!-- Main page content-->
             <!-- Main page content-->
                           <form class="" action="" method="post">
             <div class="container">
                <div class="card mb-4">
                   <div class="card-header">


                      <!-- Multi Select -->
                      <div class="row">
                         <div class="col-xl-5">
                           <a title="নতুন একটি পার্সেল এড করুন" href="addParcel.php" class="btn btn-outline-primary btn-icon">
                           <i class="fas fa-plus-circle"></i>
                           </a>


                           <a title="নতুন বাল্ক ফাইল আপলোড করুন" href="addParcelcsv.php" class="btn btn-outline-primary btn-icon">
                           <i class="fas fa-file-csv"></i>
                           </a>
                           </div>
                         <div class="col-xl-5">
                           <div class="row">
                              <div class="col-xl-6">
                                <?php if ($_SESSION['role'] =='5') {?>
                      <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
                          <option selected value="">একটি স্টাটাস বাছুন</option>
                          <?php
                                 include 'config.php';
                                 $query_s = "SELECT * FROM action";
                                 $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                 if (mysqli_num_rows($result_s) > 0) {
                                   while ($row_S = mysqli_fetch_assoc($result_s)) {

                                     if ($row['c_action'] == $row_S['action_id']) {
                                       $selected = "selected";
                                     }else {
                                       $selected = "";
                                     }

                                     echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                                   }
                                 }
                                  ?>
                      </select>
                      </div>
                      <div class="col-xl-6">
                        <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
                            <option selected value="">একজন হিরো বাছুন</option>
                            <?php
                                   include 'config.php';
                                   $query_h = "SELECT * FROM hero";
                                   $result_h = mysqli_query($connection,$query_h)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                   if (mysqli_num_rows($result_h) > 0) {
                                     while ($row_h = mysqli_fetch_assoc($result_h)) {

                                       if ($row['c_hero'] == "2") {
                                         $selected = "selected";
                                       }else {
                                         $selected = "";
                                       }

                                       echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                                     }
                                   }
                                    ?>
                        </select>

                      </div>
                      </div>
                      </div>
                      <div class="col-xl-2">
                        <input required class="btn btn-primary" type="submit" name="delete_m_data" value="পরিবর্তন">

                        <?php
                        include 'config.php';
                        if (isset($_REQUEST['Paysubmit'])) {
                          $check_datap = $_REQUEST['check_data'];
                          $all_markedp = implode(",",$check_datap);
                          $queryp = "UPDATE parcel SET
                           p_Pay ='2'
                           WHERE parcel_id in ($all_markedp)";

                          $resultp = mysqli_query($connection,$queryp) or die("Query Faield.");
                           }
                         ?>
                        <form class="" action="" method="post">
                         <input class="btn btn-outline-black btn-icon" type="submit" name="Paysubmit" value="&#2547;">
                        </form>
          <?php } ?>
                      </div>
                      </div>
                      <!-- Multi Select -->
                   </div>

                   <div class="card-body">
                      <div class="datatable">

          <?php
          include 'config.php';
          if (isset($_REQUEST['delete_m_data'])) {
            $c_heros = $_REQUEST['c_heros'];
            $c_actions = $_REQUEST['c_actions'];
            $check_data = $_REQUEST['check_data'];
            $all_marked = implode(",",$check_data);

            $query = "UPDATE parcel SET
             c_action = '$c_actions',
             c_hero = '$c_heros'
             WHERE parcel_id in ($all_marked);";

             if ($c_actions == 5) {
               $query .= "UPDATE parcel SET
                 p_Pay ='1'
                  WHERE parcel_id in ($all_marked);";
             }else {
               $query .= "UPDATE parcel SET
                 p_Pay ='0'
                 WHERE parcel_id in ($all_marked);";
             }

               $ALLDATAS = $_REQUEST['check_data'];
               if ($ALLDATAS) {
                 foreach ($ALLDATAS as $c) {
                   $query .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('".mysqli_real_escape_string($connection,$c)."','$c_actions','{$_SESSION["name"]}','$c_heros');";
                 }


            $result = mysqli_multi_query($connection,$query) or die("Query Faield.");

             }
               }
           ?>




                         <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

          <?php
                               include 'config.php';
                               if ($_SESSION['role']== '5') {
                               $query = "SELECT * FROM parcel
                               LEFT JOIN services ON parcel.c_service = services.id
                               LEFT JOIN area ON parcel.c_area = area.id
                               LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                               LEFT JOIN action ON parcel.c_action = action.action_id
                               LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                               LEFT JOIN pay ON parcel.p_Pay = pay.payID
                               WHERE pay.payID = 2
                               ORDER BY parcel.parcel_id DESC";
                               }elseif ($_SESSION['role']== '1') {
                               $query = "SELECT * FROM parcel
                               LEFT JOIN services ON parcel.c_service = services.id
                               LEFT JOIN area ON parcel.c_area = area.id
                               LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                               LEFT JOIN action ON parcel.c_action = action.action_id
                               LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                               LEFT JOIN pay ON parcel.p_Pay = pay.payID
                               WHERE parcel.c_m_business = {$_SESSION['id']} and pay.payID = 2
                               ORDER BY parcel.parcel_id DESC";
                               }else {
                               ?>
                            <div class="container p-5">
                               <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                  <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                  </button>
                               </div>
                               <div class="alert alert-success" role="alert">
                                  <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                                  <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                                  <hr>
                                  <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                               </div>
                            </div>
                            <?php
                               die;
                               }
                              ?><?php
            break;
            case "/AllCancel.php":
            ?><?php ob_start(); ?>
            <?php $title = "ক্যানসেল পার্সেল"; ?>
            <?php include 'menu.php';?>
            <script>
              window.onload=function(){
                    document.getElementById('loder').style.display="none";
                    document.getElementById('content').style.display="block";
              };
            </script>
            <style>
              #content {display: none;}
              #content img{width: 100%;}
              #loder{
                position: absolute;
                margin: auto;
                top: 0;
                right: 0;
                bottom: 0;
                left: 0;
                width: 300px;
                height: 300px;
              }
              #loder img{width: 300px;}
            </style>
            <div id="loder">
            <img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
            </div>
            <?php
            include 'config.php';
            if (isset($_REQUEST['delete_m_data'])) {
              $c_heros = $_REQUEST['c_heros'];
              $c_actions = $_REQUEST['c_actions'];
              $check_data = $_REQUEST['check_data'];
              $all_marked = implode(",",$check_data);

              $query = "UPDATE parcel SET
               c_action = '$c_actions',
               c_hero = '$c_heros'
               WHERE parcel_id in ($all_marked);";

               if ($c_actions == 5) {
                 $query .= "UPDATE parcel SET
                   p_Pay ='1'
                    WHERE parcel_id in ($all_marked);";
               }else {
                 $query .= "UPDATE parcel SET
                   p_Pay ='0'
                   WHERE parcel_id in ($all_marked);";
               }

                 $ALLDATAS = $_REQUEST['check_data'];
                 if ($ALLDATAS) {
                   foreach ($ALLDATAS as $c) {
                     $query .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE ('".mysqli_real_escape_string($connection,$c)."','$c_actions','{$_SESSION["name"]}','$c_heros');";
                   }


              $result = mysqli_multi_query($connection,$query) or die("Query Faield.");

               }
                 }
             ?>


            <main id="content">
               <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                                   <div class="container-fluid">
                                       <div class="page-header-content">
                                           <div class="row align-items-center justify-content-between pt-3">
                                               <div class="col-auto mb-3">
                                               </div>
            <?php include 'submenu.php';?>
                                           </div>
                                       </div>
                                   </div>
                               </header>
                               <!-- Main page content-->
               <!-- Main page content-->
                             <form class="" action="" method="post">
               <div class="container">
                  <div class="card mb-4">
                     <div class="card-header">


                        <!-- Multi Select -->
                        <div class="row">
                           <div class="col-xl-5">
                             <a title="নতুন একটি পার্সেল এড করুন" href="addParcel.php" class="btn btn-outline-primary btn-icon">
                             <i class="fas fa-plus-circle"></i>
                             </a>


                             <a title="নতুন বাল্ক ফাইল আপলোড করুন" href="addParcelcsv.php" class="btn btn-outline-primary btn-icon">
                             <i class="fas fa-file-csv"></i>
                             </a>
                             <a title="বাল্ক ফাইল ডাউনলোড করুন" href="X2!dswsDsfb.php?idDFsdfgxcgvbdgrgdxfbdtgbrtxb=10" class="btn btn-outline-dark btn-icon">
                             <i class="fas fa-arrow-circle-down"></i>
                             </a>
                             </div>
                           <div class="col-xl-5">
                             <div class="row">
                                <div class="col-xl-6">
                                  <?php if ($_SESSION['role'] =='5') {?>
                        <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
                            <option selected value="">একটি স্টাটাস বাছুন</option>
                            <?php
                                   include 'config.php';
                                   $query_s = "SELECT * FROM action";
                                   $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                   if (mysqli_num_rows($result_s) > 0) {
                                     while ($row_S = mysqli_fetch_assoc($result_s)) {

                                       if ($row['c_action'] == $row_S['action_id']) {
                                         $selected = "selected";
                                       }else {
                                         $selected = "";
                                       }

                                       echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                                     }
                                   }
                                    ?>
                        </select>
                        </div>
                        <div class="col-xl-6">
                          <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
                              <option selected value="">একজন হিরো বাছুন</option>
                              <?php
                                     include 'config.php';
                                     $query_h = "SELECT * FROM hero";
                                     $result_h = mysqli_query($connection,$query_h)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                     if (mysqli_num_rows($result_h) > 0) {
                                       while ($row_h = mysqli_fetch_assoc($result_h)) {

                                         if ($row['c_hero'] == "2") {
                                           $selected = "selected";
                                         }else {
                                           $selected = "";
                                         }

                                         echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                                       }
                                     }
                                      ?>
                          </select>

                        </div>
                        </div>
                        </div>
                        <div class="col-xl-2">
                          <input required class="btn btn-primary" type="submit" name="delete_m_data" value="পরিবর্তন">

                          <?php
                          include 'config.php';
                          if (isset($_REQUEST['Paysubmit'])) {
                            $check_datap = $_REQUEST['check_data'];
                            $all_markedp = implode(",",$check_datap);
                            $queryp = "UPDATE parcel SET
                             p_Pay ='2'
                             WHERE parcel_id in ($all_markedp)";

                            $resultp = mysqli_query($connection,$queryp) or die("Query Faield.");
                             }
                           ?>
                          <form class="" action="" method="post">
                           <input class="btn btn-outline-black btn-icon" type="submit" name="Paysubmit" value="&#2547;">
                          </form>
            <?php } ?>
                        </div>
                        </div>
                        <!-- Multi Select -->
                     </div>

                     <div class="card-body">
                        <div class="datatable">





                           <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

                              <?php
                                 include 'config.php';
                                 if ($_SESSION['role']== '5') {
                                 $query = "SELECT * FROM parcel
                                 LEFT JOIN services ON parcel.c_service = services.id
                                 LEFT JOIN area ON parcel.c_area = area.id
                                 LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                                 LEFT JOIN action ON parcel.c_action = action.action_id
                                 LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                                 WHERE action.action_id = 10
                                 ORDER BY parcel.parcel_id DESC limit 200";
                                 }elseif ($_SESSION['role']== '1') {
                                 $query = "SELECT * FROM parcel
                                 LEFT JOIN services ON parcel.c_service = services.id
                                 LEFT JOIN area ON parcel.c_area = area.id
                                 LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                                 LEFT JOIN action ON parcel.c_action = action.action_id
                                 LEFT JOIN hero ON parcel.c_hero = hero.hero_id
                                 WHERE parcel.c_m_business = {$_SESSION['id']}  and action.action_id = 9
                                 ORDER BY parcel.parcel_id DESC";
                                 }else {
                                 ?>
                              <div class="container p-5">
                                 <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                 </div>
                                 <div class="alert alert-success" role="alert">
                                    <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                                    <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                                    <hr>
                                    <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                                 </div>
                              </div>
                              <?php
                                 die;
                                 }
                                 $result = mysqli_query($connection,$query) or die("Query Faield.");
                                 $count = mysqli_num_rows($result);
                                 ?>
                              <thead>


                                 <tr>
                                   <?php if ($_SESSION['role'] =='5') {?>
                                    <th><i class="fas fa-clipboard-check"></i></th>
                                  <?php } ?>
                                    <th>আইডি</th>
                                    <th>প্রেরক</th>
                                    <th>প্রাপক</th>
                                    <th>নোট</th>
                                    <th>স্টাটাস</th>
                                    <th>অ্যাকশান</th>
                                 </tr>
                              </thead>
                              <tfoot>
                                 <tr>
                                   <?php if ($_SESSION['role'] =='5') {?>
                                    <th><i class="fas fa-clipboard-check"></i></th>
                                  <?php } ?>
                                    <th>আইডি</th>
                                    <th>প্রেরক</th>
                                    <th>প্রাপক</th>
                                    <th>নোট</th>
                                    <th>স্টাটাস</th>
                                    <th>অ্যাকশান</th>
                                 </tr>
                              </tfoot>
                              <tbody>
                                 <?php
                                    if ($count>0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                      ?>
                                 <tr>
                                   <?php if ($_SESSION['role'] =='5') {?>
                                    <td class="th-sm">
                                      <input type="hidden" name="businesss" value="<?php echo $row['business']; ?>">
                                      <input type="hidden" name="c_prices" value="<?php echo $row['c_price']; ?>">
                                      <input type="hidden" name="c_names" value="<?php echo $row['c_name']; ?>">
                                      <label class="checkbox path">
                                             <input type="checkbox" name="check_data[]"  value="<?php echo $row['parcel_id']; ?>">
                                             <svg viewBox="0 0 21 21">
                                                 <path d="M5,10.75 L8.5,14.25 L19.4,2.3 C18.8333333,1.43333333 18.0333333,1 17,1 L4,1 C2.35,1 1,2.35 1,4 L1,17 C1,18.65 2.35,20 4,20 L17,20 C18.65,20 20,18.65 20,17 L20,7.99769186"></path>
                                             </svg>
                                         </label>
                                    </td>
                                  <?php } ?>
                                    <td class="th-sm">
                                      <?php
                                      if ($row['trId']=="") {
                                        echo "<span class='text-green'>PEON786592". $row['parcel_id']."</span><br>";
                                      }else {
                                        echo "<span class='text-green'>". $row['trId']."</span><br>";
                                      }
                                       ?><br>
                                       M.Inv:<?php echo $row['c_Inv']; ?><br>
                                       <?php echo $row['Ptime']; ?> <br>
                                       <?php echo $row['Pdate']; ?>

                                    </td>
                                    <td class="th-sm cb">
                                       <?php echo $row['business']; ?> <br>
                                       <?php echo $row['number']; ?>  <br>
                                       <?php echo $row['address']; ?>
                                       <div class="row ">
                                          <div class="col-md-12">
                                             <div class="row">
                                                <div class="col-md-6">
                                                   <span class="text-green font-weight-900"> ওজন: <?php echo $row['weight']; ?> কেজি</span>
                                                </div>
                                                <div class="col-md-6">
                                                   <span class="text-green font-weight-900">
                                                      চার্জ:  <?php

                                                    echo $row['c_charge'];

                                                       ?> &#2547;

                                                    </span>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </td>
                                    <td class="th-sm cb">
                                       <?php echo $row['c_name'];?> <br>
                                       <?php echo $row['c_number']; ?>,  <?php echo $row['c_b_number']; ?>  <br>
                                       <?php echo $row['c_address']; ?>
                                       <span class="text font-weight-900"> এরিয়া: <?php echo $row['area_name']; ?></span>
                                       <div class="row ">
                                          <div class="col-md-12">
                                             <span class="text-green font-weight-900"> ক্যাশ কালেকশান: <?php echo $row['c_price']; ?> &#2547;</span>
                                          </div>
                                       </div>
                                    </td>
                                    <td class="th-sm cbNote">
                                    <?php echo $row['note'];?>
                                    </td>
                                    <td>
                                       <?php
                                          if ($row['c_action']==1) {
                                              echo "<div class='badge badge-danger badge-pill'>".$row['action_name']."</div>";
                                          }
                                          else if($row['c_action']==2){
                                              echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                                          }
                                          else if($row['c_action']==3){
                                              echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                                          }
                                          else if($row['c_action']==4){
                                              echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                                          }
                                          else if($row['c_action']==5){
                                              echo "<div class='badge badge-green badge-pill'>".$row['action_name']."</div>";
                                          }
                                          else if($row['c_action']==6){
                                              echo "<div class='badge badge-dark badge-pill'>".$row['action_name']."</div>";
                                          }
                                          else if($row['c_action']==7){
                                              echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                                          }
                                          else if($row['c_action']==8){
                                              echo "<div class='badge badge-dark badge-pill'>".$row['action_name']."</div>";
                                          }
                                          else {
                                            echo "<div class='badge badge-warning badge-pill'>".$row['action_name']."</div>";
                                          }
                                          ?>
                                       <br>
                                       <?php
                                          if ($row['c_service']==1) {
                                              echo "<div class='badge badge-orange badge-pill'>".$row['sName']."</div>";
                                          }
                                          else if($row['c_service']==2){
                                              echo "<div class='badge badge-primary badge-pill'>".$row['sName']."</div>";
                                          }
                                          else {
                                            echo "<div class='badge badge-warning badge-pill'>".$row['sName']."</div>";
                                          }
                                          ?>
                                          <?php if ($_SESSION['role'] =='5') {?>
                                          <br>
                                          <div class="bg-light rounded mt-2"><?php echo $row['hero_name'];?></div>
                                        <?php } ?>
                                    </td>
                                    <td>
                                         <?php if ($_SESSION['role'] =='5') {?>
               <button href="view_merchant.php?id=<?php echo $row['id']; ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="dropdownFadeInUp<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm">
                 <i data-feather="more-vertical"></i>
               </button>
             <?php } ?>
            <div class="dropdown-menu animated--fade-in-up" aria-labelledby="dropdownFadeInUp<?php echo $row['parcel_id'];?>">
              <!-- Delete Dropdown Button -->
            <a data-toggle="modal" data-target="#exampleModalSm<?php echo $row['parcel_id']; ?>" class="dropdown-item text-danger" >ডিলিট</a>

                <!-- Delete Dropdown Button -->
                                       </div>
                                       <!-- Small modal -->
                                       <div class="modal fade" id="exampleModalSm<?php echo $row['parcel_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                          <div class="modal-dialog modal-sm" role="document">
                                             <div class="modal-content">
                                                <div class="modal-header">
                                                   <h5 class="modal-title">গুরুত্বপূর্ণ ব্যাপার</h5>
                                                   <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                                </div>
                                                <div class="modal-body">
                                                   <p>আপনি কি PEON00<?php echo $row['parcel_id']; ?> পার্সেল ডিলিট করতে চাচ্ছেন?</p>
                                                </div>
                                                <div class="modal-footer">
                                                   <button class="btn btn-primary" type="button" data-dismiss="modal">না! থাক</button>
                               <a class="btn btn-danger" type="button" href="delete_parcel.php?MasRiaKib=<?php echo $row['parcel_id']; ?>">ডিলিট</a>
                                                </div>
                                             </div>
                                          </div>
                                       </div>

                                       <a href="viewParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="fas fa-eye"></i></a>
                                          <?php if ($_SESSION['role'] =='5') {?>
                                       <a target="_blank" href="updateParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="far fa-edit"></i></a>
                                     <?php } ?>
                                       <a class="btn btn-outline-primary btn-icon btn-sm" target="_blank" href="print_parcel.php?id=<?php echo $row['parcel_id']; ?>"><i class="fas fa-print"></i></a>






                                    </td>
                                 </tr>
                                 <?php } ?>
                              </tbody>
                              <?php } ?>
                           </table>

                         </form>
                        </div>
                     </div>
                  </div>
               </div>
            </main><?php
            break;
  default:
    echo "Err 36200";
}
?>