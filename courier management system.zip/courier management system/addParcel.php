<?php ob_start(); ?>
<?php $title = "Parcel Addition"; ?>
<?php include 'menu.php';
// Auto ID Genaretor
$all_keys = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y'
  ,'Z','1','2','3','4','5','6','7','8','9','0');
$rendomKey = "";
for ($i=0; $i < 3; $i++) {
  shuffle($all_keys);
 $rendomKey .= $all_keys[0];
}
date_default_timezone_set("Asia/Dhaka");
 $houre = date("h");
 $month = date("m");
 $date = date("d");
 $secnd = date("i");
$trId=   "P".$rendomKey.$month.$date.$houre.$secnd;

// Auto ID Genaretor
date_default_timezone_set("Asia/Dhaka");
$Ptime = strtoupper(date("h:i:s a"));
$Pdate = strtoupper(date("d M y"));
?>

<?php
   if (isset($_POST['submit'])) {
   include 'config.php';
   $c_Inv = mysqli_real_escape_string($connection,$_POST['c_Inv']);
   $c_name = mysqli_real_escape_string($connection,$_POST['c_name']);
   $c_number = mysqli_real_escape_string($connection,$_POST['c_number']);
   $c_b_number = mysqli_real_escape_string($connection,$_POST['c_b_number']);
   $c_address = mysqli_real_escape_string($connection,$_POST['c_address']);
   $c_service = mysqli_real_escape_string($connection,$_POST['c_service']);
   $c_area = mysqli_real_escape_string($connection,$_POST['c_area']);
   $c_price = mysqli_real_escape_string($connection,$_POST['c_price']);
   $weight = mysqli_real_escape_string($connection,$_POST['weight']);
   $action = mysqli_real_escape_string($connection,$_POST['action']);
   $note = mysqli_real_escape_string($connection,$_POST['note']);

     $c_m_business = "";

     if ($_SESSION['role'] =='1') {
        $c_m_business = $_SESSION['id'];
     }else if ($_SESSION['role'] =='5') {
     $c_m_business = $_POST["merchant"];
     }
     //Service Price
include 'charge.php';


   $query1 = "INSERT INTO parcel (c_Inv,trId,c_name,c_number,c_b_number,c_address,c_service,c_area,c_price,c_charge,weight,c_m_business,Ptime,Pdate,c_action,note)
   VALUE ('$c_Inv','$trId','$c_name','$c_number','$c_b_number','$c_address','$c_service','$c_area','$c_price','$cost','$weight','$c_m_business','$Ptime','$Pdate','$action','$note');";

   $query1 .= "UPDATE action  SET action_parcel = action_parcel + 1 WHERE action_id = '$action';";
   $query1 .= "UPDATE services  SET sParcel = sParcel + 1 WHERE id = '$c_service';";


if (mysqli_multi_query($connection,$query1 )) {
header('location: addParcel.php');
bo_enf_fluch();
}else {
echo " ERROR";
}

}

   ?>

  <?php ob_start(); ?>
   <?php
      if (isset($_POST['submitre'])) {
      include 'config.php';
      $c_Inv = mysqli_real_escape_string($connection,$_POST['c_Inv']);
      $c_name = mysqli_real_escape_string($connection,$_POST['c_name']);
      $c_number = mysqli_real_escape_string($connection,$_POST['c_number']);
      $c_b_number = mysqli_real_escape_string($connection,$_POST['c_b_number']);
      $c_address = mysqli_real_escape_string($connection,$_POST['c_address']);
      $c_service = mysqli_real_escape_string($connection,$_POST['c_service']);
      $c_area = mysqli_real_escape_string($connection,$_POST['c_area']);
      $c_price = mysqli_real_escape_string($connection,$_POST['c_price']);
      $weight = mysqli_real_escape_string($connection,$_POST['weight']);
      $action = mysqli_real_escape_string($connection,$_POST['action']);
      $note = mysqli_real_escape_string($connection,$_POST['note']);
      $c_m_business = "";

      if ($_SESSION['role'] =='1') {
         $c_m_business = $_SESSION['id'];
      }else if ($_SESSION['role'] =='5') {
      $c_m_business = $_POST["merchant"];
      }
      //Service Price
 include 'charge.php';



      $query1 = "INSERT INTO parcel (c_Inv,trId,c_name,c_number,c_b_number,c_address,c_service,c_area,c_price,c_charge,weight,c_m_business,Ptime,Pdate,c_action,note)
      VALUE ('$c_Inv','$trId','$c_name','$c_number','$c_b_number','$c_address','$c_service','$c_area','$c_price','$cost','$weight','$c_m_business','$Ptime','$Pdate','$action','$note');";

      $query1 .= "UPDATE action  SET action_parcel = action_parcel + 1 WHERE action_id = '$action';";
      $query1 .= "UPDATE services  SET sParcel = sParcel + 1 WHERE id = '$c_service'";

   if (mysqli_multi_query($connection,$query1 )) {
   header('location: parcel.php');
   bo_enf_fluch();
   }else {
   echo "ERROR";
   }

   }

      ?>




<main>
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
      <div class="container-fluid">
         <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
               <div class="col-auto mb-3">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i class="fas fa-box-open"></i></div>
                    Parcel | New parcel <a href="addParcelcsv.php" class="btn btn-outline-primary rounded-pill mr-2 my-1 btn-sm ml-5"><i class=" mr-2 fas fa-file-csv"></i>Bulk upload</a>
                  </h1>

               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- Main page content-->
   <div class="container mt-4">
<?php
$num1 = 13;
$num2 = 24;
date_default_timezone_set("Asia/Dhaka");
$date = date("G");


if (($date >= $num1) and ($date <= $num2) ) {
  echo "   <div class='alert alert-green alert-dismissible fade show' role='alert'>
      <h5 class='alert-heading'>Welcome for New Parcel Entry!</h5>
    All parcels entered after 1 pm, will be picked up tomorrow !
      <button class='close' type='button' data-dismiss='alert' aria-label='Close'>
          <span aria-hidden='true'>×</span>
      </button>
  </div>";
}else {
  echo "";
}

$time = 24 > 3;



 ?>




   <div class="row">
      <div class="col-xl-6">
         <!-- Account details card-->
         <div class="card-header">Customer information</div>
         <div class="card card-waves">
            <div class="card-body">
              <form class="" action="addParcel.php" method="POST" autocomplete="off">

                <div class="form-row">
                   <!-- Form Group (name)-->
                   <div class="form-group col-md-4">
                      <label  class="small mb-1" for="inputFirstNameinv">Merchant Invoice No.</label>
                      <input  name="c_Inv" class="form-control" id="inputFirstNameinv" type="text" placeholder="Merchant invoice no"/>
                   </div>
                   <!-- Form Group (Moble)-->
                   <div class="form-group col-md-8">
                      <label class="small mb-1" for="inputLastNamecname">Customer Name <span class="text-red font-weight-900"> *</span></label>
                      <input required name="c_name" class="form-control" id="inputLastNamecname" type="text" placeholder="Customer's full name"/>
                   </div>
                </div>
                  <!-- Content -->
                <div class="form-row">
                   <!-- Form Group (name)-->
                   <div class="form-group col-md-6">
                      <label class="small mb-1" for="inputFirstNamenumber">Mobile number<span class="text-red font-weight-900"> *</span></label>
                      <input required type="text" minlength="11" maxlength="11" name="c_number" class="form-control"  placeholder="Customer's Mobile number" />
                   </div>
                   <!-- Form Group (Moble)-->
                   <div class="form-group col-md-6">
                      <label class="small mb-1" for="inputLastNamebk_number">Alternate mobile number(if)</label>
                      <input minlength="11" maxlength="11" name="c_b_number" class="form-control" id="inputLastNamebk_number" type="text" placeholder=" Customer's Alternate mobile number"/>
                   </div>
                </div>


                  <!-- Content -->
                <div class="form-row">
                   <!-- Form Group (name)-->
                   <div class="form-group col-md-4">
                      <label class="small " for="inputFirstNames_price">Cash collection<span class="text-red font-weight-900"> *</span></label>
                      <input oninput='myNewFunction(this.value)' required name="c_price" class="form-control" id="" type="number" placeholder="Cash collection" />
                   </div>
                   <!-- Form Group (Moble)-->
                   <div class="form-group col-md-8">

                     <label for="exampleFormControlSelect1WT">Weight (within 1 to 10 kg)<span class="text-red font-weight-900"> *</span></label>
                       <input oninput='myFunction(this.value)' required min="1" max="10" name="weight" class="form-control" id='input_tag' type="number" placeholder="Kg" />
                   </div>
                </div>



                <div class="form-group">
                  <label for="exampleFormControlTextareaADDR">Full address<span class="text-red font-weight-900"> *</span></label>
                  <textarea required name="c_address" class="form-control" id="exampleFormControlTextareaADDR" rows="2"></textarea>
                  <input type="hidden" name="action"class="form-control mb-3"  value="1">
                </div>
                  <!-- Content -->
            </div>
          </div>
          <!-- Account details card-->
        </div>
      <div class="col-xl-6">
         <!-- Account details card-->
         <div class="card-header">Service information</div>
         <div class="card card-waves">
            <div class="card-body">





<!-- Calculator -->
              <div class="row alert alert-dark">
                 <div  class="col-xl-4">
                   Charge: <span id="charge">00</span> ৳
                 </div>
                 <div  class="col-xl-4">
                   Payable: <span id="payable">00</span> ৳
                 </div>
                 <div  class="col-xl-4">
                   COD charge: <span id="codcharge">00</span> ৳
                 </div>
                 </div>
<!-- Calculator -->




              <div class="row">
                 <div class="col-xl-6">
              <label for="exampleFormControlSelectservices">Service
                <span class="text-red font-weight-900"> *</span></label><a href="pricing.php" class="pl-1 text-blue-50 text-xs">See charge</a>
              <select  id='serviceOption' required name="c_service" class="form-control js-example-responsive">
                <option value="" disabled selected>Select a service</option>

                <?php
                        include 'config.php';
                        $query_s = "SELECT * FROM services";
                        $result_s = mysqli_query($connection,$query_s)or die("ERROR");

                        if (mysqli_num_rows($result_s) > 0) {
                          while ($row_S = mysqli_fetch_assoc($result_s)) {
                            echo "<option id='rt' value='{$row_S['id']}'>{$row_S['sName']}</option>";
                          }
                        }
                         ?>
               </select>
             </div>
             <div class="col-xl-6">

             <label for="exampleFormControlSelectarea">Area</label>
             <a href="#" class="pl-1 text-blue-50 text-xs"> See Area </a>
             <select name="c_area" class=" form-control" >
               <option disabled selected> Select an area </option>
               <?php
                                     include 'config.php';
                                     $query_s = "SELECT * FROM area";
                                     $result_s = mysqli_query($connection,$query_s)or die("ERROR");

                                     if (mysqli_num_rows($result_s) > 0) {
                                       while ($row_S = mysqli_fetch_assoc($result_s)) {
                                         echo "<option value='{$row_S['id']}'>{$row_S['area_name']}</option>";
                                       }
                                     }
                                      ?>
              </select>
             </div>
             </div>
             <label class="pt-3" for="exampleFormControlTextarenote">Note</label>
            <input maxlength="40" name="note" class="form-control mb-2" id="exampleFormControlTextarenote" type="text" placeholder="If there are any notes"/>
            <?php if ($_SESSION['role'] =='5') { ?>
              <label class="pt-3">Select a merchant<span class="text-red font-weight-900"> *</span></label>
            <select required class="form-control" searchable="Search ....." name="merchant">
               <option value="" disabled selected>Select a merchant</option>
               <?php
                  include 'config.php';
                    $query_s = "SELECT * FROM merchant";
                      $result_s = mysqli_query($connection,$query_s)or die("ERROR");
                      if (mysqli_num_rows($result_s) > 0) {
                    while ($row_S = mysqli_fetch_assoc($result_s)) {
                  echo "<option value='{$row_S['id']}'>{$row_S['business']}</option>";
                  }  } ?>
            </select>
            <?php } ?>

           <div class="mt-2">
              <a href="parcel.php" class="btn btn-dark" type="button"><i class="fas fa-reply"></i>&nbsp;&nbsp;Return parcel page</a>
              <input class="btn btn-primary m-3"  type="submit" name="submit" value="Save and stay ">
              <input class="btn btn-black" type="submit" name="submitre" value="Save and return">
          </div>
              </form>
            </div>
          </div>
          <!-- Account details card-->

        </div>



      </div>
   </div>

</main>
<script type="text/javascript">
$(".js-example-placeholder-multiple").select2({
    placeholder: "Select a state"
});
</script>

<script>

        const serviceOption = document.getElementById('serviceOption');
        const charge = document.getElementById('charge');
        const payable = document.getElementById('payable');
        const codcharge = document.getElementById('codcharge');

        let serviceName = ''
        let inputWeightDefaultValue = '';
        let inputCashCollection = '';

        serviceOption.addEventListener('change', e => {
            serviceName = e.target.value;
            calculatePayment(serviceName, inputWeightDefaultValue, inputCashCollection);
        });

        function calculatePayment(serviceOptionValue, inputWeightValue, inputDefaultCash) {
            if (serviceOptionValue === '1' && inputWeightValue < 11 && inputWeightValue && inputCashCollection &&  inputCashCollection > 0) {
                const serviceCharge = (inputWeightValue * 20) + 40;
                const paybleCharge = inputDefaultCash - serviceCharge;
                payable.innerText = paybleCharge;
                charge.innerText = serviceCharge;
                codcharge.innerText = '00';
            }
          else if (serviceOptionValue === '2' && inputWeightValue < 11 && inputWeightValue && inputCashCollection &&  inputCashCollection > 0) {
                const serviceCharge = (inputWeightValue * 20) + 50;
                const paybleCharge = inputDefaultCash - serviceCharge;
                payable.innerText = paybleCharge;
                charge.innerText = serviceCharge;
                codcharge.innerText = '00';
            }
          else if (serviceOptionValue === '3' && inputWeightValue < 11 && inputWeightValue && inputCashCollection &&  inputCashCollection > 0) {
                const serviceCharge = (inputWeightValue * 20) + 60;
                const paybleCharge = inputDefaultCash - serviceCharge;
                payable.innerText = paybleCharge;
                charge.innerText = serviceCharge;
                codcharge.innerText = '00';
            }
          else if (serviceOptionValue === '4' && inputWeightValue < 11 && inputWeightValue && inputCashCollection &&  inputCashCollection > 0) {
                const serviceCharge = (inputWeightValue * 20) + 80;
                const paybleCharge = inputDefaultCash - serviceCharge;
                payable.innerText = paybleCharge;
                charge.innerText = serviceCharge;
                codcharge.innerText = '00';
            }
            else if (serviceOptionValue === '5' && inputWeightValue < 11 && inputWeightValue && inputCashCollection &&  inputCashCollection > 0) {
                const serviceCharge = (inputWeightValue * 30) + 90;
                const percentCalculate = inputCashCollection / 100;
                  const paybleCharge = inputDefaultCash - serviceCharge;
                payable.innerText = paybleCharge;
                charge.innerText = serviceCharge;
                codcharge.innerText = percentCalculate;
            }
            else {
                payable.innerText = '00';
                charge.innerText = '00';
                codcharge.innerText = '00';
            }
        }

        function myFunction(a) {
            inputWeightDefaultValue = a;
                if(inputWeightDefaultValue > 0 && inputCashCollection > 0){
              calculatePayment(serviceName, inputWeightDefaultValue, inputCashCollection)
            }
        }

        function myNewFunction(value){
          inputCashCollection = value
          if(inputWeightDefaultValue > 0 && inputCashCollection > 0){
            calculatePayment(serviceName, inputWeightDefaultValue, inputCashCollection)
          }
        }

    </script>
<?php include 'footer.php';?>
