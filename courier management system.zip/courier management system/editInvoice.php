<?php ob_start(); ?>
<?php $title = "ইনভয়েস এডিট"; ?>
<?php include 'menu.php'; ?>
<?php
if (!$_SESSION['role']== '5') {
  header("location: index.php");
}
?>
<?php
   if (isset($_POST['submit'])) {
   include 'config.php';
   $PEONID = mysqli_real_escape_string($connection,$_POST['PEONID']);
   $merchant = mysqli_real_escape_string($connection,$_POST['merchant']);
   $totalPrice = mysqli_real_escape_string($connection,$_POST['totalPrice']);
   $status_invoice	 = mysqli_real_escape_string($connection,$_POST['status_invoice']);
   $Trxid	 = mysqli_real_escape_string($connection,$_POST['Trxid']);
   $comment	 = mysqli_real_escape_string($connection,$_POST['comment']);
   $rec_file = $_FILES['upload_image'];

   // Auto ID Genaretor
   $all_keys = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y'
     ,'Z','1','2','3','4','5','6','7','8','9','0'
   );
   $rendomKey = "";
   for ($i=0; $i < 3; $i++) {
     shuffle($all_keys);
    $rendomKey .= $all_keys[0];
   }


   $image_name = $rec_file['name'];
   $image_tmp_name = $rec_file['tmp_name'];
   date_default_timezone_set("Asia/Dhaka");
   $name_changer = date("MdDhiy").$rendomKey.".xls";
   if (!empty($image_name)) {
     $loction = "excel/".$name_changer;
     move_uploaded_file($image_tmp_name, $loction);
   }else {
     ?>
     <div class="alert alert-warning m-4" role="alert">
         আপনি কোন ফাইল আপলোড দেন নি!
     </div>
     <?php
   }
   // Photo

// Draft
date_default_timezone_set('Asia/Dhaka');
  $time = date("d M Y h:i:sa");
 $query1 =   "UPDATE invoice SET
    PEONID = '$PEONID',
    merchant ='{$merchant}',
    totalPrice ='{$totalPrice}',
    link ='{$loction}',
    status_invoice ='{$status_invoice}',
    Trxid ='{$Trxid}',
    comment ='{$comment}',
    paidTime ='{$time}'
WHERE invoice.id_invoice = {$_POST["pid"]}";

$result1 = mysqli_query($connection,$query1) or die("ডাটা সেন্টার কানেক্ট হয়নি !".mysqli_error());
if ($result1) {
  if ($_POST["status_invoice"] == 2) {

    $to = $_POST["mobileno"];
    $token = "69a9e1162ef97e9cc0f314fe26475048";
    $message = "আসসালামু আলাইকুম ! সন্মানিত স্বজন, পিয়ন কুরিয়ার লিঃ থেকে আপনার একটি পেমেন্ট পাঠানো হয়েছে । বিস্তারিত- https://beta.peonbd.com/viewInvoice.php?id=".$_POST["pid"];


    $url = "http://api.greenweb.com.bd/api.php?json";


    $data= array(
    'to'=>"$to",
    'message'=>"$message",
    'token'=>"$token"
    ); // Add parameters in key value
    $ch = curl_init(); // Initialize cURL
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $smsresult = curl_exec($ch);

  }
  header("location: invoice.php");
}
}



   ?>

   <?php $id_invoice =$_GET['edit'];
   include 'config.php';
    if ($_SESSION['role']== '5') {
   $querye = "SELECT * FROM invoice
   LEFT JOIN merchant ON invoice.merchant = merchant.id
   LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
   WHERE invoice.id_invoice = {$id_invoice}";
   }elseif ($_SESSION['role']== '1') {
     $querye = "SELECT * FROM invoice
     LEFT JOIN merchant ON invoice.merchant = merchant.id
     LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
     WHERE invoice.id_invoice = {$id_invoice} and invoice.merchant = {$_SESSION['id']}";
   }


   $resulte = mysqli_query($connection,$querye) or die("Query Faield.11");
   $counte = mysqli_num_rows($resulte);

   if ($counte>0) {

   while ($rowe = mysqli_fetch_assoc($resulte)) {


    ?>
<main>
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
      <div class="container-fluid">
         <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
               <div class="col-auto mb-3">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i class="fas fa-pen"></i></div>
                      PONEY<?php echo $rowe['id_invoice']; ?> | আপডেট ইনভয়েস
                  </h1>
               </div>
            </div>
         </div>
      </div>
   </header>
<!-- Main page content-->
   <div class="container mt-4">
   <hr class="mt-0 mb-4" />
   <div class="row">
      <div class="col-xl-12">
         <!-- Account details card-->
         <div class="card card-waves">
            <div class="card-header">অর্ডার আইডি</div>
            <div class="card-body">
              <form class="" action="" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="pid" value="<?php echo $rowe['id_invoice']; ?>">
                <div class="form-group mb-5">
                  <textarea required name="PEONID" class="form-control" id="exampleFormControlTextareaADDR" rows="6" ><?php echo $rowe['PEONID']; ?></textarea>
                </div>

            <div class="row">
               <div class="col-xl-6">
            <select required class="form-control" searchable="সার্চ করুন....." name="merchant">
          <option value="" disabled selected>একটি মার্চেন্ট সিলেক্ট করুন</option>
          <?php
            include 'config.php';
              $query_s = "SELECT * FROM merchant";
                $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");
                if (mysqli_num_rows($result_s) > 0) {
              while ($row_S = mysqli_fetch_assoc($result_s)) {
                if ($rowe['merchant'] == $row_S['id']) {
                  $select = "selected";
                }else {
                  $select = "";
                }
            echo "<option ".$select." value='{$row_S['id']}'>{$row_S['business']}</option>";
          }  } ?>
        </select>
        <div class="pt-3">
        <label class="sr-only" for="inlineFormInputGroup">টাকা</label>
          <div class="input-group">
            <div class="input-group-prepend">
              <div class="input-group-text">&#2547;</div>
            </div>
            <input required type="text" class="form-control " id="inlineFormInputGroup" placeholder="সর্বমোট টাকা" name="totalPrice" value="<?php echo $rowe['totalPrice']; ?>">
          </div>
        </div>

<div class=" pt-3">
  <input name="upload_image" class="form-control form-control" id="formFileLg" type="file" />
  </div>

    </div>
          <div class="col-xl-6">
          <select required class="form-control" searchable="সার্চ করুন....." name="status_invoice">
          <option  value="" disabled selected>একটি স্টাটাস সিলেক্ট করুন</option>
          <?php
            include 'config.php';
              $query_s = "SELECT * FROM in_status";
                $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");
                if (mysqli_num_rows($result_s) > 0) {
              while ($row_S = mysqli_fetch_assoc($result_s)) {
                if ($rowe['status_invoice'] == $row_S['in_id']) {
                  $select = "selected";
                }else {
                  $select = "";
                }
            echo "<option ".$select." value='{$row_S['in_id']}'>{$row_S['in_name']}</option>";
          }  } ?>
        </select>

        <div class="pt-3">
        <label class="sr-only" for="inlineFormInputGroup">Trxid</label>
          <div class="input-group">
            <div class="input-group-prepend">
              <div class="input-group-text"><i class="fas fa-qrcode"></i></div>
            </div>
            <input required type="text" class="form-control " id="inlineFormInputGroup" placeholder="Transaction ID" name="Trxid" value="<?php echo $rowe['Trxid']; ?>">
          </div>
        </div>

        <div class="pt-3">
        <label class="sr-only" for="inlineFormInputGroup">Comment</label>
          <div class="input-group">
            <div class="input-group-prepend">
              <div class="input-group-text"><i class="far fa-comment-dots"></i></div>
            </div>
            <input type="text" class="form-control " id="inlineFormInputGroup" placeholder="Comment" name="comment" value="<?php echo $rowe['comment']; ?>">
          </div>
        </div>

        </div>
      </div>
      <a href="invoice.php" class="btn btn-dark" type="button"><i class="fas fa-reply"></i>&nbsp;&nbsp;ইনভয়েস-এ ফিরব</a>
      <input class="btn btn-primary m-3"  type="submit" name="submit" value="সেভ">
      </form>
    </div>
  </div>


   </div>
</main>

<?php }}
 include 'footer.php';?>
