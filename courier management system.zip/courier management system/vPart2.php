<?php
                     $result = mysqli_query($connection,$query) or die("Query Faield.");
                     $count = mysqli_num_rows($result);
                   }
                     ?>
                  <thead>
                     <tr>
                        <th>আইডি</th>
                        <th>প্রেরক</th>
                        <th>প্রাপক</th>
                        <th>নোট</th>
                        <th>স্টাটাস</th>
                        <th>অ্যাকশান</th>
                     </tr>
                  </thead>
                  <tfoot>
                     <tr>
                        <th>আইডি</th>
                        <th>প্রেরক</th>
                        <th>প্রাপক</th>
                        <th>নোট</th>
                        <th>স্টাটাস</th>
                        <th>অ্যাকশান</th>
                     </tr>
                  </tfoot>
                  <tbody>
                     <?php
                        if ($count>0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                          ?>
                     <tr>
                        <td class="th-sm">
                           <span class="text-green">PEON786592<?php echo $row['parcel_id']; ?></span><br>
                           M.Inv:<?php echo $row['c_Inv']; ?><br>
                           <?php echo $row['Ptime']; ?> <br>
                           <?php echo $row['Pdate']; ?>
                        </td>
                        <td class="th-sm cb">
                           <?php echo $row['business']; ?> <br>
                           <?php echo $row['number']; ?>  <br>
                           <?php echo $row['address']; ?>
                           <div class="row ">
                              <div class="col-md-12">
                                 <div class="row">
                                    <div class="col-md-6">
                                       <span class="text-green font-weight-900"> ওজন: <?php echo $row['weight']; ?> কেজি</span>
                                    </div>
                                    <div class="col-md-6">
                                       <span class="text-green font-weight-900">
                                          চার্জ:  <?php

                                        echo $row['c_charge'];

                                           ?> &#2547;

                                        </span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </td>
                        <td class="th-sm cb">
                           <?php echo $row['c_name'];?> <br>
                           <?php echo $row['c_number']; ?>,  <?php echo $row['c_b_number']; ?>  <br>
                           <?php echo $row['c_address']; ?>
                           <span class="text font-weight-900"> এরিয়া: <?php echo $row['area_name']; ?></span>
                           <div class="row ">
                              <div class="col-md-12">
                                 <span class="text-green font-weight-900"> ক্যাশ কালেকশান: <?php echo $row['c_price']; ?> &#2547;</span>
                              </div>
                           </div>
                        </td>
                        <td class="th-sm cbNote">
                        <?php echo $row['note'];?>
                        </td>
                        <td>
                           <?php
                              if ($row['c_action']==1) {
                                  echo "<div class='badge badge-danger badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==2){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==3){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==4){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==5){
                                  echo "<div class='badge badge-green badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==6){
                                  echo "<div class='badge badge-dark badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==7){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==8){
                                  echo "<div class='badge badge-dark badge-pill'>".$row['action_name']."</div>";
                              }
                              else {
                                echo "<div class='badge badge-warning badge-pill'>".$row['action_name']."</div>";
                              }
                              ?>
                           <br>
                           <?php
                              if ($row['c_service']==1) {
                                  echo "<div class='badge badge-danger badge-pill'>".$row['sName']."</div>";
                              }
                              else if($row['c_service']==2){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['sName']."</div>";
                              }
                              else {
                                echo "<div class='badge badge-warning badge-pill'>".$row['sName']."</div>";
                              }
                              ?>
                        </td>
                        <td>
                             <?php if ($_SESSION['role'] =='5') {?>
   <button href="view_merchant.php?id=<?php echo $row['id']; ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="dropdownFadeInUp<?php echo $row['parcel_id']; ?>" class="btn btn-datatable btn-icon btn-transparent-dark mr-2">
     <i data-feather="more-vertical"></i>
   </button>
 <?php } ?>
<div class="dropdown-menu animated--fade-in-up" aria-labelledby="dropdownFadeInUp<?php echo $row['parcel_id'];?>">
  <!-- Delete Dropdown Button -->
<a data-toggle="modal" data-target="#exampleModalSm<?php echo $row['parcel_id']; ?>" class="dropdown-item text-danger" >ডিলিট</a>

    <!-- Delete Dropdown Button -->
                           </div>
                           <!-- Small modal -->
                           <div class="modal fade" id="exampleModalSm<?php echo $row['parcel_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                              <div class="modal-dialog modal-sm" role="document">
                                 <div class="modal-content">
                                    <div class="modal-header">
                                       <h5 class="modal-title">গুরুত্বপূর্ণ ব্যাপার</h5>
                                       <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                    </div>
                                    <div class="modal-body">
                                       <p>আপনি কি PEON00<?php echo $row['parcel_id']; ?> পার্সেল ডিলিট করতে চাচ্ছেন?</p>
                                    </div>
                                    <div class="modal-footer">
                                       <button class="btn btn-primary" type="button" data-dismiss="modal">না! থাক</button>
                   <a class="btn btn-danger" type="button" href="delete_parcel.php?MasRiaKib=<?php echo $row['parcel_id']; ?>">ডিলিট</a>
                                    </div>
                                 </div>
                              </div>
                           </div>

                           <a href="viewParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-datatable btn-icon btn-transparent-dark"><i class="fas fa-eye"></i></a>
                              <?php if ($_SESSION['role'] =='5') {?>
                           <a href="updateParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-datatable btn-icon btn-transparent-dark"><i class="far fa-edit"></i></a>
                         <?php } ?>
                           <a class="btn btn-datatable btn-icon btn-transparent-dark" onclick="window.open('print_parcel.php?id=<?php echo $row['parcel_id']; ?>','POPUP WINDOW TITLE HERE','').print()"><i class="fas fa-print"></i></a>
                           <?php if ($_SESSION['role'] =='5') {?>
  <a data-toggle="modal" data-target="#exampleModalCenter<?php echo $row['parcel_id']; ?>"  class="btn btn-datatable btn-icon "><i class="fas fa-cogs"></i>
  </a>
<?php } ?>
<!-- admin Modal -->
<div class="modal fade" id="exampleModalCenter<?php echo $row['parcel_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle">PEON00<?php echo $row['parcel_id']; ?></h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <div class="modal-body">
              <!-- Content  -->
              <form action="action_up.php" method="post">
                <input type="hidden" name="pid"  value="<?php echo $row['parcel_id']; ?>" >
    <div class="form-group">

      <label for="exampleFormControlInput1">চার্জ</label>
      <input name="c_charge" class="form-control" id="exampleFormControlInput1" type="text" placeholder="<?php echo $row['c_charge']; ?>">

      <label for="exampleFormControlInput3">ওজন</label>
      <input name="weight" class="form-control" id="exampleFormControlInput3" type="text" placeholder="<?php echo $row['weight']; ?>">

        <label for="exampleFormControlSelect2">অ্যাকশান</label>
        <select name="c_action" class="form-control" id="exampleFormControlSelect2">
            <option selected disabled>একটি নির্বাচন করুন</option>
            <?php
                   include 'config.php';
                   $query_s = "SELECT * FROM action";
                   $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                   if (mysqli_num_rows($result_s) > 0) {
                     while ($row_S = mysqli_fetch_assoc($result_s)) {

                       if ($row['c_action'] == $row_S['action_id']) {
                         $selected = "selected";
                       }else {
                         $selected = "";
                       }

                       echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                     }
                   }
                    ?>
        </select>
        <input type="hidden" name="old_action" value="<?php echo $row['c_action']; ?>">
    </div>

              <!-- Content  -->
            </div>
            <div class="modal-footer">
              <button class="btn btn-dark" type="button" data-dismiss="modal">Close</button>
              <input class=" btn btn-primary" type="submit" name="submit" value="সেভ" required>
              </form>
            </div>
        </div>
    </div>
</div>


<!-- admin Modal -->






                        </td>
                     </tr>
                     <?php } ?>
                  </tbody>
                  <?php } ?>
               </table>

            </div>
         </div>
      </div>
   </div>
</main>
