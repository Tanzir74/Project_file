<?php ob_start(); ?>
<?php
$payAccount_default = $_GET['id'];
$payAccount_merchant = $_GET['mr'];

include 'config.php';


$query = "UPDATE payaccount
SET payAccount_default=0
WHERE 	payAccount_merchant={$payAccount_merchant}";
$result = mysqli_query($connection,$query) or die("Query Faield 1.");

$query2 = "UPDATE payaccount
SET payAccount_default=1
WHERE payAccount_id={$payAccount_default}";
$result2 = mysqli_query($connection,$query2) or die("Query Faield 2.");

if ($result2) {
  header('location: peoney.php?id='.$payAccount_merchant);
  bo_enf_fluch();
}else{
echo   "<div class='alert alert-primary' role='alert'>
    Delete Fail!
</div>";
}

 ?>
