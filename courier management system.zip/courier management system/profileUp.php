<?php ob_start(); ?>
<?php
if (isset($_POST['submit'])) {
  include 'config.php';
$id = mysqli_real_escape_string($connection,$_POST['ide']);
$rec_file = $_FILES['upload_image'];




$image_name = $rec_file['name'];
$image_tmp_name = $rec_file['tmp_name'];
$name_changer = uniqid().".png";
if (!empty($image_name)) {
  $loction = "images/".$name_changer;
  move_uploaded_file($image_tmp_name, $loction);
}else {
  echo "ফাইলে কিছু নাই।";
}

$query1 = "UPDATE `merchant` SET
`p_photo` = '$loction'  WHERE `merchant`.`id` = $id";

$result1 = mysqli_query($connection,$query1) or die("কিউরি ফেইল হয়েছে।1".mysqli_error());
if ($result1) {
  header("location: parcel.php");
  bo_enf_fluch();
    }
  }



 ?>
