<?php ob_start(); ?>
<?php $title = "সার্ভিস যুক্তকরণ"; ?>
<?php include 'menu.php'; ?>
<?php
   if (isset($_POST['submit'])) {
     include 'config.php';
     $sName = mysqli_real_escape_string($connection,$_POST['sName']);
     $s_price = mysqli_real_escape_string($connection,$_POST['s_price']);
                  $query1 = "INSERT INTO services (sName,s_price)
                  VALUE ('$sName','$s_price')";
                  $result1 = mysqli_query($connection,$query1) or die("কিউরি ফেইল হয়েছে।");
                  if($result1){
                  header('location: service.php');
                  bo_enf_fluch();  }}

                  ?>
<main>
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
      <div class="container-fluid">
         <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
               <div class="col-auto mb-3">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i data-feather="user"></i></div>
                     সার্ভিস  | নতুন সার্ভিস
                  </h1>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- Main page content-->
   <div class="container mt-4">
   <hr class="mt-0 mb-4" />
   <div class="row">
      <div class="col-xl-4">
         <!-- Account details card-->
         <div class="card mb-4">
            <div class="card-header">নতুন সার্ভিস</div>
            <div class="card-body">
               <form action="addService.php" method="POST" autocomplete="off">
                  <input type="hidden" name="id" >
                  <!-- Form Group (username)-->
                  <div class="form-group">
                     <label  class="small mb-1" for="inputUsername">নাম</label>
                     <input  class="form-control"  name="sName" type="text" placeholder="সার্ভিস নাম"  />
                  </div>
                  <!-- Form Row-->
                  <div class="form-row">
                     <!-- Form Group (name)-->
                     <div class="form-group col-md-6">
                        <label class="small mb-1" for="inputFirstName">টাকা</label>
                        <input name="s_price" class="form-control" id="inputFirstName" type="text" placeholder="সার্ভিস মূল্য"  />
                     </div>
                     <!-- Form Group (Moble)-->
                     <!-- <div class="form-group col-md-6">
                        <label class="small mb-1" for="inputLastName">মার্চেন্ট</label>
                        <input disabled name="bk_number" class="form-control" id="inputLastName" type="text" placeholder="একটি মার্চেন্ট নির্বাচন করুন" />
                     </div> -->
                  </div>
                  <div class="form-row">
                     <a href="service.php" class="btn btn-dark" type="button"><i class="fas fa-reply"></i>&nbsp;&nbsp;      সার্ভিস-এ ফিরব</a>
                     &nbsp;&nbsp;&nbsp;
                     <button type="submit" name="submit" class="btn btn-primary" type="button">আপডেট সেভ</button>
               </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</main>
<?php include 'footer.php';?>
