<?php ob_start(); ?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="smartLogcustom.js"></script>
<link rel="stylesheet" href="smartLogcustom.css">



<!-- All the files that are required -->
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link href='https://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.13.1/jquery.validate.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>পাসওয়ার্ড রিকভারি| পিয়ন কুরিয়ার লিমেটেড</title>
<link rel="icon" type="image/x-icon" href="assets/img/favicon.png" />
<!-- REGISTRATION FORM -->
<div class="text-center" style="padding:50px 0">
	<div class="logo">পাসওয়ার্ড রিকভারি</div>
	<!-- Main Form -->
	<div class="login-form-1">

		<!--PHP New User -->
		<?php
		   if (isset($_POST['submit'])) {
		   include 'config.php';
		   $number = mysqli_real_escape_string($connection,$_POST['number']);

		   $query2 ="SELECT * FROM merchant

       WHERE number='$number'";
		   $result2 = mysqli_query($connection,$query2) or die("কিউরি ফেইল হয়েছে।");

		   $count = mysqli_num_rows($result2);
       if ($count>0) {

       while ($rowe = mysqli_fetch_assoc($result2)) {

// SMS
$to = $number;
$token = "69a9e1162ef97e9cc0f314fe26475048";
$message = "প্রিয় মার্চেন্ট ! রিকভারি রিকুয়েস্টের জন্য ধন্যবাদ। আপনার ইউজারনেম-{$rowe['username']} পাসওয়ার্ড-{$rowe['password']} অনুগ্রহপূর্বক লগইন করে পাসওয়ার্ডটি চেন্জ করুন।";


$url = "http://api.greenweb.com.bd/api.php?json";


$data= array(
'to'=>"$to",
'message'=>"$message",
'token'=>"$token"
); // Add parameters in key value
$ch = curl_init(); // Initialize cURL
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_ENCODING, '');
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$smsresult = curl_exec($ch);
if ($smsresult) {
  header('location: index.php');
  bo_enf_fluch();
}

// SMS



       }


     }else {
       echo "দুঃখিত ! {$number} এই নম্বরটি রেজিস্টার্ড নয় ।";
     }

		   }

		   ?>

		<!--PHP New User -->


		<form id="register-form" class="text-left" action="<?php $_SERVER['PHP_SELF'] ?>"  method="post">
			<div class="login-form-main-message"></div>
			<div class="main-login-form">
				<div class="login-group">
						<div class="form-group">
							<label for="reg_fullname" class="sr-only">মোবাইল নম্বর</label>
							<input required type="text" class="form-control" id="reg_fullname" name="number" placeholder="মোবাইল নম্বর">
						</div>
				</div>
				<input type="submit" class="login-button" name="submit" value="&#10097;">
			</div>
			<div class="etc-login-form">
				<p>ইতোমধ্যেই স্বজন ? <a href="index.php">লগইন করুন</a></p>
				<p>নতুন স্বজন ? <a href="signUP.php">নতুন অ্যাকাউন্ট তৈরী করুন</a></p>
			</div>
		</form>
	</div>
	<!-- end:Main Form -->
</div>
<div class="footer fixed-bottom">
	<img src="footer.png" class="footer-img">
</div>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5e6e963aeec7650c33202caf/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
