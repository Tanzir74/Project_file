<?php
   session_start();
   if (!isset($_SESSION['username'])) {
     header("location: index.php");
   }
   include 'config.php';
$actoionF = $_GET['action'];
$merchantF = $_GET['merchant'];
$servicesF = $_GET['service'];



   if ($_SESSION['role']== '5') {
   $query = "SELECT * FROM parcel
   LEFT JOIN services ON parcel.c_service = services.id
   LEFT JOIN area ON parcel.c_area = area.id
   LEFT JOIN merchant ON parcel.c_m_business = merchant.id
   LEFT JOIN action ON parcel.c_action = action.action_id
   LEFT JOIN hero ON parcel.c_hero = hero.hero_id
   LEFT JOIN pay ON parcel.p_Pay = pay.payID
   WHERE parcel.c_action = {$actoionF} and (parcel.c_m_business = {$merchantF} and parcel.c_service = {$servicesF})
   ORDER BY parcel.parcel_id  DESC LIMIT 500";
   }elseif ($_SESSION['role']== '1') {
   $query = "SELECT * FROM parcel
   LEFT JOIN services ON parcel.c_service = services.id
   LEFT JOIN area ON parcel.c_area = area.id
   LEFT JOIN merchant ON parcel.c_m_business = merchant.id
   LEFT JOIN action ON parcel.c_action = action.action_id
   LEFT JOIN hero ON parcel.c_hero = hero.hero_id
   WHERE parcel.c_m_business = {$_SESSION['id']} and (parcel.c_action = {$actoionF} and parcel.c_service = {$servicesF})
   ORDER BY parcel.parcel_id DESC LIMIT 500";
   }else {
    die;
  }

                    ?>
                    <?php
                    $result = mysqli_query($connection,$query) or die("Query Faield.");
                    ?>
                <?php $html= '<table>
                <tr>
                <td>Order ID</td>
                <td>Mer ID</td>
                <td>Order Place</td>
                <td>Rider</td>
                <td>Merchant Name</td>
                <td>M Phone no</td>
                <td>M Address</td>
                <td>Customer Name</td>
                <td>C Phone no</td>
                <td>C Address</td>
                <td>Zone</td>
                <td>Wt (kg)</td>
                <td>Product Price</td>
                <td>Delivery Charge</td>
                <td>COD Charge</td>
                <td>Order Status</td>
                <td>Notes</td>
                </tr>';
                       while ($row = mysqli_fetch_assoc($result)) {
                         if ($row['trId'] == ""){
                        $orid = "PEON786592".$row['parcel_id'];
                         }else {
                          $orid =  $row['trId'];
                         }

                         $html.='<tr>
                         <td>'.$orid.'</td>
                         <td>'.$row['c_Inv'].'</td>
                         <td>'.$row['Pdate'].'</td>
                         <td>N/A</td>
                         <td>'.$row['business'].'</td>
                         <td>'.$row['number'].'</td>
                         <td>'.$row['address'].'</td>
                         <td>'.$row['c_name'].'</td>
                         <td>'.$row['c_number'].'</td>
                         <td>'.$row['c_address'].'</td>
                         <td>'.$row['area_name'].'</td>
                         <td>'.$row['weight'].'</td>
                         <td>'.$row['c_price'].'</td>
                         <td>'.$row['c_charge'].'</td>
                         <td>0</td>
                         <td>'.$row['action_name'].'</td>
                         <td>'.$row['note'].'</td>
                         </tr>';
}
                     $html.='</table>';
 date_default_timezone_set("Asia/Dhaka");
header('Content-Type:application/xls');
header('Content-Disposition:attachment;filename='.date("YmdHis").'.xls');
echo $html;
                    ?>
