<?php
// Same Day Service Price
$percentage= 1;
if ($_POST['c_service'] == 1 and $_POST['weight'] == 1) {
$cost = "60";
}else if($_POST['c_service'] == 1 and $_POST['weight'] == 2){
 $cost = "80";
}else if($_POST['c_service'] == 1 and $_POST['weight'] == 3){
 $cost = "100";
}else if($_POST['c_service'] == 1 and $_POST['weight'] == 4){
 $cost = "120";
}else if($_POST['c_service'] == 1 and $_POST['weight'] == 5){
 $cost = "140";
}else if($_POST['c_service'] == 1 and $_POST['weight'] == 6){
 $cost = "160";
}else if($_POST['c_service'] == 1 and $_POST['weight'] == 7){
 $cost = "180";
}else if($_POST['c_service'] == 1 and $_POST['weight'] == 8){
 $cost = "200";
}else if($_POST['c_service'] == 1 and $_POST['weight'] == 9){
 $cost = "220";
}else if($_POST['c_service'] == 1 and $_POST['weight'] == 10){
 $cost = "240";
}
// Next Day Service Price
if ($_POST['c_service'] == 2 and $_POST['weight'] == 1) {
$cost = "70";
}else if($_POST['c_service'] == 2 and $_POST['weight'] == 2){
 $cost = "90";
}else if($_POST['c_service'] == 2 and $_POST['weight'] == 3){
 $cost = "110";
}else if($_POST['c_service'] == 2 and $_POST['weight'] == 4){
 $cost = "130";
}else if($_POST['c_service'] == 2 and $_POST['weight'] == 5){
 $cost = "150";
}else if($_POST['c_service'] == 2 and $_POST['weight'] == 6){
 $cost = "170";
}else if($_POST['c_service'] == 2 and $_POST['weight'] == 7){
 $cost = "190";
}else if($_POST['c_service'] == 2 and $_POST['weight'] == 8){
 $cost = "210";
}else if($_POST['c_service'] == 2 and $_POST['weight'] == 9){
 $cost = "230";
}else if($_POST['c_service'] == 2 and $_POST['weight'] == 10){
 $cost = "250";
}
// Next Day Service Price
if ($_POST['c_service'] == 3 and $_POST['weight'] == 1) {
$cost = "80";
}else if($_POST['c_service'] == 3 and $_POST['weight'] == 2){
 $cost = "100";
}else if($_POST['c_service'] == 3 and $_POST['weight'] == 3){
 $cost = "120";
}else if($_POST['c_service'] == 3 and $_POST['weight'] == 4){
 $cost = "140";
}else if($_POST['c_service'] == 3 and $_POST['weight'] == 5){
 $cost = "160";
}else if($_POST['c_service'] == 3 and $_POST['weight'] == 6){
 $cost = "180";
}else if($_POST['c_service'] == 3 and $_POST['weight'] == 7){
 $cost = "200";
}else if($_POST['c_service'] == 3 and $_POST['weight'] == 8){
 $cost = "220";
}else if($_POST['c_service'] == 3 and $_POST['weight'] == 9){
 $cost = "240";
}else if($_POST['c_service'] == 3 and $_POST['weight'] == 10){
 $cost = "260";
}
// Next Day Service Price
if ($_POST['c_service'] == 4 and $_POST['weight'] == 1) {
$cost = "100";
}else if($_POST['c_service'] == 4 and $_POST['weight'] == 2){
 $cost = "120";
}else if($_POST['c_service'] == 4 and $_POST['weight'] == 3){
 $cost = "140";
}else if($_POST['c_service'] == 4 and $_POST['weight'] == 4){
 $cost = "160";
}else if($_POST['c_service'] == 4 and $_POST['weight'] == 5){
 $cost = "180";
}else if($_POST['c_service'] == 4 and $_POST['weight'] == 6){
 $cost = "200";
}else if($_POST['c_service'] == 4 and $_POST['weight'] == 7){
 $cost = "220";
}else if($_POST['c_service'] == 4 and $_POST['weight'] == 8){
 $cost = "240";
}else if($_POST['c_service'] == 4 and $_POST['weight'] == 9){
 $cost = "260";
}else if($_POST['c_service'] == 4 and $_POST['weight'] == 10){
 $cost = "280";
}

// Frozen Service Price
if ($_POST['c_service'] == 5 and $_POST['weight'] == 1) {
  $charge = 120;
  $cod = $_POST['c_price'];
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($_POST['c_service'] == 5 and $_POST['weight'] == 2){
  $charge = 150;
  $cod = $_POST['c_price'];
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($_POST['c_service'] == 5 and $_POST['weight'] == 3){
  $charge = 170;
  $cod = $_POST['c_price'];
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($_POST['c_service'] == 5 and $_POST['weight'] == 4){
  $charge = 200;
  $cod = $_POST['c_price'];
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($_POST['c_service'] == 5 and $_POST['weight'] == 5){
  $charge = 230;
  $cod = $_POST['c_price'];
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($_POST['c_service'] == 5 and $_POST['weight'] == 6){
  $charge = 260;
  $cod = $_POST['c_price'];
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($_POST['c_service'] == 5 and $_POST['weight'] == 7){
  $charge = 290;
  $cod = $_POST['c_price'];
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($_POST['c_service'] == 5 and $_POST['weight'] == 8){
  $charge = 320;
  $cod = $_POST['c_price'];
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($_POST['c_service'] == 5 and $_POST['weight'] == 9){
  $charge = 350;
  $cod = $_POST['c_price'];
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($_POST['c_service'] == 5 and $_POST['weight'] == 10){
  $charge = 370;
  $cod = $_POST['c_price'];
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}


 ?>
