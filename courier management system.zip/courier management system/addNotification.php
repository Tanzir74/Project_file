<?php ob_start(); ?>
<?php $title = "Notification design"; ?>
<?php include 'menu.php'; ?>
<?php
if (!$_SESSION['role']== '5') {
  header("location: index.php");
}
 ?>
<?php
if (isset($_POST['save'])) {
  include 'config.php';
  $notification_name = mysqli_real_escape_string($connection,$_POST['notification_name']);
  $notification_content = mysqli_real_escape_string($connection,$_POST['notification_content']);
  $notification_link = mysqli_real_escape_string($connection,$_POST['notification_link']);
  $notification_text = mysqli_real_escape_string($connection,$_POST['notification_text']);
  $notification_color = mysqli_real_escape_string($connection,$_POST['notification_color']);


     $query1 = "INSERT INTO notification (notification_name,notification_content,notification_link,notification_text,notification_color)
     VALUE ('$notification_name','$notification_content','$notification_link','$notification_text','$notification_color')";
     $result1 = mysqli_query($connection,$query1) or die("ERROR");
     if($result1){
     header('location: addNotification.php');
      bo_enf_fluch();
     }}?>

<main>
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
      <div class="container-fluid">
         <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
               <div class="col-auto mb-3">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i class="fas fa-bell"></i></div>
                     Notification design
                  </h1>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- Main page content-->
   <div class="container mt-4">
   <div class="row">
      <div class="col-xl-4">
         <!-- Account details card-->
         <div class="card card-waves">
            <div class="card-header">Notification design</div>
            <div class="card-body">
              <form class="" action="" method="post">
              <label class="small mb-1" for="notification_name">Name</label>
              <input required type="text"  name="notification_name" id="notification_name" class="form-control"  placeholder="(It will not show.)" />

                <label class="small mt-3" for="notification_content">Content</label>
                <textarea required name="notification_content" class="form-control" id="notification_content" rows="3"></textarea>


              <label class="small mt-3" for="notification_link">Button</label>
              <input required type="text" name="notification_link" class="form-control" id="notification_link"  placeholder="https: // must be given." />

              <label class="small mt-3" for="notification_text">Button text</label>
              <input required type="text" name="notification_text" id="notification_text" class="form-control"  placeholder="For example: Details!" />

              <label class="small mt-3" for="notification_color">Button color</label>
              <select class="form-control" name="notification_color" id="notification_color">
                <option value="btn btn-primary" class="bg-primary text-light">Primary</option>
                <option value="btn btn-secondary" class="bg-secondary text-light">Secondary</option>
                <option value="btn btn-success" class="bg-success text-light">Success</option>
                <option value="btn btn-danger" class="bg-danger text-light">Danger</option>
                <option value="btn btn-warning" class="bg-warning text-light">Warning</option>
                <option value="btn btn-info" class="bg-info text-light">Info</option>
                <option value="btn btn-light" class="bg-light text-dark">Light</option>
                <option value="btn btn-dark" class="bg-dark text-light">Dark</option>
                <option value="btn btn-link" class="bg-link text-primary">Link</option>
              </select>

              <input class="btn btn-primary mt-3" type="submit" name="save" value="Save">
            </form>
            </div>
          </div>
        </div>
        <div class="col-md-8">
          <div class="card mb-4">
              <div class="card-header">All notifications &nbsp;
            </a>
              </div>



              <div class="card-body">
                  <div class="datatable">
                      <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

          <?php
          include 'config.php';
          $query = "SELECT * FROM notification ORDER BY notification_id DESC";
          $result = mysqli_query($connection,$query) or die("Query Faield.");
          $count = mysqli_num_rows($result);
          if ($count>0) {

           ?>

                          <thead>
                              <tr>
                                  <th>Name</th>
                                  <th>Content</th>
                                  <th>Button</th>
                                  <th>Action</th>
                              </tr>
                          </thead>
                          <tfoot>
                              <tr>
                                <th>Name</th>
                                <th>Content</th>
                                <th>Button</th>
                                <th>Action</th>
                              </tr>
                          </tfoot>

                          <tbody>
          <?php
          while ($row = mysqli_fetch_assoc($result)) {
          ?>
                              <tr>
                                  <td><?php echo $row['notification_name']; ?></td>
                                  <td class="th-sm cb"><?php echo $row['notification_content']; ?></td>
                                  <td><a href="<?php echo $row['notification_link']; ?>" class="<?php echo $row['notification_color']; ?>" type="button"><?php echo $row['notification_text']; ?></a></td>
                                  <td>    <div class="ml-4 small">
                                        <?php if ($row['notification_default'] == "1") {
                                          ?>
                                          <div title="Make UnDefault" class="badge badge-light mr-3"><a href="undefult_notification.php?id=<?php echo $row['notification_id']; ?>">Default</a></div>
                                          <?php
                                        }else {
                                        ?>
                                        <a class="text-muted mr-3" href="defult_notification.php?id=<?php echo $row['notification_id']; ?>">Make Default</a>
                                        <?php
                                        } ?>
                                          <a onclick="myFunction()" href="delete_notification.php?id=<?php echo $row['notification_id']; ?>">Delete</a>
                                      </div></td>
                              </tr>
                              <?php } ?>
                          </tbody>
                          <?php } ?>
                      </table>
                  </div>
              </div>
          </div>

        </div>




      </div>
   </div>

</main>
<?php include 'footer.php';?>
