      <?php ob_start(); ?>
      <?php
      $notification_id  = $_GET['id'];

      include 'config.php';


      $query2 = "UPDATE notification
      SET notification_default=0
      WHERE 	notification_id ={$notification_id }";
      $result2 = mysqli_query($connection,$query2) or die("Query Faield.");

      if ($result2) {
        header('location: addNotification.php');
        bo_enf_fluch();
      }else{
      echo   "<div class='alert alert-primary' role='alert'>
          Delete Fail!
      </div>";
      }

       ?>
