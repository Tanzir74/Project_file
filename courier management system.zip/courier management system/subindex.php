<?php ob_start();

  header("location: https://peonbd.com/sorry/");
    bo_enf_fluch();
    ?>
