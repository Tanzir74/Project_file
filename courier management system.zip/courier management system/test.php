<?php
include 'config.php';
$query = "SELECT * FROM merchant
LEFT JOIN parcel ON merchant.id = parcel.c_m_business
WHERE parcel.action = 1
ORDER BY merchant.id DESC";
$result = mysqli_query($connection,$query) or die("Query Faield.");
$count = mysqli_num_rows($result);
  echo $count;
 ?>
