<?php ob_start();
$title = "All merchants";
 include 'menu.php';
if ($_SESSION['role']== '5') {
 ?>
 <style>
 .avatars {
   vertical-align: middle;
   width: 50px;
   height: 50px;
   border-radius: 100%;
 }
 </style>
<main>
    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
        <div class="container">
            <div class="page-header-content pt-4">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto mt-4">
                        <h1 class="page-header-title">
                            <div class="page-header-icon"><i class="fas fa-users"></i></div>
                            Merchant | Accounts
                        </h1>
                        <div class="page-header-subtitle">Every merchant is with us Important</div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Main page content-->

    <div class="container mt-n10">
        <div class="card mb-4">
            <div class="card-header">All marches &nbsp;
            </div>
            <?php
            include 'config.php';
            $query = "SELECT * FROM merchant ORDER BY PEONEY DESC";
            $result = mysqli_query($connection,$query) or die("Query Faield.");
            $count = mysqli_num_rows($result);
            ?>
            <div class="card-body">
                <div class="datatable">
                    <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

                        <thead>
                            <tr>
                                <th>Merchant</th>
                                <th>Payment info</th>
                                <th>Balance</th>
                            </tr>
                        </thead>

                        <tfoot>
                            <tr>
                              <th>Merchant</th>
                              <th>Payment info</th>
                              <th>Balance</th>
                            </tr>
                        </tfoot>

                        <tbody>
                          <?php
                          if ($count>0) {
                          while ($row = mysqli_fetch_assoc($result)) {
                          ?>
                            <tr>
                                <td>
                                  <div class="d-flex align-items-center justify-content-between">
                                      <div class="d-flex align-items-center">
                                      <img class="avatars" src="<?php echo $row['p_photo']; ?>">
                                          <div class="ml-4">
                                              <div class="small"><?php echo $row['business']; ?> | <?php echo $row['number']; ?></div>
                                              <div class="text-xs text-muted"><?php echo $row['email']; ?></div>
                                          </div>
                                      </div>
                                      <div class="ml-4 small">
                                          <!-- <div class="badge badge-light mr-3">Default</div> -->
                                        <a href="profile.php?id=<?php echo $row['id']; ?>" class="text-muted mr-3" >All Info</a>
                                          <a href="" class="text-red mr-3" data-toggle="modal" data-target="#exampleModalCenter<?php echo $row['id']; ?>">Make Pay</a>
                                      </div>
                                  </div>
                                </td>
                                <td>

                                  <?php
                                  include 'config.php';
                                  $query1 = "SELECT * FROM payaccount WHERE payAccount_merchant = {$row['id']} and payAccount_default = 1";
                                  $result1 = mysqli_query($connection,$query1) or die("Query Faield.");
                                  $count1 = mysqli_num_rows($result1);
                                  if ($count1>0) {
                                  while ($row1 = mysqli_fetch_assoc($result1)) {
                                    $PaymentGateway = $row1['payAccount_type'];

                                    switch ($PaymentGateway) {
                                      case "1":
                                    ?>
                                    <div class="d-flex align-items-center justify-content-between">
                                        <div class="d-flex align-items-center">
                                        <i class="fas fa-university fa-2x"></i>
                                            <div class="ml-4">
                                                <div class="small"><?php echo $row1['payAccount_owner']; ?> | <?php echo $row1['payAccount_number']; ?></div>
                                                <div class="text-xs text-muted"><?php echo $row1['payAccount_branch']; ?> | <?php echo $row1['payAccount_name']; ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                        break;
                                      case "2":
                                    ?>
                                    <div class="d-flex align-items-center justify-content-between">
                                        <div class="d-flex align-items-center">
                                            <img src="images/bkash.png" width="full" height="25">
                                            <div class="ml-4">
                                                <div class="small"><?php echo $row1['payAccount_number']; ?></div>
                                                <div class="text-xs text-muted"><?php if ($row1['payAccount_typeof'] == "1") {
                                                  echo "bKash Parsonal";
                                                }else {
                                                  echo "bKash Merchant";
                                                } ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                        break;
                                      case "3":
                                    ?><div class="d-flex align-items-center justify-content-between">
                                        <div class="d-flex align-items-center">
                                            <img src="https://download.logo.wine/logo/Nagad/Nagad-Logo.wine.png" width="full" height="25">
                                            <div class="ml-4">
                                                <div class="small"><?php echo $row1['payAccount_number']; ?></div>
                                                <div class="text-xs text-muted"><?php if ($row1['payAccount_typeof'] == "1") {
                                                  echo "Nagad Parsonal";
                                                }else {
                                                  echo "Nagad Merchant";
                                                } ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                        break;
                                      case "4":
                                    ?><div class="d-flex align-items-center justify-content-between">
                                        <div class="d-flex align-items-center">
                                            <img src="https://seeklogo.com/images/D/dutch-bangla-rocket-logo-B4D1CC458D-seeklogo.com.png" width="full" height="25">
                                            <div class="ml-4">
                                                <div class="small"><?php echo $row1['payAccount_number']; ?></div>
                                                <div class="text-xs text-muted"><?php if ($row1['payAccount_typeof'] == "1") {
                                                  echo "Rocket Parsonal";
                                                }else {
                                                  echo "Rocket Merchant";
                                                } ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                        break;
                                      case "5":
                                    ?><div class="d-flex align-items-center justify-content-between">
                                        <div class="d-flex align-items-center">
                                          <img src="https://seeklogo.com/images/E/eastern-bank-limited-logo-3DD509DA8B-seeklogo.com.png" width="full" height="25">
                                            <div class="ml-4">
                                              <div class="small"><?php echo $row1['payAccount_owner']; ?> | <?php echo $row1['payAccount_number']; ?></div>
                                              <div class="text-xs text-muted"><?php echo $row1['payAccount_branch']; ?> | EBL Card</div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                        break;
                                      default:
                                        echo "No Data!";
                                    }
                                  }}else {
                                    echo "The merchant did not add any payment gateway or default.";
                                  }
                                  ?>
                                </td>
                                <td><?php echo $row['PEONEY']; ?></td>
                            </tr>

<!-- Pay Info -->
<div class="modal fade" id="exampleModalCenter<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalCenterTitle"><?php echo $row['business']; ?> | Payment Info</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>
            <form class="" action="paycode.php" method="post" enctype="multipart/form-data">
            <div class="modal-body">
              <?php
              include 'config.php';
              $query1 = "SELECT * FROM payaccount WHERE payAccount_merchant = {$row['id']} and payAccount_default = 1";
              $result1 = mysqli_query($connection,$query1) or die("Query Faield.");
              $count1 = mysqli_num_rows($result1);
              if ($count1>0) {
              while ($row1 = mysqli_fetch_assoc($result1)) {
                $PaymentGateway = $row1['payAccount_type'];

                switch ($PaymentGateway) {
                  case "1":
                ?>
                <div class="d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center">
                    <i class="fas fa-university fa-2x"></i>
                        <div class="ml-4">
                            <div class="small"><?php echo $row1['payAccount_owner']; ?> | <?php echo $row1['payAccount_number']; ?></div>
                            <div class="text-xs text-muted"><?php echo $row1['payAccount_branch']; ?> | <?php echo $row1['payAccount_name']; ?></div>
                        </div>
                    </div>
                </div>
                <hr>

                <div class="form-group">
                  <label for="exampleFormControlInput1">How much do you want to pay?</label>
                  <input class="form-control form-control-solid" id="exampleFormControlInput1" type="number" name="peoney" placeholder="00" value="<?php echo $row['PEONEY']; ?>">
                </div>

                <div class="form-group mt-2">
                  <label for="exampleFormControlInput5">Have any comments or instructions?</label>
                  <input class="form-control form-control-solid" id="exampleFormControlInput5" type="text" name="comments" >
                </div>

                <div class=" pt-3">
                  <input name="upload_image" class="form-control form-control" id="formFileLg" type="file" />
                  </div>
                <?php
                    break;
                  case "2":
                ?>
                <div class="d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center">
                        <img src="images/bkash.png" width="full" height="25">
                        <div class="ml-4">
                            <div class="small"><?php echo $row1['payAccount_number']; ?></div>
                            <div class="text-xs text-muted"><?php if ($row1['payAccount_typeof'] == "1") {
                              echo "bKash Parsonal";
                            }else {
                              echo "bKash Merchant";
                            } ?></div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="form-group">
                  <label for="exampleFormControlInput1">How much do you want to pay?</label>
                  <input class="form-control form-control-solid" id="exampleFormControlInput1" type="number" name="peoney" placeholder="00" value="<?php echo $row['PEONEY']; ?>">
                </div>

                <div class="form-group mt-2">
                  <label for="exampleFormControlInput5">Have any comments or instructions?</label>
                  <input class="form-control form-control-solid" id="exampleFormControlInput5" type="text" name="comments" >
                </div>
                <div class=" pt-3">
                  <input name="upload_image" class="form-control form-control" id="formFileLg" type="file" />
                  </div>
                <?php
                    break;
                  case "3":
                ?><div class="d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center">
                        <img src="https://download.logo.wine/logo/Nagad/Nagad-Logo.wine.png" width="full" height="25">
                        <div class="ml-4">
                            <div class="small"><?php echo $row1['payAccount_number']; ?></div>
                            <div class="text-xs text-muted"><?php if ($row1['payAccount_typeof'] == "1") {
                              echo "Nagad Parsonal";
                            }else {
                              echo "Nagad Merchant";
                            } ?></div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="form-group">
                  <label for="exampleFormControlInput1">How much do you want to pay?</label>
                  <input class="form-control form-control-solid" id="exampleFormControlInput1" type="number" name="peoney" placeholder="00" value="<?php echo $row['PEONEY']; ?>">
                </div>

                <div class="form-group mt-2">
                  <label for="exampleFormControlInput5">Have any comments or instructions?</label>
                  <input class="form-control form-control-solid" id="exampleFormControlInput5" type="text" name="comments" >
                </div>
                <div class=" pt-3">
                  <input name="upload_image" class="form-control form-control" id="formFileLg" type="file" />
                  </div>
                <?php
                    break;
                  case "4":
                ?><div class="d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center">
                        <img src="https://seeklogo.com/images/D/dutch-bangla-rocket-logo-B4D1CC458D-seeklogo.com.png" width="full" height="25">
                        <div class="ml-4">
                            <div class="small"><?php echo $row1['payAccount_number']; ?></div>
                            <div class="text-xs text-muted"><?php if ($row1['payAccount_typeof'] == "1") {
                              echo "Rocket Parsonal";
                            }else {
                              echo "Rocket Merchant";
                            } ?></div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="form-group">
                  <label for="exampleFormControlInput1">How much do you want to pay?</label>
                  <input class="form-control form-control-solid" id="exampleFormControlInput1" type="number" name="peoney" placeholder="00" value="<?php echo $row['PEONEY']; ?>">
                </div>

                <div class="form-group mt-2">
                  <label for="exampleFormControlInput5">Have any comments or instructions?</label>
                  <input class="form-control form-control-solid" id="exampleFormControlInput5" type="text" name="comments" >
                </div>
                <div class=" pt-3">
                  <input name="upload_image" class="form-control form-control" id="formFileLg" type="file" />
                  </div>
                <?php
                    break;
                  case "5":
                ?><div class="d-flex align-items-center justify-content-between">
                    <div class="d-flex align-items-center">
                      <img src="https://seeklogo.com/images/E/eastern-bank-limited-logo-3DD509DA8B-seeklogo.com.png" width="full" height="25">
                        <div class="ml-4">
                          <div class="small"><?php echo $row1['payAccount_owner']; ?> | <?php echo $row1['payAccount_number']; ?></div>
                          <div class="text-xs text-muted"><?php echo $row1['payAccount_branch']; ?> | EBL Card</div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="form-group">
                  <label for="exampleFormControlInput1">How much do you want to pay?</label>
                  <input class="form-control form-control-solid" id="exampleFormControlInput1" type="number" name="peoney" placeholder="00" value="<?php echo $row['PEONEY']; ?>">
                </div>

                <div class="form-group mt-2">
                  <label for="exampleFormControlInput5">Have any comments or instructions?</label>
                  <input class="form-control form-control-solid" id="exampleFormControlInput5" type="text" name="comments" >
                </div>
                <div class=" pt-3">
                  <input name="upload_image" class="form-control form-control" id="formFileLg" type="file" />
                  </div>
                <?php
                    break;
                  default:
                    echo "No Data!";
                }
              }}else {
                echo "The merchant did not add any payment gateway or default.";
              }
              ?>

            </div>
            <input type="hidden" name="oldbalench" value="<?php echo $row['PEONEY']; ?>">
            <input type="hidden" name="merchant" value="<?php echo $row['id']; ?>">
            <div class="modal-footer"><button class="btn btn-black" type="button" data-dismiss="modal">Close</button><input name="submit"  class="btn btn-primary" type="submit" value="Pay Now"></div>
          </form>
        </div>
    </div>
</div>
<!-- Pay Info -->







                      <?php } }?>
                                              </tbody>
                    </table>
                </div>
            </div>
        </div>


      <div class="card">
          <div class="card-header">Last transaction</div>
          <div class="card-body">
              <div class="datatable">
                  <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

 <?php
 include 'config.php';
 // Pagination
$limit = 10;
if (isset($_GET['page'])) {
  $page = $_GET['page'];
}else {
  $page = 1;
}

$offset = ($page - 1) * $limit;
// Pagination
 $query = "SELECT * FROM statement
  LEFT JOIN merchant ON statement.statement_merchant = merchant.id
  ORDER BY statement_id DESC LIMIT {$offset},{$limit}";
 $result = mysqli_query($connection,$query) or die("Query Faield.");
 $count = mysqli_num_rows($result);
 if ($count>0) {
 ?>

                      <thead>
                          <tr>
                              <th>ID</th>
                              <th>Time and date</th>
                              <th>Money sent</th>
                              <th>Merchant</th>
                          </tr>
                      </thead>
                      <tfoot>
                          <tr>
                            <th>ID</th>
                            <th>Time and date</th>
                            <th>Money sent</th>
                            <th>Merchant</th>
                          </tr>
                      </tfoot>



                      <tbody>
 <?php
 while ($row = mysqli_fetch_assoc($result)) {
 ?>
                          <tr>
                              <td><?php echo $row['statement_trid']; ?></td>
                              <td><?php echo $row['statement_date']; ?> </td>
                              <td><?php echo $row['statement_credit_amount']; ?></td>
                              <td><?php echo $row['business']; ?></td>
                          </tr>
                          <?php } ?>
                      </tbody>
                      <?php } ?>
                  </table>
              </div>
              <!-- pagination -->
<?php
include 'config.php';
$queryPagi = "SELECT * FROM statement";
$ResultPagi = mysqli_query($connection,$queryPagi) or die("Pagination Err");
if (mysqli_num_rows($ResultPagi)) {
  $total_records = mysqli_num_rows($ResultPagi);
  $totalPage = ceil($total_records/$limit);
  echo "<nav aria-label='Page navigation example mt-5'>
    <ul class='pagination justify-content-center'>";
      if ($page > 1) {
        echo "<li class='page-item'><a class='page-link' href='{$_SERVER['PHP_SELF']}?page=".($page-1)."' tabindex='-1' aria-disabled='true'>Back</a>
        </li>";
      }else {
        echo "<li class='page-item disabled'><a class='page-link' href='{$_SERVER['PHP_SELF']}?page=".($page-1)."' tabindex='-1' aria-disabled='true'>Back</a>
        </li>";
      }


  for ($i= 1; $i <= $totalPage; $i++) {
    if ($i == $page) {
      $active = "active";
    }else {
      $active = "";
    }

    echo "<li class='page-item ".$active."'><a class='page-link' href='{$_SERVER['PHP_SELF']}?page=".$i."'>".$i."</a></li>";


  }
  if ($totalPage > $page) {
    echo "
    <li class='page-item '>
     <a class='page-link' href='{$_SERVER['PHP_SELF']}?page=".($page+1)."'>Next</a>
        </li>";
  }else {
    echo "
    <li class='page-item disabled'>
     <a class='page-link' href=''>Next</a>
        </li>";
  }


      echo "</ul>
  </nav>";
}


?>





<!-- pagination -->
          </div>
      </div>
  </div>

</main>
<?php }else {
  header("location: index.php");
  die;
} ?>
<?php include 'footer.php';?>
