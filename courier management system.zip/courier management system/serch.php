<?php
$title = "সার্চ রেজাল্ট";
 include 'menu.php';?>
<main>
   <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
      <div class="container">
         <div class="page-header-content pt-4">
            <div class="row align-items-center justify-content-between">
               <div class="col-auto mt-4">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i class="fab fa-searchengin"></i></div>
                     পার্সেল সার্চ
                  </h1>
                  <div class="page-header-subtitle">অর্ডার আইডি দিয়ে খুজন যেকোন পার্সেল</div>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- Main page content-->
   <div class="container mt-n10">
      <div class="card mb-4">
         <div class="card-header">সার্চ পার্সেল &nbsp;
            <a href="addParcel.php" class="btn btn-outline-primary btn-icon btn-sm">
            <i class="fas fa-plus-circle"></i>
            </a>
         </div>
         <div class="card-body">
            <div class="datatable">
               <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

                  <?php

                  if (isset($_GET['serch'])) {
                    $parcel_id = $_GET['serch'];
                     include 'config.php';
                     if ($_SESSION['role']== '5') {
                     $query = "SELECT * FROM parcel
                     LEFT JOIN services ON parcel.c_service = services.id
                     LEFT JOIN area ON parcel.c_area = area.id
                     LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                     LEFT JOIN action ON parcel.c_action = action.action_id
                     WHERE parcel.parcel_id LIKE '%$parcel_id%' or parcel.trId LIKE '%$parcel_id%' or parcel.c_name LIKE '%$parcel_id%' or parcel.c_Inv LIKE '%$parcel_id%' or parcel.c_number LIKE '%$parcel_id%' or parcel.c_address LIKE '%$parcel_id%' ";
                     }elseif ($_SESSION['role']== '1') {
                     $query = "SELECT * FROM parcel
                     LEFT JOIN services ON parcel.c_service = services.id
                     LEFT JOIN area ON parcel.c_area = area.id
                     LEFT JOIN merchant ON parcel.c_m_business = merchant.id
                     LEFT JOIN action ON parcel.c_action = action.action_id
                     WHERE parcel.c_m_business = {$_SESSION['id']} and (parcel.parcel_id LIKE '%$parcel_id%' or parcel.trId LIKE '%$parcel_id%' or parcel.c_name LIKE '%$parcel_id%' or parcel.c_Inv LIKE '%$parcel_id%' or parcel.c_number LIKE '%$parcel_id%'
                       or parcel.c_address LIKE '%$parcel_id%') ";
                     }else {
                     ?>
                  <div class="container p-5">
                     <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                     </div>
                     <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                        <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                        <hr>
                        <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                     </div>
                  </div>
                  <?php
                     die;
                     }
?>


<?php
                     $result = mysqli_query($connection,$query) or die("Query Faield.");
                     $count = mysqli_num_rows($result);
                   }
                     ?>
                  <thead>
                     <tr>
                        <th>আইডি</th>
                        <th>প্রেরক</th>
                        <th>প্রাপক</th>
                        <th>নোট</th>
                        <th>স্টাটাস</th>
                        <th>অ্যাকশান</th>
                     </tr>
                  </thead>
                  <tfoot>
                     <tr>
                        <th>আইডি</th>
                        <th>প্রেরক</th>
                        <th>প্রাপক</th>
                        <th>নোট</th>
                        <th>স্টাটাস</th>
                        <th>অ্যাকশান</th>
                     </tr>
                  </tfoot>
                  <tbody>
                     <?php
                        if ($count>0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                          ?>
                     <tr>
                        <td class="th-sm">
                          <?php
                          if ($row['trId']=="") {
                            echo "<span class='text-green'>PEON786592". $row['parcel_id']."</span><br>";
                          }else {
                            echo "<span class='text-green'>". $row['trId']."</span><br>";
                          }
                           ?>
                           M.Inv:<?php echo $row['c_Inv']; ?><br>
                           <?php echo $row['Ptime']; ?> <br>
                           <?php echo $row['Pdate']; ?>
                        </td>
                        <td class="th-sm cb">
                           <?php echo $row['business']; ?> <br>
                           <?php echo $row['number']; ?>  <br>
                           <?php echo $row['address']; ?>
                           <div class="row ">
                              <div class="col-md-12">
                                 <div class="row">
                                    <div class="col-md-6">
                                       <span class="text-green font-weight-900"> ওজন: <?php echo $row['weight']; ?> কেজি</span>
                                    </div>
                                    <div class="col-md-6">
                                       <span class="text-green font-weight-900">
                                          চার্জ:  <?php

                                        echo $row['c_charge'];

                                           ?> &#2547;

                                        </span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </td>
                        <td class="th-sm cb">
                           <?php echo $row['c_name'];?> <br>
                           <?php echo $row['c_number']; ?>,  <?php echo $row['c_b_number']; ?>  <br>
                           <?php echo $row['c_address']; ?>
                           <span class="text font-weight-900"> এরিয়া: <?php echo $row['area_name']; ?></span>
                           <div class="row ">
                              <div class="col-md-12">
                                 <span class="text-green font-weight-900"> ক্যাশ কালেকশান: <?php echo $row['c_price']; ?> &#2547;</span>
                              </div>
                           </div>
                        </td>
                        <td class="th-sm cbNote">
                        <?php echo $row['note'];?>
                        </td>
                        <td>
                           <?php
                              if ($row['c_action']==1) {
                                  echo "<div class='badge badge-danger badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==2){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==3){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==4){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==5){
                                  echo "<div class='badge badge-green badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==6){
                                  echo "<div class='badge badge-dark badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==7){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==8){
                                  echo "<div class='badge badge-dark badge-pill'>".$row['action_name']."</div>";
                              }
                              else {
                                echo "<div class='badge badge-warning badge-pill'>".$row['action_name']."</div>";
                              }
                              ?>
                           <br>
                           <?php
                              if ($row['c_service']==1) {
                                  echo "<div class='badge badge-danger badge-pill'>".$row['sName']."</div>";
                              }
                              else if($row['c_service']==2){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['sName']."</div>";
                              }
                              else {
                                echo "<div class='badge badge-warning badge-pill'>".$row['sName']."</div>";
                              }
                              ?>
                        </td>
                        <td>
                             <?php if ($_SESSION['role'] =='5') {?>
   <button href="view_merchant.php?id=<?php echo $row['id']; ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="dropdownFadeInUp<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm">
     <i data-feather="more-vertical"></i>
   </button>
 <?php } ?>
<div class="dropdown-menu animated--fade-in-up" aria-labelledby="dropdownFadeInUp<?php echo $row['parcel_id'];?>">
  <!-- Delete Dropdown Button -->
<a data-toggle="modal" data-target="#exampleModalSm<?php echo $row['parcel_id']; ?>" class="dropdown-item text-danger" >ডিলিট</a>

    <!-- Delete Dropdown Button -->
                           </div>
                           <!-- Small modal -->
                           <div class="modal fade" id="exampleModalSm<?php echo $row['parcel_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                              <div class="modal-dialog modal-sm" role="document">
                                 <div class="modal-content">
                                    <div class="modal-header">
                                       <h5 class="modal-title">গুরুত্বপূর্ণ ব্যাপার</h5>
                                       <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                    </div>
                                    <div class="modal-body">
                                       <p>আপনি কি PEON00<?php echo $row['parcel_id']; ?> পার্সেল ডিলিট করতে চাচ্ছেন?</p>
                                    </div>
                                    <div class="modal-footer">
                                       <button class="btn btn-primary" type="button" data-dismiss="modal">না! থাক</button>
                   <a class="btn btn-danger" type="button" href="delete_parcel.php?MasRiaKib=<?php echo $row['parcel_id']; ?>">ডিলিট</a>
                                    </div>
                                 </div>
                              </div>
                           </div>

                           <a href="viewParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="fas fa-eye"></i></a>
                              <?php if ($_SESSION['role'] =='5') {?>
                           <a href="updateParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="far fa-edit"></i></a>
                         <?php } ?>
                           <a class="btn btn-outline-primary btn-icon btn-sm" onclick="window.open('print_parcel.php?id=<?php echo $row['parcel_id']; ?>','POPUP WINDOW TITLE HERE','').print()"><i class="fas fa-print"></i></a>

                        </td>
                     </tr>
                     <?php } ?>
                  </tbody>
                  <?php } ?>
               </table>

            </div>
         </div>
      </div>
   </div>
</main>
<?php include 'footer.php';?>
