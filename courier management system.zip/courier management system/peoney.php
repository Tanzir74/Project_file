<?php
 $title = "Payment";
 include 'menu.php';
 if ($_SESSION['role']== '5') {
   $user_id = $_GET['id'];
 }elseif ($_SESSION['role']== '1') {
   $user_id = $_SESSION['id'];
 }
 ?>

<main>
    <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
        <div class="container-fluid">
            <div class="page-header-content">
                <div class="row align-items-center justify-content-between pt-3">
                    <div class="col-auto mb-3">
                        <h1 class="page-header-title">
                            <div class="page-header-icon"><i class="fas fa-money-check"></i></div>
                            Payment settings
                        </h1>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Main page content-->
    <div class="container mt-4">
        <!-- Account page navigation-->
        <nav class="nav nav-borders">
          <a class="nav-link " href="profile.php?id=<?php echo $user_id; ?>">Profile</a>
          <a class="nav-link active ml-0" href="peoney.php?id=<?php echo $user_id; ?>">Payment</a>
        </nav>
        <hr class="mt-0 mb-4" />
        <div class="row">
            <div class="col-lg-4 mb-4">
              <?php
                                            include 'config.php';
                                            $querybl = "SELECT * FROM merchant WHERE id = {$user_id}";
                                            $resultbl = mysqli_query($connection,$querybl) or die("Query Faield.");
                                            $countbl = mysqli_num_rows($resultbl);


                                            if ($countbl>0) {
                                            while ($rowbl = mysqli_fetch_assoc($resultbl)) { ?>
                <!-- Billing card 1-->
                <div class="card h-70 border-left-lg border-left-primary">
                    <div class="card-body">
                        <div class="small text-muted">Current balance</div>
                        <div class="h1">৳ <?php echo $rowbl['PEONEY']; ?></div>
                    </div>
                </div>
              <?php }} ?>
            </div>
            <div class="col-lg-4 mb-4">
                <!-- Billing card 2-->
                <?php
                $lastpay = "Didn't start";
                include 'config.php';
                $querylast = "SELECT * FROM statement WHERE statement_merchant = {$user_id}
                ORDER BY statement_id  DESC  LIMIT 1
                ";
                $resultlast = mysqli_query($connection,$querylast) or die("Query Faield.");
                $countlast = mysqli_num_rows($resultlast);


                if ($countlast>0) {
                while ($rowlast = mysqli_fetch_assoc($resultlast)) {
                  $lastpay = $rowlast['statement_date'];
                 }} ?>
                <div class="card h-70 border-left-lg border-left-primary">
                    <div class="card-body">
                        <div class="small text-muted">Last payment</div>
                        <div class="h3"><?php echo $lastpay; ?></div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 mb-4">
                <!-- Billing card 3-->
                <?php
                $query = "SELECT * FROM parcel
                WHERE c_m_business = {$user_id}";
                $result = mysqli_query($connection,$query) or die("Query Faield.");
                $count = mysqli_num_rows($result);
                if ($count <= "100") {
                  $labe= "Basic";
                }elseif ($count <= "50"){
                  $labe= "Starter";
                }elseif ($count <= "100"){
                  $labe= "Growing";
                }elseif ($count <= "170"){
                  $labe= "Professional";
                }elseif ($count <= "250"){
                  $labe= "Professional Gold";
                }elseif ($count <= "400"){
                  $labe= "Startup";
                }elseif ($count <= "500"){
                  $labe= "Special relatives";
                }elseif ($count <= "800"){
                  $labe= "Partner";
                }elseif ($count <= "1000000"){
                  $labe= "Gold Partner";
                }else{
                  $labe= "General";
                }
                 ?>
                <div class="card h-70 border-left-lg border-left-primary">
                    <div class="card-body">
                        <div class="small text-muted">Merchant category</div>
                        <div class="h3 d-flex align-items-center"><?php echo $labe; ?></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Payment methods card-->
        <div class="row">
          <div class="col-md-8">
            <!-- statement -->
            <div class="card">
                <div class="card-header">Payment statement</div>
                <div class="card-body">
                    <div class="datatable">
                        <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

       <?php
       include 'config.php';
       // Pagination
      $limit = 10;
      if (isset($_GET['page'])) {
        $page = $_GET['page'];
      }else {
        $page = 1;
      }

      $offset = ($page - 1) * $limit;
      // Pagination
       $query = "SELECT * FROM statement
        LEFT JOIN merchant ON statement.statement_merchant = merchant.id
        WHERE statement_merchant = {$user_id}
        ORDER BY statement_id DESC LIMIT {$offset},{$limit}";
       $result = mysqli_query($connection,$query) or die("Query Faield.");
       $count = mysqli_num_rows($result);
       if ($count>0) {
       ?>

                            <tfoot>
                                <tr>
                                    <th>ID</th>
                                    <th>Time and date</th>
                                    <th>Comments</th>
                                    <th>Money sent</th>
                                    <th>Balance</th>
                                </tr>
                            </tfoot>
                            <tfoot>
                                <tr>
                                  <th>ID</th>
                                  <th>Time and date</th>
                                  <th>Comments</th>
                                  <th>Money sent</th>
                                  <th>Balance</th>
                                </tr>
                            </tfoot>



                            <tbody>
       <?php
       while ($row = mysqli_fetch_assoc($result)) {
       ?>
                                <tr>
                                    <td>
                                      <?php if (!$row['statement_file']== "") { ?>
                                        <a href="<?php echo $row['statement_file']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="fas fa-download"></i></a>
                                        <?php } ?>
                                      <?php echo $row['statement_trid']; ?> </td>
                                    <td><?php echo $row['statement_date']; ?> <br><?php echo $row['statement_time']; ?> </td>
                                    <td><?php echo $row['statement_comment']; ?></td>
                                    <td><?php echo $row['statement_credit_amount']; ?></td>
                                    <td><?php echo $row['statement_balance']; ?></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                            <?php } ?>
                        </table>
                    </div>
                    <!-- pagination -->
      <?php
      include 'config.php';
      $queryPagi = "SELECT * FROM statement
      WHERE statement_merchant = {$user_id}";
      $ResultPagi = mysqli_query($connection,$queryPagi) or die("Pagination Err");
      if (mysqli_num_rows($ResultPagi)) {
        $total_records = mysqli_num_rows($ResultPagi);
        $totalPage = ceil($total_records/$limit);
        echo "<nav aria-label='Page navigation example mt-5'>
          <ul class='pagination justify-content-center'>";
            if ($page > 1) {
              echo "<li class='page-item'><a class='page-link' href='{$_SERVER['PHP_SELF']}?page=".($page-1)."' tabindex='-1' aria-disabled='true'>Back</a>
              </li>";
            }else {
              echo "<li class='page-item disabled'><a class='page-link' href='{$_SERVER['PHP_SELF']}?page=".($page-1)."' tabindex='-1' aria-disabled='true'>Back</a>
              </li>";
            }


        for ($i= 1; $i <= $totalPage; $i++) {
          if ($i == $page) {
            $active = "active";
          }else {
            $active = "";
          }

          echo "<li class='page-item ".$active."'><a class='page-link' href='{$_SERVER['PHP_SELF']}?page=".$i."'>".$i."</a></li>";


        }
        if ($totalPage > $page) {
          echo "
          <li class='page-item '>
           <a class='page-link' href='{$_SERVER['PHP_SELF']}?page=".($page+1)."'>Next</a>
              </li>";
        }else {
          echo "
          <li class='page-item disabled'>
           <a class='page-link' href=''>Next</a>
              </li>";
        }


            echo "</ul>
        </nav>";
      }


      ?>





      <!-- pagination -->
                </div>
            </div>


            <!-- statement -->
          </div>
          <div class="col-md-4">
            <div class="card card-header-actions mb-4">
                <div class="card-header text-black">
                    Payment method
                    <a class="btn btn-sm btn-outline-primary" href="addPament.php" type="button">Add new payment</a>
                </div>
                <div class="card-body">
                    <!-- Payment method 1-->
                    <?php
                    include 'config.php';
                    $query1 = "SELECT * FROM payaccount WHERE payAccount_merchant = {$user_id}";
                    $result1 = mysqli_query($connection,$query1) or die("Query Faield.");
                    $count1 = mysqli_num_rows($result1);
                    if ($count1>0) {
                    while ($row1 = mysqli_fetch_assoc($result1)) {
                      $PaymentGateway = $row1['payAccount_type'];

                      switch ($PaymentGateway) {
                        case "1":
                      ?>
                      <div class="d-flex align-items-center justify-content-between">
                          <div class="d-flex align-items-center">
                          <i class="fas fa-university fa-2x"></i>
                              <div class="ml-4">
                                  <div class="small"><?php echo $row1['payAccount_owner']; ?> | <?php echo $row1['payAccount_number']; ?></div>
                                  <div class="text-xs text-muted"><?php echo $row1['payAccount_branch']; ?> | <?php echo $row1['payAccount_name']; ?></div>
                              </div>
                          </div>
                          <div class="ml-4 small">
                            <?php if ($row1['payAccount_default'] == "1") {
                            ?><div class="badge badge-light mr-3">Default</div><?php
                          }else {
                            ?><a class="text-muted mr-3" href="defult_pay.php?id=<?php echo $row1['payAccount_id'];?>&mr=<?php echo $row1['payAccount_merchant'];?>">Make Default</a><?php
                          } ?>
                      <?php  if ($_SESSION['role']== '5') { ?>
                        <a href="delete_pay.php?id=<?php echo $row1['payAccount_id'];?>">Delete</a>
                      <?php } ?>
                           </div>
                      </div>
                      <hr>
                      <?php
                          break;
                        case "2":
                      ?>
                      <div class="d-flex align-items-center justify-content-between">
                          <div class="d-flex align-items-center">
                              <img src="images/bkash.png" width="full" height="25">
                              <div class="ml-4">
                                  <div class="small"><?php echo $row1['payAccount_number']; ?></div>
                                  <div class="text-xs text-muted"><?php if ($row1['payAccount_typeof'] == "1") {
                                    echo "bKash Parsonal";
                                  }else {
                                    echo "bKash Merchant";
                                  } ?></div>
                              </div>
                          </div>
                          <div class="ml-4 small">
                            <?php if ($row1['payAccount_default'] == "1") {
                            ?><div class="badge badge-light mr-3">Default</div><?php
                          }else {
                            ?><a class="text-muted mr-3" href="defult_pay.php?id=<?php echo $row1['payAccount_id'];?>&mr=<?php echo $row1['payAccount_merchant'];?>">Make Default</a><?php
                          } ?>
                          <?php  if ($_SESSION['role']== '5') { ?>
                            <a href="delete_pay.php?id=<?php echo $row1['payAccount_id'];?>">Delete</a>
                          <?php } ?>
                           </div>
                      </div>
                      <hr>
                      <?php
                          break;
                        case "3":
                      ?><div class="d-flex align-items-center justify-content-between">
                          <div class="d-flex align-items-center">
                              <img src="https://download.logo.wine/logo/Nagad/Nagad-Logo.wine.png" width="full" height="25">
                              <div class="ml-4">
                                  <div class="small"><?php echo $row1['payAccount_number']; ?></div>
                                  <div class="text-xs text-muted"><?php if ($row1['payAccount_typeof'] == "1") {
                                    echo "Nagad Parsonal";
                                  }else {
                                    echo "Nagad Merchant";
                                  } ?></div>
                              </div>
                          </div>
                          <div class="ml-4 small">
                            <?php if ($row1['payAccount_default'] == "1") {
                            ?><div class="badge badge-light mr-3">Default</div><?php
                          }else {
                            ?><a class="text-muted mr-3" href="defult_pay.php?id=<?php echo $row1['payAccount_id'];?>&mr=<?php echo $row1['payAccount_merchant'];?>">Make Default</a><?php
                          } ?>
                          <?php  if ($_SESSION['role']== '5') { ?>
                            <a href="delete_pay.php?id=<?php echo $row1['payAccount_id'];?>">Delete</a>
                          <?php } ?>
                           </div>
                      </div>
                      <hr>
                      <?php
                          break;
                        case "4":
                      ?><div class="d-flex align-items-center justify-content-between">
                          <div class="d-flex align-items-center">
                              <img src="https://seeklogo.com/images/D/dutch-bangla-rocket-logo-B4D1CC458D-seeklogo.com.png" width="full" height="25">
                              <div class="ml-4">
                                  <div class="small"><?php echo $row1['payAccount_number']; ?></div>
                                  <div class="text-xs text-muted"><?php if ($row1['payAccount_typeof'] == "1") {
                                    echo "Rocket Parsonal";
                                  }else {
                                    echo "Rocket Merchant";
                                  } ?></div>
                              </div>
                          </div>
                          <div class="ml-4 small">
                            <?php if ($row1['payAccount_default'] == "1") {
                            ?><div class="badge badge-light mr-3">Default</div><?php
                          }else {
                            ?><a class="text-muted mr-3" href="defult_pay.php?id=<?php echo $row1['payAccount_id'];?>&mr=<?php echo $row1['payAccount_merchant'];?>">Make Default</a><?php
                          } ?>
                          <?php  if ($_SESSION['role']== '5') { ?>
                            <a href="delete_pay.php?id=<?php echo $row1['payAccount_id'];?>">Delete</a>
                          <?php } ?>
                           </div>
                      </div>
                      <hr>
                      <?php
                          break;
                        case "5":
                      ?><div class="d-flex align-items-center justify-content-between">
                          <div class="d-flex align-items-center">
                            <img src="https://seeklogo.com/images/E/eastern-bank-limited-logo-3DD509DA8B-seeklogo.com.png" width="full" height="25">
                              <div class="ml-4">
                                <div class="small"><?php echo $row1['payAccount_owner']; ?> | <?php echo $row1['payAccount_number']; ?></div>
                                <div class="text-xs text-muted"><?php echo $row1['payAccount_branch']; ?> | EBL Card</div>
                              </div>
                          </div>
                          <div class="ml-4 small">
                            <?php if ($row1['payAccount_default'] == "1") {
                            ?><div class="badge badge-light mr-3">Default</div><?php
                          }else {
                            ?><a class="text-muted mr-3" href="defult_pay.php?id=<?php echo $row1['payAccount_id'];?>&mr=<?php echo $row1['payAccount_merchant'];?>">Make Default</a><?php
                          } ?>
                          <?php  if ($_SESSION['role']== '5') { ?>
                            <a href="delete_pay.php?id=<?php echo $row1['payAccount_id'];?>">Delete</a>
                          <?php } ?>
                           </div>
                      </div>
                      <hr>

                      <?php
                          break;
                        default:
                          echo "No Data!";
                      }
                    }}
                    ?>
        </div>
        </div>
          </div>
        </div>

</main>
<?php include 'footer.php'; ?>
