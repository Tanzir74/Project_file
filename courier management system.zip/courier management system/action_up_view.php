<?php ob_start(); ?>
<?php include 'menu.php'; ?>
    <?php
if (isset($_POST['submit']))
{
    include 'config.php';

    $c_hero = $_POST["c_heros"];
    $c_action = $_POST["c_action"];
    $parcel_id = $_POST["pid"];
    $c_m_business = $_POST["business"];
    $c_charge = $_POST["c_charge"];
    $c_price = $_POST["c_price"];
    $c_name = $_POST["c_name"];
    $trId = $_POST["trId"];
    $c_number = $_POST["c_number"];
    $c_service = $_POST["c_service"];
    $cherg = $_POST["cherg"];

     $rec_file = $_FILES['file'];
    // Auto ID Genaretor
    $all_keys = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y'
      ,'Z','1','2','3','4','5','6','7','8','9','0'
    );
    $rendomKey = "";
    for ($i=0; $i < 3; $i++) {
      shuffle($all_keys);
     $rendomKey .= $all_keys[0];
    }
    $loction= "";
    $image_name = $rec_file['name'];
    $image_tmp_name = $rec_file['tmp_name'];
    $filename = $_FILES['file']['name'];
    $ext = pathinfo($filename, PATHINFO_EXTENSION);
    date_default_timezone_set("Asia/Dhaka");
    $name_changer = date("MdDhiy").$rendomKey.".".$ext;
    if (!empty($image_name)) {
      $loction = "file/".$name_changer;
      move_uploaded_file($image_tmp_name, $loction);
    }
    // Photo


    $query1 = "UPDATE parcel SET
      c_hero ='{$c_hero}',
       c_action ='{$c_action}',
       c_charge ='{$cherg}',
       file ='{$loction}'
       WHERE parcel.parcel_id = {$parcel_id};";
    $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,reason) VALUE ('{$_POST["pid"]}','{$_POST["c_action"]}','{$_SESSION["name"]}','{$_POST["reason"]}');";

    if ($c_action == "5")
    {
        // Calculation
        $sum = 0;
        $totaldue = 0;
        $CODsumTotal = 0;
        $sum += $c_charge;
        $CODsumTotal += $c_price;
        $totaldue = $CODsumTotal - $sum;
        // Calculation
        $query1 .= "UPDATE merchant SET PEONEY = PEONEY + '$totaldue' WHERE merchant.id  = '$c_m_business';";
        $Pdate = strtoupper(date("d M y"));
        $query1 .= "UPDATE `parcel` SET `lastAction` = '$Pdate' WHERE `parcel_id` = '$parcel_id' ;";

    }
    elseif ($c_action == "9")
    {
        // Calculation
        $sum = 0;
        $sum += $c_charge;
        $query1 .= "UPDATE merchant SET PEONEY = PEONEY - $sum WHERE merchant.id  = '$c_m_business';";

        $Pdate = strtoupper(date("d M y"));
        $query1 .= "UPDATE `parcel` SET `lastAction` = '$Pdate' WHERE `parcel_id` = '$parcel_id' ;";

    }
    elseif ($c_action == "4"){
        if (!$trId == ""){
            $track = ".Track order: - http://www.track.peonbd.com?serch=" . $trId;
        }
        else {
            $track = ".Your Tracking Id: PEON786592" . $parcel_id;
        }
        $queryeh = "SELECT * FROM hero
        WHERE hero_id = {$c_hero}";
        $resulteh = mysqli_query($connection, $queryeh) or header("location: index.php");
        $counteh = mysqli_num_rows($resulteh);
        if ($counteh > 0)
        {
            while ($roweh = mysqli_fetch_assoc($resulteh))
            {
                // SMS
                $sercice = $c_service;

                switch ($sercice) {
                  case "1":
                  $to = $c_number;
                  $token = "69a9e1162ef97e9cc0f314fe26475048";
                  $message = "Assalamu Alaikum! Dear " .$c_name. "! " .$roweh['hero_name']." - ".$roweh['hero_mobile']. " will deliver your parcel today . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
                    break;
                  case "2":
                  $to = $c_number;
                  $token = "69a9e1162ef97e9cc0f314fe26475048";
                  $message = "Assalamu Alaikum! Dear " .$c_name. "! " .$roweh['hero_name']." - ".$roweh['hero_mobile']. " will deliver your parcel today . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
                    break;
                  case "3":
                  $to = $c_number;
                  $token = "69a9e1162ef97e9cc0f314fe26475048";
                  $message = "Assalamu Alaikum! Dear " .$c_name. "! " .$roweh['hero_name']." - ".$roweh['hero_mobile']. " will deliver your parcel today . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
                    break;
                  case "4":
                  $to = $c_number;
                  $token = "69a9e1162ef97e9cc0f314fe26475048";
                  $message = "Assalamu Alaikum! Dear " .$c_name. "! " .$roweh['hero_name']." - ".$roweh['hero_mobile']. " will deliver your parcel Within 3 days . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
                    break;
                  case "5":
                  $to = $c_number;
                  $token = "69a9e1162ef97e9cc0f314fe26475048";
                  $message = "Assalamu Alaikum! Dear " .$c_name. "! " .$roweh['hero_name']." - ".$roweh['hero_mobile']. " will deliver your parcel Within 3-7 days . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
                    break;
                  case "5":
                  $to = $c_number;
                  $token = "69a9e1162ef97e9cc0f314fe26475048";
                  $message = "Assalamu Alaikum! Dear " .$c_name. "! " .$roweh['hero_name']." - ".$roweh['hero_mobile']. " will deliver your parcel Within 2-3 days . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
                    break;
                  default:
                  $message = "Assalamu Alaikum! Dear " .$c_name. "! We will deliver your parcel within a short time . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
                }


                $url = "http://api.greenweb.com.bd/api.php?json";

                $data = array(
                    'to' => "$to",
                    'message' => "$message",
                    'token' => "$token"
                ); // Add parameters in key value
                $ch = curl_init(); // Initialize cURL
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_ENCODING, '');
                curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $smsresult = curl_exec($ch);

            }
        }
    }
    $result1 = mysqli_multi_query($connection, $query1) or die("ডাটা সেন্টার কানেক্ট হয়নি !" . mysqli_error());
    header('location: viewParcel.php?id=' . $parcel_id);
    bo_enf_fluch();
}

?>
