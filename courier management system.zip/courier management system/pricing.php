<?php
$title = "সার্ভিস বিস্তারিত";
include 'menu.php';?>
<main>
                   <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
                       <div class="container">
                           <div class="page-header-content pt-4">
                               <div class="row align-items-center justify-content-between">
                                   <div class="col-auto mt-4">
                                       <h1 class="page-header-title">
                                           <div class="page-header-icon"><i class="fas fa-th"></i></div>
                                           সার্ভিস বিস্তারিত
                                       </h1>
                                       <div class="page-header-subtitle">রেগুলার এবং কাস্টমাইজ সার্ভিসের সমাহার !</div>
                                   </div>
                               </div>
                           </div>
                       </div>
                   </header>
                   <!-- Main page content-->
                   <div class="container mt-n10">
                     <div class="card">
                         <div class="card-header">
                             <ul class="nav nav-pills card-header-pills" id="cardPill" role="tablist">
                                 <li class="nav-item"><a class="nav-link active" id="overview-pill" href="#overviewPill" data-toggle="tab" role="tab" aria-controls="overview" aria-selected="true">সেম ডে</a></li>
                                 <li class="nav-item"><a class="nav-link" id="example-pill" href="#examplePill" data-toggle="tab" role="tab" aria-controls="example" aria-selected="false">নেক্সট ডে</a></li>
                                 <li class="nav-item"><a class="nav-link" id="example-pill" href="#fragel" data-toggle="tab" role="tab" aria-controls="example" aria-selected="false">ফ্রোজেন</a></li>
                                 <li class="nav-item"><a class="nav-link" id="example-pill" href="#subCty" data-toggle="tab" role="tab" aria-controls="example" aria-selected="false">ঢাকা সাব-সিটি</a></li>
                                 <li class="nav-item"><a class="nav-link" id="example-pill" href="#outOfDhaka" data-toggle="tab" role="tab" aria-controls="example" aria-selected="false">আউট অফ ঢাকা</a></li>
                             </ul>
                         </div>
                         <div class="card-body">
                             <div class="tab-content" id="cardPillContent">
                                 <div class="tab-pane fade show active" id="overviewPill" role="tabpanel" aria-labelledby="overview-pill">
                                   <div class="row">
                                     <div class="col-md-6">


                                     <h2 class="card-title">সেম ডে ডেলিভারি সার্ভিস ! </h2>
                                     <p class="card-text">অপ্রতিদ্বন্দ্বী এ সার্ভিসে পিয়ন-ই একমাত্র যেখানে আপনি শতভাগ নিশ্চিত ডেলিভারি সার্ভিস গ্রহণ করতে পারবেন । এ সার্ভিসে ডেলিভারির টাইম সর্বচ্চ ১২ ঘন্টা ! সকাল ১০ টা থেকে রাত ১০ টার ভিতর । শুধুমাত্র ঢাকা সিটি কর্পোরেশন এরিয়া এই সার্ভিসের অন্তুর্ভুক্ত।<span class="d-inline-flex align-items-center bg-green-soft text-green font-weight-normal py-1 px-2 rounded"> সেম ডে ডেলিভারির জন্য পার্সেল এন্ট্রির সর্বশেষ সময় সকাল ১০ টা পর্যন্ত ।</span> আপনার কাজ শুধু সকাল ১০ টার ভিতর নিজ অ্যাকাউন্টে পার্সেল এন্ট্রি করা এর পর থেকেই শুরু আমাদের জার্নি ।  </p>
</div>
<div class="col-md-6 border">
                                    <!-- Table -->
            <table class="table mb-0">
                <thead>
                    <tr>
                        <th scope="col">ওজন</th>
                        <th scope="col">মূল্য</th>
                        <th scope="col">COD চার্জ</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td> ১ কেজি </td>
                        <td>১০০ টাকা</td>
                        <td>Free</td>
                    </tr>
                    <tr>
                        <td> ২ কেজি</td>
                        <td>১২০ টাকা</td>
                        <td>Free</td>
                    </tr>
                    <tr>
                        <td> ৩ কেজি</td>
                        <td>১৪০ টাকা</td>
                        <td>Free</td>
                    </tr>
                    <tr>
                        <td> ৪ কেজি</td>
                        <td>১৬০ টাকা</td>
                        <td>Free</td>
                    </tr>
                    <tr>
                        <td> ৫ কেজি</td>
                        <td>১৮০ টাকা</td>
                        <td>Free</td>
                    </tr>
                    <tr>
                        <td> ৬ কেজি</td>
                        <td>২০০ টাকা</td>
                        <td>Free</td>
                    </tr>
                    <tr>
                        <td> ৭ কেজি</td>
                        <td>২২০ টাকা</td>
                        <td>Free</td>
                    </tr>
                    <tr>
                        <td> ৮ কেজি</td>
                        <td>২৪০ টাকা</td>
                        <td>Free</td>
                    </tr>
                    <tr>
                        <td> ৯ কেজি</td>
                        <td>২৮০ টাকা</td>
                        <td>Free</td>
                    </tr>
                    <tr>
                        <td> ১০ কেজি</td>
                        <td>৩০০ টাকা</td>
                        <td>Free</td>
                    </tr>
                </tbody>
            </table>
  <!-- Table -->
  </div>
      </div>


                                 </div>
                                 <div class="tab-pane fade" id="examplePill" role="tabpanel" aria-labelledby="example-pill">
                                   <div class="row">
                                     <div class="col-md-6">
                                   <h2 class="card-title">নেক্সট ডে ডেলিভারি সার্ভিস ! </h2>
                                   <p class="card-text">রেগুলার এ সার্ভিসে পিয়নই একমাত্র যারা সময়মত ডেলিভার শতভাগ নিশ্চয়তা দেয়। এ সার্ভিসে ডেলিভারির টাইম পার্সেল ডেলিভারীর ঠিক পরদিনের ভিতর । শুধুমাত্র ঢাকা সিটি কর্পোরেশন এরিয়া এই সার্ভিসের অন্তুর্ভুক্ত।<span class="d-inline-flex align-items-center bg-green-soft text-green font-weight-normal py-1 px-2 rounded"> নেক্সট ডে ডেলিভারির জন্য পার্সেল এন্ট্রির সর্বশেষ সময় বিকাল ৩ টা পর্যন্ত ।</span> আপনার কাজ শুধু বিকাল ৩ টার ভিতর নিজ অ্যাকাউন্টে পার্সেল এন্ট্রি করা এর পর থেকেই শুরু আমাদের জার্নি ।  </p>
</div>
<div class="col-md-6 border">
                                  <!-- Table -->
          <table class="table mb-0">
              <thead>
                  <tr>
                      <th scope="col">ওজন</th>
                      <th scope="col">মূল্য</th>
                      <th scope="col">COD চার্জ</th>
                  </tr>
              </thead>
              <tbody>
                  <tr>
                      <td> ১ কেজি </td>
                      <td>৬০ টাকা</td>
                      <td>Free</td>

                  </tr>
                  <tr>
                      <td> ২ কেজি</td>
                      <td>৭৫ টাকা</td>
                      <td>Free</td>

                  </tr>
                  <tr>
                      <td> ৩ কেজি</td>
                      <td>৯০ টাকা</td>
                      <td>Free</td>

                  </tr>
                  <tr>
                      <td> ৪ কেজি</td>
                      <td>১০৫ টাকা</td>
                      <td>Free</td>
                  </tr>
                  <tr>
                      <td> ৫ কেজি</td>
                      <td>১২০ টাকা</td>
                      <td>Free</td>
                  </tr>
                  <tr>
                      <td> ৬ কেজি</td>
                      <td>১৩৫ টাকা</td>
                      <td>Free</td>
                  </tr>
                  <tr>
                      <td> ৭ কেজি</td>
                      <td>১৫০ টাকা</td>
                      <td>Free</td>
                  </tr>
                  <tr>
                      <td> ৮ কেজি</td>
                      <td>১৬৫ টাকা</td>
                      <td>Free</td>
                  </tr>
                  <tr>
                      <td> ৯ কেজি</td>
                      <td>১৮০ টাকা</td>
                      <td>Free</td>
                  </tr>
                  <tr>
                      <td> ১০ কেজি</td>
                      <td>১৯৫ টাকা</td>
                      <td>Free</td>
                  </tr>
              </tbody>
          </table>
<!-- Table -->
</div>
    </div>
                                 </div>

                                 <div class="tab-pane fade" id="fragel" role="tabpanel" aria-labelledby="example-pill">
                                   <div class="row">
                                     <div class="col-md-6">
                                   <h2 class="card-title">ফ্রোজেন ফুড ডেলিভারি সার্ভিস ! </h2>
                                   <p class="card-text">ফ্রোজেন ফুড ডেলিভারির এ সার্ভিসে পিয়ন- মাছ, মাংস সহ সকল ধনের বরফজাত বা ফ্রোজেন ডেলিভার শতভাগ নিশ্চয়তা দেয়। এ সার্ভিসে ডেলিভারির টাইম সর্বচ্চ ৮ ঘন্টা ! সকাল ৯ টা থেকে বিকাল ৫ টার ভিতর । শুধুমাত্র ঢাকা সিটি কর্পোরেশন এরিয়া এই সার্ভিসের অন্তুর্ভুক্ত । এবং সর্বনিন্ম অর্ডার ২০ টি পার্সেল। <span class="d-inline-flex align-items-center bg-green-soft text-green font-weight-normal py-1 px-2 rounded">ডেলিভারীরি আগের দিন বিকাল ৫টার আগেই ওয়েবসাইটে অর্ডার বুকিং করতে হবে।</span> আপনার কাজ শুধু ডেলিভারীরি আগের দিন বিকাল ৫ টার আগেই নিজ অ্যাকাউন্টে পার্সেল এন্ট্রি করা এর পর থেকেই শুরু আমাদের জার্নি ।  </p>
</div>
<div class="col-md-6 border">
                                  <!-- Table -->
                                  <table class="table mb-0">
                                      <thead>
                                          <tr>
                                              <th scope="col">ওজন</th>
                                              <th scope="col">মূল্য</th>
                                              <th scope="col">COD চার্জ</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                            <td> ১ কেজি </td>
                                            <td>১০০ টাকা</td>
                                            <td>১% </td>

                                        </tr>
                                        <tr>
                                            <td> ২ কেজি</td>
                                            <td>১২০ টাকা</td>
                                            <td>১% </td>

                                        </tr>
                                        <tr>
                                            <td> ৩ কেজি</td>
                                            <td>১৪০ টাকা</td>
                                            <td>১% </td>

                                        </tr>
                                        <tr>
                                            <td> ৪ কেজি</td>
                                            <td>১৬০ টাকা</td>
                                            <td>১% </td>
                                        </tr>
                                        <tr>
                                            <td> ৫ কেজি</td>
                                            <td>১৮০ টাকা</td>
                                            <td>১% </td>
                                        </tr>
                                        <tr>
                                            <td> ৬ কেজি</td>
                                            <td>২০০ টাকা</td>
                                            <td>১%  </td>
                                        </tr>
                                        <tr>
                                            <td> ৭ কেজি</td>
                                            <td>২২০ টাকা</td>
                                            <td>১% </td>
                                        </tr>
                                        <tr>
                                            <td> ৮ কেজি</td>
                                            <td>২৪০ টাকা</td>
                                            <td>১% </td>
                                        </tr>
                                        <tr>
                                            <td> ৯ কেজি</td>
                                            <td>২৬০ টাকা</td>
                                            <td>১% </td>
                                        </tr>
                                        <tr>
                                            <td> ১০ কেজি</td>
                                            <td>২৮০ টাকা</td>
                                            <td>১% </td>
                                        </tr>
                                      </tbody>
                                  </table>
<!-- Table -->
</div>
    </div>
                                 </div>

                                 <div class="tab-pane fade" id="subCty" role="tabpanel" aria-labelledby="example-pill">
                                   <div class="row">
                                     <div class="col-md-6">
                                   <h2 class="card-title">ঢাকার সাব-সিটি ডেলিভারি সার্ভিস ! </h2>
                                   <p class="card-text">ঢাকার সাব-সিটি এরিয়া গুলো যেন ঢাকাও নয়,আবার ঢাকার বাইরেও নয়! ঢাকা সিটি কর্পোরেশনের বাইরে কিন্তু ঢাকা জেলার অন্তর্ভুক্ত যেমনঃ সাভার,গাজিপুর,কেরানিগঞ্জ,ডেমর এরিয়া উল্লেখযোগ্য। এ সার্ভিসে ডেলিভারির টাইম সর্বচ্চ ৩ দিন ! <span class="d-inline-flex align-items-center bg-green-soft text-green font-weight-normal py-1 px-2 rounded"> ঢাকার সাব-সিটি ডেলিভারির জন্য পার্সেল এন্ট্রির সর্বশেষ সময় বিকাল ৩ টা পর্যন্ত ।</span> আপনার কাজ শুধু বিকাল ৩ টার ভিতর নিজ অ্যাকাউন্টে পার্সেল এন্ট্রি করা এর পর থেকেই শুরু আমাদের জার্নি ।    </p>
</div>
<div class="col-md-6 border">
                                  <!-- Table -->
                                  <table class="table mb-0">
                                      <thead>
                                          <tr>
                                              <th scope="col">ওজন</th>
                                              <th scope="col">মূল্য</th>
                                              <th scope="col">COD চার্জ</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                            <td> ১ কেজি </td>
                                            <td>১০০ টাকা</td>
                                            <td>১% </td>

                                        </tr>
                                        <tr>
                                            <td> ২ কেজি</td>
                                            <td>১১৫ টাকা</td>
                                            <td>১% </td>

                                        </tr>
                                        <tr>
                                            <td> ৩ কেজি</td>
                                            <td>১৩০ টাকা</td>
                                            <td>১% </td>

                                        </tr>
                                        <tr>
                                            <td> ৪ কেজি</td>
                                            <td>১৪৫ টাকা</td>
                                            <td>১% </td>
                                        </tr>
                                        <tr>
                                            <td> ৫ কেজি</td>
                                            <td>১৬০ টাকা</td>
                                            <td>১% </td>
                                        </tr>
                                      </tbody>
                                  </table>
<!-- Table -->
</div>
    </div>
                                 </div>

                                 <div class="tab-pane fade" id="outOfDhaka" role="tabpanel" aria-labelledby="example-pill">
                                   <div class="row">
                                     <div class="col-md-6">
                                   <h2 class="card-title">আউট অফ ঢাকা ডেলিভারি সার্ভিস ! </h2>
                                   <p class="card-text">ঢাকার জেলার বাইরে সকল এরিয়া -এ সার্ভিসের অন্তভুক্ত । এ সার্ভিসে ডেলিভারির টাইম সর্বচ্চ ৩-৫ দিন ! <span class="d-inline-flex align-items-center bg-green-soft text-green font-weight-normal py-1 px-2 rounded"> ঢাকার সাব-সিটি ডেলিভারির জন্য পার্সেল এন্ট্রির সর্বশেষ সময় বিকাল ৩ টা পর্যন্ত ।</span> আপনার কাজ শুধু বিকাল ৩ টার ভিতর নিজ অ্যাকাউন্টে পার্সেল এন্ট্রি করা এর পর থেকেই শুরু আমাদের জার্নি ।    </p>
</div>
<div class="col-md-6 border">
                                  <!-- Table -->
                                  <table class="table mb-0">
                                      <thead>
                                          <tr>
                                              <th scope="col">ওজন</th>
                                              <th scope="col">মূল্য</th>
                                              <th scope="col">COD চার্জ</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                            <td> ১ কেজি </td>
                                            <td>১৩০ টাকা</td>
                                            <td>১% </td>

                                        </tr>
                                        <tr>
                                            <td> ২ কেজি</td>
                                            <td>১৬০ টাকা</td>
                                            <td>১% </td>

                                        </tr>
                                        <tr>
                                            <td> ৩ কেজি</td>
                                            <td>১৯০ টাকা</td>
                                            <td>১% </td>

                                        </tr>
                                        <tr>
                                            <td> ৪ কেজি</td>
                                            <td>২২০ টাকা</td>
                                            <td>১% </td>
                                        </tr>
                                        <tr>
                                            <td> ৫ কেজি</td>
                                            <td>২৫০ টাকা</td>
                                            <td>১% </td>
                                        </tr>
                                      </tbody>
                                  </table>
<!-- Table -->
</div>
    </div>
                                 </div>

                             </div>
                         </div>
                     </div>

    </div>


               </main>
<?php include 'footer.php';?>
