      <?php ob_start(); ?>
      <?php
      $parcel_id  = $_GET['id'];

      include 'config.php';


      $query2 = "UPDATE parcel
      SET c_action=1
      WHERE 	parcel_id ={$parcel_id}";
      $result2 = mysqli_query($connection,$query2) or die("Query Faield.");

      if ($result2) {
        header('location: parcel.php');
        bo_enf_fluch();
      }else{
      echo   "<div class='alert alert-primary' role='alert'>
          Delete Fail!
      </div>";
      }

       ?>
