<?php ob_start(); ?>
<?php
$area_id = $_GET['id'];

include 'config.php';
$query = "DELETE FROM `area` WHERE id = {$area_id}";
$result = mysqli_query($connection,$query) or die("Query Faield.");
if ($result) {
  header("location: area.php");
    bo_enf_fluch();
}else{
echo   "<div class='alert alert-primary' role='alert'>
    Delete Fail!
</div>";
}

 ?>
