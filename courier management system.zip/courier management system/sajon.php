<?php ob_start();
$title = "All Merchant";
 include 'menu.php';
if ($_SESSION['role']== '1' or $_SESSION['role']== '0') {
  header("location: index.php");
  die;
}
 ?>
<main>
    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
        <div class="container">
            <div class="page-header-content pt-4">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto mt-4">
                        <h1 class="page-header-title">
                            <div class="page-header-icon"><i class="fas fa-users"></i></div>
                            Merchant
                        </h1>
                        <div class="page-header-subtitle">Every merchant is important to us</div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Main page content-->
    <div class="container mt-n10">
        <div class="card mb-4">
            <div class="card-header">All merchants &nbsp;
            <a href="addSajon.php" class="btn btn-primary btn-xs btn-icon ">
            <i class="fas fa-plus-circle"></i>
          </a>
            </div>



            <div class="card-body">
                <div class="datatable">
                    <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

<?php
include 'config.php';
$query = "SELECT * FROM merchant ORDER BY id DESC";
$result = mysqli_query($connection,$query) or die("Query Faield.");
$count = mysqli_num_rows($result);
if ($count>0) {
?>

                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Business name</th>
                                <th>Office</th>
                                <th>No.</th>
                                <th>Start date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                              <th>Name</th>
                              <th>Business name</th>
                              <th>Office</th>
                              <th>No.</th>
                              <th>Start date</th>
                              <th>Status</th>
                              <th>Action</th>
                            </tr>
                        </tfoot>


                        <tbody>
<?php
while ($row = mysqli_fetch_assoc($result)) {
?>
                            <tr>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['business']; ?></td>
                                <td><?php echo $row['address']; ?></td>
                                <td><?php echo $row['number']; ?></td>
                                <td><?php echo $row['time']; ?></td>
                                <td>
                                  <?php
                            if ($row['role']==0) {
                              echo "<div class='badge badge-danger badge-pill'>Pending</div>";
                            }
                            else if($row['role']==1){
                              echo "<div class='badge badge-info badge-pill'>Active</div>";
                            }
                            else if($row['role']==5){
                              echo "<div class='badge badge-dark badge-pill'>Admin</div>";
                              }
                              else{
                                echo "De-active";
                              }

   ?></td>
                                <td>

                                    <button href="view_merchant.php?id=<?php echo $row['id']; ?>" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="dropdownFadeInUp<?php echo $row['id']; ?>" class="btn btn-datatable btn-icon btn-transparent-dark mr-2"><i data-feather="more-vertical"></i></button>
                                        <div class="dropdown-menu animated--fade-in-up" aria-labelledby="dropdownFadeInUp<?php echo $row['id']; ?>">
                                            <a data-toggle="modal" data-target="#staticBackdrops<?php echo $row['id']; ?>" class="dropdown-item"  >Status change</a>
                                            <!-- Delete -->
                                            <a data-toggle="modal" data-target="#exampleModalSm<?php echo $row['id']; ?>" class="dropdown-item text-danger" >Delete</a>
                                                    </div>
                                            <!-- Small modal -->

                                            <div class="modal fade" id="exampleModalSm<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-sm" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">Important thing</h5>
                                                            <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Do you want to delete <?php echo $row['business']; ?> Merchant? </p>
                                                        </div>
                                                        <div class="modal-footer">
                                                          <button class="btn btn-primary" type="button" data-dismiss="modal">No! Stay</button>
                                                          <a class="btn btn-danger" type="button" href="delete_sajon.php?id=<?php echo $row['id']; ?>">Yes Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <!-- Modal -->
                                            <div class="modal fade" id="staticBackdrops<?php echo $row['id']; ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="staticBackdropLabel">Role change</h5>
                                                            <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                                        </div>
                                                        <div class="modal-body">
                                                          <form class="" action="action_sajon.php" method="post">
                                                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                                            <input type="hidden" name="number" value="<?php echo $row['number']; ?>">
                                                            <input type="hidden" name="name" value="<?php echo $row['name']; ?>">
                                                              <select name="role" class="form-control" id="exampleFormControlSelect1">
                                                                  <option value="0">Pending</option>
                                                                  <option value="1">Active</option>
                                                              </select>

                                                        </div>
                                                        <div class="modal-footer"><button class="btn btn-dark" type="button" data-dismiss="modal">No, stay!</button>
                                                          <button class="btn btn-info my-4" type="submit" name="submit">Save</button>
                                                        </form>


                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                    <a href="profile.php?id=<?php echo $row['id']; ?>" class="btn btn-datatable btn-icon btn-transparent-dark"><i class="fas fa-user-edit"></i></a>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                        <?php } ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php include 'footer.php';?>
