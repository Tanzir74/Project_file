<?php
    $link= $_SERVER['PHP_SELF'];
    switch ($link) {
      case "/Version07.php":
      echo '<nav class="nav nav-borders">
          <a class="nav-link active ml-0" href="Version07.php">Version 0.7(Beta)</a>
          <a class="nav-link ml-0" href="Version06.php">Version 0.6(Beta)</a>
          <a class="nav-link ml-0" href="Version05.php">Version 0.5(Beta)</a>
          <a class="nav-link ml-0" href="Version04.php">Version 0.4(Beta)</a>
          <a class="nav-link ml-0" href="Version03.php">Version 0.3(Beta)</a>
          <a class="nav-link ml-0" href="VersionFeature.php">Version 0.2(Beta)</a>
      </nav>';
      break;


      case "/Version06.php":
      echo '<nav class="nav nav-borders">
          <a class="nav-link ml-0" href="Version07.php">Version 0.7(Beta)</a>
          <a class="nav-link active ml-0" href="Version06.php">Version 0.6(Beta)</a>
          <a class="nav-link ml-0" href="Version05.php">Version 0.5(Beta)</a>
          <a class="nav-link ml-0" href="Version04.php">Version 0.4(Beta)</a>
          <a class="nav-link ml-0" href="Version03.php">Version 0.3(Beta)</a>
          <a class="nav-link ml-0" href="VersionFeature.php">Version 0.2(Beta)</a>
      </nav>';
      break;

      case "/Version05.php":
      echo '<nav class="nav nav-borders">
                <a class="nav-link ml-0" href="Version07.php">Version 0.7(Beta)</a>
          <a class="nav-link ml-0" href="Version06.php">Version 0.6(Beta)</a>
          <a class="nav-link active ml-0" href="Version05.php">Version 0.5(Beta)</a>
          <a class="nav-link ml-0" href="Version04.php">Version 0.4(Beta)</a>
          <a class="nav-link ml-0" href="Version03.php">Version 0.3(Beta)</a>
          <a class="nav-link ml-0" href="VersionFeature.php">Version 0.2(Beta)</a>
      </nav>';
      break;

      case "/v3/Version04.php":
      echo '<nav class="nav nav-borders">
                <a class="nav-link ml-0" href="Version07.php">Version 0.7(Beta)</a>
          <a class="nav-link ml-0" href="Version06.php">Version 0.6(Beta)</a>
          <a class="nav-link ml-0" href="Version05.php">Version 0.5(Beta)</a>
          <a class="nav-link active ml-0" href="Version04.php">Version 0.4(Beta)</a>
          <a class="nav-link ml-0" href="Version03.php">Version 0.3(Beta)</a>
          <a class="nav-link ml-0" href="VersionFeature.php">Version 0.2(Beta)</a>
      </nav>';
      break;

      case "/Version03.php":
      echo '<nav class="nav nav-borders">
                <a class="nav-link ml-0" href="Version07.php">Version 0.7(Beta)</a>
          <a class="nav-link ml-0" href="Version06.php">Version 0.6(Beta)</a>
          <a class="nav-link ml-0" href="Version05.php">Version 0.5(Beta)</a>
          <a class="nav-link ml-0" href="Version04.php">Version 0.4(Beta)</a>
          <a class="nav-link active ml-0" href="Version03.php">Version 0.3(Beta)</a>
          <a class="nav-link ml-0" href="VersionFeature.php">Version 0.2(Beta)</a>
      </nav>';
      break;

      case "/v3/VersionFeature.php":
      echo '<nav class="nav nav-borders">
                <a class="nav-link ml-0" href="Version07.php">Version 0.7(Beta)</a>
          <a class="nav-link ml-0" href="Version06.php">Version 0.6(Beta)</a>
          <a class="nav-link ml-0" href="Version05.php">Version 0.5(Beta)</a>
          <a class="nav-link ml-0" href="Version04.php">Version 0.4(Beta)</a>
          <a class="nav-link ml-0" href="Version03.php">Version 0.3(Beta)</a>
          <a class="nav-link active ml-0" href="VersionFeature.php">Version 0.2(Beta)</a>
      </nav>';
      break;

      case "/Version01.php":
      echo '<nav class="nav nav-borders">
                <a class="nav-link ml-0" href="Version07.php">Version 0.7(Beta)</a>
          <a class="nav-link ml-0" href="Version06.php">Version 0.6(Beta)</a>
          <a class="nav-link ml-0" href="Version05.php">Version 0.5(Beta)</a>
          <a class="nav-link ml-0" href="Version04.php">Version 0.4(Beta)</a>
          <a class="nav-link ml-0" href="Version03.php">Version 0.3(Beta)</a>
          <a class="nav-link ml-0" href="VersionFeature.php">Version 0.2(Beta)</a>
      </nav>';
      break;

      default:
      echo '<nav class="nav nav-borders">
                <a class="nav-link ml-0" href="Version07.php">Version 0.7(Beta)</a>
          <a class="nav-link ml-0" href="Version06.php">Version 0.6(Beta)</a>
          <a class="nav-link ml-0" href="Version05.php">Version 0.5(Beta)</a>
          <a class="nav-link ml-0" href="Version04.php">Version 0.4(Beta)</a>
          <a class="nav-link ml-0" href="Version03.php">Version 0.3(Beta)</a>
          <a class="nav-link ml-0" href="VersionFeature.php">Version 0.2(Beta)</a>
      </nav>';
    }


 ?>
