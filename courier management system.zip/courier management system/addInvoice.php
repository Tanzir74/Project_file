<?php ob_start(); ?>
<?php $title = "ইনভয়েস যুক্তকরণ"; ?>
<?php include 'menu.php'; ?>
<?php
if ($_SESSION['role']== '5') {
 ?>
<?php
   if (isset($_POST['submit'])) {
   include 'config.php';
   $PEONID = mysqli_real_escape_string($connection,$_POST['PEONID']);
   $merchant = mysqli_real_escape_string($connection,$_POST['merchant']);
   $totalPrice = mysqli_real_escape_string($connection,$_POST['totalPrice']);
   $status_invoice	 = mysqli_real_escape_string($connection,$_POST['status_invoice']);
   $Trxid	 = mysqli_real_escape_string($connection,$_POST['Trxid']);
   $comment	 = mysqli_real_escape_string($connection,$_POST['comment']);




   $query1 = "INSERT INTO invoice (PEONID,merchant,totalPrice,status_invoice,Trxid,comment)
   VALUE ('$PEONID','$merchant','$totalPrice','$status_invoice','$Trxid','$comment')";

   if (mysqli_query($connection,$query1)) {
   header('location: invoice.php');
   bo_enf_fluch();
   }else {
   echo "কিউরি ফেইল হয়েছ";
   }
  }

   ?>


<main>
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
      <div class="container-fluid">
         <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
               <div class="col-auto mb-3">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i class="fas fa-scroll"></i></div>
                     পেমেন্ট স্টেটমেন্ট | নতুন স্টেটমেন্ট
                  </h1>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- Main page content-->
   <div class="container mt-4">
   <hr class="mt-0 mb-4" />
   <div class="row">
      <div class="col-xl-12">
         <!-- Account details card-->
         <div class="card card-waves">
            <div class="card-header">অর্ডার আইডি</div>
            <div class="card-body">
              <form class="" action="<?php $_SERVER['PHP_SELF']; ?>" method="POST" >
                <div class="form-group mb-5">
                  <textarea required name="PEONID" class="form-control" id="exampleFormControlTextareaADDR" rows="6" ></textarea>
                </div>

            <div class="row">
               <div class="col-xl-6">
            <select required class="form-control" searchable="সার্চ করুন....." name="merchant">
          <option value="" disabled selected>একটি মার্চেন্ট সিলেক্ট করুন</option>
          <?php
            include 'config.php';
              $query_s = "SELECT * FROM merchant";
                $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");
                if (mysqli_num_rows($result_s) > 0) {
              while ($row_S = mysqli_fetch_assoc($result_s)) {
            echo "<option value='{$row_S['id']}'>{$row_S['business']}</option>";
          }  } ?>
        </select>
        <div class="pt-3">
        <label class="sr-only" for="inlineFormInputGroup">টাকা</label>
          <div class="input-group">
            <div class="input-group-prepend">
              <div class="input-group-text">&#2547;</div>
            </div>
            <input required type="text" class="form-control " id="inlineFormInputGroup" placeholder="সর্বমোট টাকা" name="totalPrice" >
          </div>
        </div>

    </div>
          <div class="col-xl-6">
          <select required class="form-control" searchable="সার্চ করুন....." name="status_invoice">
          <option ‍selected  value="1">জেনারেট</option>
          <option value="2">পরিশোধ</option>
        </select>

        <div class="pt-3">
        <label class="sr-only" for="inlineFormInputGroup">Comment</label>
          <div class="input-group">
            <div class="input-group-prepend">
              <div class="input-group-text"><i class="far fa-comment-dots"></i></div>
            </div>
            <input type="text" class="form-control " id="inlineFormInputGroup" placeholder="Comment" name="comment" >
          </div>
        </div>

        </div>
      </div>
      <a href="invoice.php" class="btn btn-dark" type="button"><i class="fas fa-reply"></i>&nbsp;&nbsp;ইনভয়েস-এ ফিরব</a>
      <input class="btn btn-primary m-3"  type="submit" name="submit" value="সেভ">
      </form>
    </div>
  </div>


   </div>
</main>
<?php }
else {
  header("location: index.php");
}

 ?>
<?php include 'footer.php';?>
