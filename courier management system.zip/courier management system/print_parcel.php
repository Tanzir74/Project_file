<?php
   session_start();
   if (!isset($_SESSION['username'])) {
     header("location: index.php");
   }
    ?>
<script type="text/javascript">
        window.print();
</script>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
            <meta http-equiv="x-ua-compatible" content="ie=edge">
            <title>Print | SPEEDY ALADDIN</title>
            <link rel="icon" type="image/x-icon" href="assets/img/favicon.png" />
                    <!--<link rel="icon" type="image/x-icon" href="assets/img/favicon.png" />-->
            <link rel="preconnect" href="https://fonts.gstatic.com">
            <link href="https://fonts.googleapis.com/css2?family=Baloo+Da+2:wght@400;500;600;700;800&family=Hind+Siliguri:wght@300;400;500;600;700&family=Mina:wght@400;700&display=swap" rel="stylesheet">
            <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">

            <link rel="stylesheet" href="css2/nstyles.css">
            <link rel="stylesheet" href="css2/bootstrap.min.css">
            <link rel="stylesheet" href="css2/mdb.min.css">
            <link rel="stylesheet" href="css2/style.css">
            <link rel="stylesheet" href="css2/responsive.css">
            <link rel="stylesheet" href="css2/datatables.min.css">
            <link rel="stylesheet" href="css2/datatables-select.min.css">
    </head>
    <body>
<link rel="stylesheet" href="css\print_parcel.css">


<div class="book">
  <div class="page">
    <div class="subpage">


            <?php ob_start(); ?>


            <?php
            $parcel_id =$_GET['id'];


            include 'config.php';
             if ($_SESSION['role']== '5') {
            $querye = "SELECT * FROM parcel
            LEFT JOIN services ON parcel.c_service = services.id
            LEFT JOIN area ON parcel.c_area = area.id
            LEFT JOIN merchant ON parcel.c_m_business = merchant.id
            WHERE parcel.parcel_id = {$parcel_id}";
          }elseif ($_SESSION['role']== '1' or $_SESSION['role']== '0') {
            $querye = "SELECT * FROM parcel
            LEFT JOIN services ON parcel.c_service = services.id
            LEFT JOIN area ON parcel.c_area = area.id
            LEFT JOIN merchant ON parcel.c_m_business = merchant.id
            WHERE parcel.parcel_id = {$parcel_id} and parcel.c_m_business = {$_SESSION['id']}";
            }

            $resulte = mysqli_query($connection,$querye) or header("location: index.php");
            $counte = mysqli_num_rows($resulte);

            if ($counte>0) {

            while ($rowe = mysqli_fetch_assoc($resulte)) {


             ?>


            <!--  -->
            <div class="text-center">
<!--<img src="assets/img/peon.png" alt="Peon" width="700" height="auto">-->
<h1 class="new5 bolt">SPEEDY ALADDIN</h1>
<span>&#9741; www.speedyaladdin.com</span>&nbsp;&nbsp; <span>&#9743; 02-84118072</span>&nbsp;&nbsp; <span>&#9993; speedyaladdin@gmail.com</span>

<hr class="new5">

<h1>Sender</h1>
<h1 class="bolt"><?php echo $rowe['business']; ?></h1>
<h1><?php echo $rowe['number']; ?></h1>
<hr class="new5">
<h1 >Recipient</h1>
<h1 class="bolt"> Name: <?php echo $rowe['c_name']; ?></h1>
<h1 class="bolt"> Mobile: <?php echo $rowe['c_number']; ?></h1>
<h1>Address: <?php echo $rowe['c_address']; ?></h1>
<h1 class="bolt">Area: <?php echo $rowe['area_name']; ?></h1>
<h1 class="bolt">Collection:  <?php echo $rowe['c_price']; ?> BDT</h1>

<hr><hr><hr>
<?php
if ($rowe['trId']=="") {
  echo "<h1 class='bolt'>SPEEDY ALADDIN ID: SPEEDY786592". $rowe['parcel_id']."</h1>";
}else {
  echo "<h1 class='bolt'>SPEEDY ALADDIN ID ". $rowe['trId']."</h1>";
}
 ?>
<h1>Merchant ID: <?php echo $rowe['c_Inv']; ?></h1>

            <?php }

            }else {
            echo "You have no such parcel!";
            }
            ?>
  </div>
  </div>
  </div>
</div>
<script src="js2/jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="js2/popper.min.js"></script>
<script type="text/javascript" src="js2/bootstrap.js"></script>
<script type="text/javascript" src="js2/mdb.min.js"></script>
<script src="js2/jquery.slimscroll.js"></script>
<script src="js2/sticky-kit.min.js"></script>
<script src="js2/custom.min-2.js"></script>
<script src="js2/datatables.min.js"></script>
<script src="js2/datatables-select.min.js"></script>
<script src="js2/custom.js"></script>
<script src="js2/axios.min.js"></script>
<script src="js\ionicons.js"></script>
<script src="js2/nmain.js"></script>
</body>
</html>
