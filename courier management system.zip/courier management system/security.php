<?php include 'menu.php';?>
                <main>
                    <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                        <div class="container-fluid">
                            <div class="page-header-content">
                                <div class="row align-items-center justify-content-between pt-3">
                                    <div class="col-auto mb-3">
                                        <h1 class="page-header-title">
                                            <div class="page-header-icon"><i data-feather="user"></i></div>
                                            অ্যাকাউন্ট সেটিংস | সিকিউরিটি
                                        </h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                    <!-- Main page content-->
                    <div class="container mt-4">
                        <!-- Account page navigation-->
                        <nav class="nav nav-borders">
                          <a class="nav-link ml-0" href="profile.php?id=<?php echo $_SESSION['id']; ?>">প্রফাইল</a>
                          <a class="nav-link" href="payment.php">পেমেন্ট</a>
                          <a class="nav-link active" href="security.php">সিকিউরিটি</a>
                          <a class="nav-link" href="#">নটিফিকেশন  <div class='badge badge-info badge-pill'>আসছে</div></a>
                        </nav>
                        <hr class="mt-0 mb-4" />
                        <div class="row">
                            <div class="col-lg-8">
      <!-- Change password card-->
      <?php
         if (isset($_POST['submit'])) {
         include 'config.php';
         $newPassword = mysqli_real_escape_string($connection,$_POST['newPassword']);
         $id = $_SESSION['id'];

         $query1 = "UPDATE merchant SET
           password ='$newPassword'
           WHERE merchant.id = $id ";



         $result1 = mysqli_query($connection,$query1) or die("কিউরি ফেইল হয়েছে।");
         if($result1){
         echo "
         <div class='alert alert-primary alert-icon' role='alert'>
            <button class='close' type='button' data-dismiss='alert' aria-label='Close'>
            <span aria-hidden='true'>×</span>
            </button>
            <div class='alert-icon-aside'>
               <i class='fas fa-lock'></i>
            </div>
            <div class='alert-icon-content'>
               <h6 class='alert-heading'>পাসওয়ার্ড চেন্স</h6>
               আপনার নতুন পাসওয়ার্ডটি চেন্জ হয়েছে।
            </div>
         </div> ";
         }




         }?>

         <!-- Change password card-->
                                <div class="card mb-4">
                                    <div class="card-header">পাসওয়ার্ড পরিবর্তন</div>
                                    <div class="card-body">
                                        <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">

                                      <div class="form-group">
                                                <label class="small mb-1" for="newPassword">নতুন পাসওয়ার্ড</label>
                                                <input class="form-control" id="newPassword" name="newPassword" type="password" placeholder="নতুন পাসওয়ার্ড লিখুন" />
                                            </div>

                                          <input class=" btn btn-primary" type="submit" name="submit" value="সেভ" required>
                                        </form>








                                    </div>
                                </div>

                            </div>
                            <div class="col-lg-4">

                                <!-- Delete account card-->
                                <div class="card mb-4">
                                    <div class="card-header">অ্যাকাউন্ট ডিলিট <div class='badge badge-info badge-pill'>আসছে</div></div>
                                    <div class="card-body">
                                        <p>আপনার অ্যাকাউন্টটি ডিলিট হলে এটি একেবারেই মুছে যাবে এবং চাইলেও আগের অবস্থায় ফিরতে পারবেন না । আপ যদি নিশ্চিত থাকেন এটি আপনি ডিলিটৈ করতে চান তাহলে নিচের বাটনটি ক্লিক করুন ।</p>
                                        <a class="btn btn-danger-soft text-danger" type="button">বুঝতে পেরেছি ! এটি ডিলিট হোক !</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
    <?php include 'footer.php';?>
