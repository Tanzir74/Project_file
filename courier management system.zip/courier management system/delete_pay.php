<?php ob_start(); ?>
<?php
$payAccount_id = $_GET['id'];

include 'config.php';
$query = "DELETE FROM `payaccount` WHERE payAccount_id = {$payAccount_id}";
$result = mysqli_query($connection,$query) or die("Query Faield.");
if ($result) {
  header('location: peoney.php?id='.$_SESSION["id"]);
  bo_enf_fluch();
}else{
echo   "<div class='alert alert-primary' role='alert'>
    Delete Fail!
</div>";
}

 ?>
