<?php ob_start();
$title = "Add payment method";
 include 'menu.php';
 ?>

<?php
 include 'config.php';
 if (isset($_POST["pay"])) {
    $payAccount_name = "";
    $payAccount_number = "";
    $payAccount_type = "";
    $payAccount_typeof = "";
    $payAccount_branch = "";
    $payAccount_owner = "";
    $payAccount_merchant = "";
    $payAccount_name = $_POST["payAccount_name"];
    $payAccount_number = $_POST["payAccount_number"];
    $payAccount_type = $_POST["payAccount_type"];
    $payAccount_typeof = $_POST["payAccount_typeof"];
    $payAccount_branch = $_POST["payAccount_branch"];
    $payAccount_owner = $_POST["payAccount_owner"];
    $payAccount_merchant = $_SESSION["id"];
    if ($_SESSION['role'] =='1') {
       $payAccount_merchant = $_SESSION['id'];
    }else if ($_SESSION['role'] =='5') {
    $payAccount_merchant = $_POST["merchant"];
    }

    $query = "INSERT INTO payaccount (payAccount_name,	payAccount_number,	payAccount_type,	payAccount_typeof,	payAccount_branch,	payAccount_owner,	payAccount_merchant)
    VALUES ('$payAccount_name',	'$payAccount_number',	'$payAccount_type',	'$payAccount_typeof',	'$payAccount_branch',	'$payAccount_owner',	'$payAccount_merchant')";
    $result = mysqli_query($connection,$query) or die("Query Faield".mysqli_error($connection));
    if ($result) {
      header('location: peoney.php?id='.$payAccount_merchant);
      bo_enf_fluch();
    }

} ?>
<main>
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
      <div class="container-fluid">
         <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
               <div class="col-auto mb-3">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i class="fas fa-credit-card"></i></div>
                     Add payment method
                  </h1>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- Main page content-->
   <div class="container mt-4">
   <div class="row">
      <div class="col-xl-6">
         <!-- Account details card-->
         <div class="card card-waves">
            <div class="card-header">Banking information</div>
            <div class="card-body">
              <form class="" action="" method="post">
                <?php if ($_SESSION['role'] =='5') { ?>
                <select required class="form-control mb-3" searchable="Search ....." name="merchant">
                   <option value="" disabled selected>Select a merchant</option>
                   <?php
                      include 'config.php';
                        $query_s = "SELECT * FROM merchant";
                          $result_s = mysqli_query($connection,$query_s)or die("ERROR");
                          if (mysqli_num_rows($result_s) > 0) {
                        while ($row_S = mysqli_fetch_assoc($result_s)) {
                      echo "<option value='{$row_S['id']}'>{$row_S['business']}</option>";
                      }  } ?>
                </select>
                <?php } ?>

                <label >Select a method</label>
                <select required name="payAccount_type" class="form-control" id="selectBox" onchange="changeFunc();">
                <option selected disabled>Select One</option>
                <option value="1">Bank</option>
                <option value='2'>bKash</option>
                <option value='3'>Nagad</option>
                <option value='4'>Rocket</option>
                <!-- <option value='5'>EBL Card</option> -->
                </select>

                <!-- <label class="font-italic text-danger text-xs mt-2" style="display: none" id="cl01">আমরা এখনও পর্যন্ত কার্ডের ক্ষেত্রে শুধুমাত্র ইস্টার্ন ব্যাংক লিঃ এর কার্ড সার্পোড করে। অনুগ্রহগপূর্বক অন্য ব্যাংকের কার্ড ইনফরমেশন দিবেন না। </label> -->



                <label class="mt-3" for="exampleFormControlTextareaADDR"   style="display: none" id="bl1">Bank name</label>
                <input type="text" class="form-control mt-1" name="payAccount_name" placeholder="Bank Name" style="display: none" id="b1">

                <label class="mt-3" for="exampleFormControlTextareaADDR" style="display: none" id="bl2">Branch name or routing number</label>
                <input type="text" class="form-control mt-1" name="payAccount_branch" placeholder="Branch Name" style="display: none" id="b2">

                <label class="mt-3" style="display: none" id="dl">Account number</label>
                <select class="form-control mt-1" name="payAccount_typeof" style="display: none" id="d">
                  <option value="1">Personal</option>
                  <option value="2">Merchant</option>
                </select>

                <label class=" mt-3" for="exampleFormControlTextareaADDR" style="display: none" id="cl1">Cardholder name</label>
                <label class=" mt-3" for="exampleFormControlTextareaADDR" style="display: none" id="bl3">Account holder name</label>
                <input type="text" class="form-control mt-1" name="payAccount_owner" placeholder="Name" style="display: none" id="b3">

                <label class=" mt-3" for="exampleFormControlTextareaADDR"  style="display: none" id="cl2">EBL card number</label>
                <label class=" mt-3" for="exampleFormControlTextareaADDR"  style="display: none" id="bl4">Account number</label>
                <input required type="number" class="form-control mt-1" name="payAccount_number" placeholder="Number" style="display: none" id="b4">

                <input type="submit" class="btn btn-primary btn-lg btn-block mt-3" name="pay" value="SAVE">
            </form>
            </div>
          </div>
        </div>




      </div>
   </div>
</main>
<script type="text/javascript">
    function changeFunc() {
        var selectBox = document.getElementById("selectBox");
        var selectedValue = selectBox.options[selectBox.selectedIndex].value;
        if (selectedValue == "1") {
          $('#cl01').hide();
          $('#bl1').show();
          $('#b1').show();
          $('#bl2').show();
          $('#b2').show();
          $('#dl').hide();
          $('#d').hide();
          $('#cl1').hide();
          $('#bl3').show();
          $('#b3').show();
          $('#cl2').hide();
          $('#bl4').show();
          $('#b4').show();
        }else if (selectedValue == "2"){
          $('#cl01').hide();
          $('#bl1').hide();
          $('#b1').hide();
          $('#bl2').hide();
          $('#b2').hide();
          $('#dl').show();
          $('#d').show();
          $('#cl1').hide();
          $('#bl3').hide();
          $('#b3').hide();
          $('#cl2').hide();
          $('#bl4').show();
          $('#b4').show();
        }else if (selectedValue == "3"){
          $('#cl01').hide();
          $('#bl1').hide();
          $('#b1').hide();
          $('#bl2').hide();
          $('#b2').hide();
          $('#dl').show();
          $('#d').show();
          $('#cl1').hide();
          $('#bl3').hide();
          $('#b3').hide();
          $('#cl2').hide();
          $('#bl4').show();
          $('#b4').show();
        }else if (selectedValue == "4"){
          $('#cl01').hide();
          $('#bl1').hide();
          $('#b1').hide();
          $('#bl2').hide();
          $('#b2').hide();
          $('#dl').show();
          $('#d').show();
          $('#cl1').hide();
          $('#bl3').hide();
          $('#b3').hide();
          $('#cl2').hide();
          $('#bl4').show();
          $('#b4').show();
        }else if (selectedValue == "5"){
          $('#cl01').show();
          $('#bl1').hide();
          $('#b1').hide();
          $('#bl2').show();
          $('#b2').show();
          $('#dl').hide();
          $('#d').hide();
          $('#cl1').show();
          $('#bl3').hide();
          $('#b3').show();
          $('#cl2').show();
          $('#bl4').hide();
          $('#b4').show();
        } else {

        }
    }
</script>
<?php include 'footer.php';?>
