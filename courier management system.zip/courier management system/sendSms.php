<?php ob_start();



$title = "সেন্ড এস এম এস";
 include 'menu.php';
 include 'tokensms.php';
if ($_SESSION['role']== '5') {
if (isset($_POST['send'])) {
  include 'config.php';
  $to = mysqli_real_escape_string($connection,$_POST['number']);
  $token = $tokens;
  $message = mysqli_real_escape_string($connection,$_POST['sms']);


  $url = "http://api.greenweb.com.bd/api.php?json";


  $data= array(
  'to'=>"$to",
  'message'=>"$message",
  'token'=>"$token"
  ); // Add parameters in key value
  $ch = curl_init(); // Initialize cURL
  curl_setopt($ch, CURLOPT_URL,$url);
  curl_setopt($ch, CURLOPT_ENCODING, '');
  curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
  $smsresult = curl_exec($ch);
  if ($smsresult) {
    header('location: sendSms.php');
    bo_enf_fluch();
  }
}
// টোটাল পাঠনো SMS
        $url = 'http://api.greenweb.com.bd/g_api.php?token='.$tokens.'&tokensms';

        try
        {
            $result = file_get_contents( $url );
        }
        catch (Exception $e)
        {
            die('ERROR: ' . $e->getMessage());
        }

      // echo   $result;
// SMS ব্যালেন্স
        $url = 'http://api.greenweb.com.bd/g_api.php?token='.$tokens.'&balance';

        try
        {
            $balance = file_get_contents( $url );
        }
        catch (Exception $e)
        {
            die('ERROR: ' . $e->getMessage());
        }

      // echo  $balance;

 ?>
<main>
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
      <div class="container-fluid">
         <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
               <div class="col-auto mb-3">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i class="fas fa-sms"></i></div>
                     এস এম এস | প্যানেল
                  </h1>

               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- Main page content-->
   <div class="container mt-4">
   <div class="row">
      <div class="col-xl-6">
         <!-- Account details card-->
         <div class="card card-waves">
            <div class="card-header">ক্রেতার তথ্য  </div>
            <div class="card-body">
              <form class="" action="" method="post">
              <label class="small mb-1" for="inputFirstNamenumber">মোবাইল নম্বর</label>
              <input required type="text" minlength="11" name="number" class="form-control"  placeholder="017...." />

              <div class="form-group mt-3">
                <label for="exampleFormControlTextareaADDR">এস এম এস</label>
                <textarea required name="sms" class="form-control" id="exampleFormControlTextareaADDR" rows="3"></textarea>
              </div>

              <input class="btn btn-primary" type="submit" name="send" value="সেন্ড">
            </form>
            </div>
          </div>
        </div>
        <div class="col-xl-6">
          <div class="card card-waves">
            <div class="card-header"> এস এম এস সম্পর্কিত তথ্য</div>
            <div class="card-body">
              সর্বমোট পাঠানো এসএমএসঃ  <?php echo " ".$result; ?>
              অ্যাভেলেবেল এসএমএস  ব্যালেন্সঃ  ৳<?php echo " ".$balance; ?>
          </div>
          </div>
        </div>




      </div>
   </div>

</main>
<?php } ?>
<?php include 'footer.php';?>
