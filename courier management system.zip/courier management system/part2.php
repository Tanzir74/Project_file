<?php
$result = mysqli_query($connection,$query) or die("Query Faield.");
$count = mysqli_num_rows($result);
?>
<thead>


<tr>
  <?php if ($_SESSION['role'] =='5') {?>
   <th><i class="fas fa-clipboard-check"></i></th>
 <?php } ?>
   <th>আইডি</th>
   <th>প্রেরক</th>
   <th>প্রাপক</th>
   <th>নোট</th>
   <th>স্টাটাস</th>
   <th>অ্যাকশান</th>
</tr>
</thead>
<tfoot>
<tr>
  <?php if ($_SESSION['role'] =='5') {?>
   <th><i class="fas fa-clipboard-check"></i></th>
 <?php } ?>
   <th>আইডি</th>
   <th>প্রেরক</th>
   <th>প্রাপক</th>
   <th>নোট</th>
   <th>স্টাটাস</th>
   <th>অ্যাকশান</th>
</tr>
</tfoot>
<tbody>
<?php
   if ($count>0) {
   while ($row = mysqli_fetch_assoc($result)) {
     ?>
<tr>
  <?php if ($_SESSION['role'] =='5') {?>
   <td class="th-sm">
     <input  type="hidden" name="businesss" value="<?php echo $row['business']; ?>">
     <input type="hidden" name="c_prices" value="<?php echo $row['c_price']; ?>">
     <input type="hidden" name="c_names" value="<?php echo $row['c_name']; ?>">
     <label class="checkbox path">
            <input type="checkbox" name="check_data[]"  value="<?php echo $row['parcel_id']; ?>">
            <svg viewBox="0 0 21 21">
                <path d="M5,10.75 L8.5,14.25 L19.4,2.3 C18.8333333,1.43333333 18.0333333,1 17,1 L4,1 C2.35,1 1,2.35 1,4 L1,17 C1,18.65 2.35,20 4,20 L17,20 C18.65,20 20,18.65 20,17 L20,7.99769186"></path>
            </svg>
        </label>
   </td>
 <?php } ?>
   <td class="th-sm">
<?php
if ($row['trId']=="") {
  echo "<span class='text-green'>PEON786592". $row['parcel_id']."</span><br>";
}else {
  echo "<span class='text-green'>". $row['trId']."</span><br>";
}
 ?>



      M.Inv:<?php echo $row['c_Inv']; ?><br>
      <?php echo $row['Ptime']; ?> <br>
      <?php echo $row['Pdate']; ?>

   </td>
   <td class="th-sm cb">
     <span class="font-weight-bolder"><?php echo $row['business']; ?></span><br>
      <?php echo $row['number']; ?>  <br>
      <?php echo $row['address']; ?>
      <div class="row ">
         <div class="col-md-12">
            <div class="row">
               <div class="col-md-6">
                  <span class="text-green font-weight-900"> ওজন: <?php echo $row['weight']; ?> কেজি</span>
               </div>
               <div class="col-md-6">
                  <span class="text-green font-weight-900">
                     চার্জ:  <?php

                   echo $row['c_charge'];

                      ?> &#2547;

                   </span>
               </div>
            </div>
         </div>
      </div>
      <div class="row ">
         <div class="col-md-12">
            <div class="row">
               <div class="col-md-6">
                  <span class="text-green font-weight-900"> COD: <?php echo $row['c_price']; ?>&#2547;</span>
               </div>
               <div class="col-md-6">
                  <span class="text-green font-weight-900">
                    Payable:  <?php echo $payble =  $row['c_price'] - $row['c_charge']; ?> &#2547;

                   </span>
               </div>
            </div>
         </div>
      </div>
   </td>
   <td class="th-sm cb">
      <?php echo $row['c_name'];?> <br>
      <?php echo $row['c_number']; ?>,  <?php echo $row['c_b_number']; ?>  <br>
      <?php echo $row['c_address']; ?>

      <div class="row ">
         <div class="col-md-12">
            <div class="row">
               <div class="col-md-12">
                  <span class="text-green"> এরিয়া: <?php echo $row['area_name']; ?></span>
               </div>
            </div>
         </div>
      </div>

   </td>
   <td class="th-sm cbNote">
   <?php echo $row['note'];?>
   </td>
   <td>
      <?php
         if ($row['c_action']==1) {
             echo "<div class='badge badge-danger badge-pill'><i class='fas fa-spinner'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
         }
         else if($row['c_action']==2){
             echo "<div class='badge badge-primary badge-pill'><i class='fas fa-biking'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
         }
         else if($row['c_action']==3){
             echo "<div class='badge badge-primary badge-pill'><i class='fas fa-warehouse'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
         }
         else if($row['c_action']==4){
             echo "<div class='badge badge-primary badge-pill'><i class='fas fa-shipping-fast'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
         }
         else if($row['c_action']==5){
             echo "<div class='badge badge-green badge-pill'><i class='fa fa-check-circle'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
         }
         else if($row['c_action']==6){
             echo "<div class='badge badge-dark badge-pill'><i class='fas fa-history'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
         }
         else if($row['c_action']==7){
             echo "<div class='badge badge-primary badge-pill'><i class='fas fa-exchange-alt'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
         }
         else if($row['c_action']==8){
             echo "<div class='badge badge-dark badge-pill'><i class='fas fa-file-import'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
         }
         else {
           echo "<div class='badge badge-warning badge-pill'><i class='fas fa-window-close'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
         }
         ?>
      <br>
      <?php
         if ($row['p_Pay']==1) {
             echo "<div class='badge badge-blue badge-pill'><i class='far fa-hourglass'></i>&nbsp;&nbsp;".$row['payName']."</div><br>";
         }
         else if($row['p_Pay']==2){
             echo "<div class='badge badge-green badge-pill'><i class='fas fa-hourglass'></i>&nbsp;&nbsp;".$row['payName']."</div> <br>";
         }
         else {

         }
         ?>
      <?php
         if ($row['c_service']==1) {
             echo "<div class='badge badge-orange badge-pill'>".$row['sName']."</div>";
         }
         else if($row['c_service']==2){
             echo "<div class='badge badge-primary badge-pill'>".$row['sName']."</div>";
         }
         else {
           echo "<div class='badge badge-warning badge-pill'>".$row['sName']."</div>";
         }
         ?>

         <?php if ($_SESSION['role'] =='5') {?>
         <br>
         <div class="bg-light rounded mt-2"><?php echo $row['hero_name'];?></div>
       <?php } ?>
   </td>
   <td>
        <?php if ($_SESSION['role'] =='5') {?>
<button data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="dropdownFadeInUp<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm">
<i data-feather="more-vertical"></i>
</button>
<?php } ?>
<div class="dropdown-menu animated--fade-in-up" aria-labelledby="dropdownFadeInUp<?php echo $row['parcel_id'];?>">
<!-- Delete Dropdown Button -->
<a data-toggle="modal" data-target="#exampleModalSm<?php echo $row['parcel_id']; ?>" class="dropdown-item text-danger" >ডিলিট</a>

<!-- Delete Dropdown Button -->
      </div>
      <!-- Small modal -->
      <div class="modal fade" id="exampleModalSm<?php echo $row['parcel_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
         <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
               <div class="modal-header">
                  <h5 class="modal-title">গুরুত্বপূর্ণ ব্যাপার</h5>
                  <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
               </div>
               <div class="modal-body">
                  <p>আপনি কি <?php
                  if ($row['trId']=="") {
                    echo "PEON786592". $row['parcel_id'];
                  }else {
                    echo  $row['trId'];
                  }
                   ?> পার্সেল ডিলিট করতে চাচ্ছেন?</p>
               </div>
               <div class="modal-footer">
                  <button class="btn btn-primary" type="button" data-dismiss="modal">না! থাক</button>
<a class="btn btn-danger" type="button" href="delete_parcel.php?MasRiaKib=<?php echo $row['parcel_id']; ?>">ডিলিট</a>
               </div>
            </div>
         </div>
      </div>

      <a target="_blank" href="viewParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="fas fa-eye"></i></a>
         <?php if ($_SESSION['role'] =='5') {?>
      <a target="_blank" href="updateParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="far fa-edit"></i></a>
    <?php } ?>
      <a class="btn btn-outline-primary btn-icon btn-sm" target="_blank" href="print_parcel.php?id=<?php echo $row['parcel_id']; ?>"><i class="fas fa-print"></i></a>
   </td>
</tr>
<?php } ?>
</tbody>
<?php } ?>
</table>

</form>

</div>
</div>
</div>
</div>
</main>
