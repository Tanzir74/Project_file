<main>
   <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
      <div class="container">
         <div class="page-header-content pt-4">
            <div class="row align-items-center justify-content-between">
               <div class="col-auto mt-4">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i class="fas fa-box-open"></i></div>
                     পার্সেল
                  </h1>
                  <div class="page-header-subtitle">শুধু অর্ডার নিন, বাকিচিন্তা আমাদের</div>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- Main page content-->
   <div class="container mt-n10">
      <div class="card mb-4">
         <div class="card-header">সকল পার্সেল &nbsp;
            <a href="addParcel.php" class="btn btn-primary btn-xs btn-icon ">
            <i class="fas fa-plus-circle"></i>
            </a>
         </div>
         <div class="card-body">
            <div class="datatable">
               <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
