<?php ob_start(); ?>
<?php
$parcel_id = $_GET['MasRiaKib'];

include 'config.php';
$query = "DELETE FROM `parcel` WHERE parcel_id = {$parcel_id}";
$result = mysqli_query($connection,$query) or die("Query Faield.");
if ($result) {
  header("location: parcel.php");
  bo_enf_fluch();
  
}else{
echo   "<div class='alert alert-primary' role='alert'>
    Delete Fail!
</div>";
}

 ?>
