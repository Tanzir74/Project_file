<?php ob_start(); ?>
<?php
                                    if (isset($_POST['submit'])) {
                                    include 'config.php';
                                    $role = mysqli_real_escape_string($connection,$_POST['role']);
                                    $id = mysqli_real_escape_string($connection,$_POST['id']);

                                      $query1 = "UPDATE merchant SET
                                      role = '$role'
                                      WHERE id = $id";

                                      $result1 = mysqli_query($connection,$query1) or die("ডাটা সেন্টার কানেক্ট হয়নি !".mysqli_error());

                      if ($result1) {


                      if ($_POST["role"] == 1) {

                        $to = $_POST["number"];
                        $token = "69a9e1162ef97e9cc0f314fe26475048";
                        $message = "আসসালামু আলাইকুম ! প্রিয় " .$_POST["name"]." ! বন্ড কুরিয়ারে স্বাগতম ! আপনার স্বজন অ্যাকাউন্ট অ্যাক্টিভ হয়েছে । লগইন করে শুরু করুন পার্সেল বুকিংঃ https://demo.finalebond.com/courier/
                      -BOND Courier";


                        $url = "http://api.greenweb.com.bd/api.php?json";


                        $data= array(
                        'to'=>"$to",
                        'message'=>"$message",
                        'token'=>"$token"
                        ); // Add parameters in key value
                        $ch = curl_init(); // Initialize cURL
                        curl_setopt($ch, CURLOPT_URL,$url);
                        curl_setopt($ch, CURLOPT_ENCODING, '');
                        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
                        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                        $smsresult = curl_exec($ch);
                        if ($smsresult=true) {


                          header('location: sajon.php');
                          bo_enf_fluch();
                            }

                      }else{
                        header('location: sajon.php');
                        bo_enf_fluch();
                      }
                    }


                  }
                                        ?>
