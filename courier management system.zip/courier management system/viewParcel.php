<?php ob_start(); ?>
<?php
$title = "Parcel";
 include 'menu.php'; ?>
<?php $parcel_id =$_GET['id'];
include 'config.php';
 if ($_SESSION['role']== '5') {
   $querye = "SELECT * FROM parcel
   LEFT JOIN services ON parcel.c_service = services.id
   LEFT JOIN area ON parcel.c_area = area.id
   LEFT JOIN merchant ON parcel.c_m_business = merchant.id
   LEFT JOIN action ON parcel.c_action = action.action_id
   LEFT JOIN hero ON parcel.c_hero = hero.hero_id
   WHERE parcel.parcel_id = {$parcel_id}";
 }elseif ($_SESSION['role']== '1') {
   $querye = "SELECT * FROM parcel
   LEFT JOIN services ON parcel.c_service = services.id
   LEFT JOIN area ON parcel.c_area = area.id
   LEFT JOIN merchant ON parcel.c_m_business = merchant.id
   LEFT JOIN action ON parcel.c_action = action.action_id
   LEFT JOIN hero ON parcel.c_hero = hero.hero_id
   WHERE parcel.parcel_id = {$parcel_id} and parcel.c_m_business = {$_SESSION['id']}";
 }



$resulte = mysqli_query($connection,$querye) or header("location: index.php");

$counte = mysqli_num_rows($resulte);

if ($counte>0) {

while ($rowe = mysqli_fetch_assoc($resulte)) {


 ?>

<main>
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
      <div class="container-fluid">
         <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
               <div class="col-auto mb-3">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i data-feather="user"></i></div>
                     Parcel |       <?php
                           if ($rowe['trId']=="") {
                             echo "PEON786592". $rowe['parcel_id'];
                           }else {
                             echo  $rowe['trId'];
                           }
                            ?>
<!-- অ্যাক্টিভ স্টাটাস -->
<?php
if ($rowe['c_action']==1) {
    echo "The parcel is still pending.";
}
else if($rowe['c_action']==2){
    echo $rowe['hero_name']. " has been sent to pick up."."If necessary- ".$rowe['hero_mobile'];
}
else if($rowe['c_action']==3){
    echo "We have received the parcel. Processing for fast delivery.";
}
else if($rowe['c_action']==4){
    echo $rowe['hero_name']."rider has been sent for parcel delivery. If necessary- ".$rowe['hero_mobile'];
}
else if($rowe['c_action']==5){
    echo "Alhamdulillah! Parcel delivery is complete. 😊";
}
else if($rowe['c_action']==6){
    echo "Delivery has been rescheduled for the next day.";
}
else if($rowe['c_action']==7){
    echo " No. The parcel will be returned to the merchant quickly.";
}
else if($rowe['c_action']==8){
    echo " No. The parcel has been sent to ".$rowe['hero_name']." Rider for return.  If necessary-  ".$rowe['hero_mobile'];
}
else if($rowe['c_action']==9){
    echo " No Parcel.  has been returned to the merchant.";
}
else {
  echo "Parcel request has been canceled for any reason.";
}

 ?>

<!-- অ্যাক্টিভ স্টাটাস -->




                  </h1>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- Main page content-->

   <div class="container mt-4">
     <div class="card card-header-actions mx-auto">
    <div class="card-header">
      <?php
      if ($rowe['trId']=="") {
        echo "PEON786592". $rowe['parcel_id'];
      }else {
        echo  $rowe['trId'];
      }
       ?>
<h1>
<?php
if ($rowe['c_action']==1) {
    echo "<div class='badge badge-danger badge-pill'>".$rowe['action_name']."</div>";
}
else if($rowe['c_action']==2){
    echo "<div class='badge badge-primary badge-pill'>".$rowe['action_name']."</div>";
}
else if($rowe['c_action']==3){
    echo "<div class='badge badge-primary badge-pill'>".$rowe['action_name']."</div>";
}
else if($rowe['c_action']==4){
    echo "<div class='badge badge-primary badge-pill'>".$rowe['action_name']."</div>";
}
else if($rowe['c_action']==5){
    echo "<div class='badge badge-green badge-pill'>".$rowe['action_name']."</div>";
}
else if($rowe['c_action']==6){
    echo "<div class='badge badge-dark badge-pill'>".$rowe['action_name']."</div>";
}
else if($rowe['c_action']==7){
    echo "<div class='badge badge-primary badge-pill'>".$rowe['action_name']."</div>";
}
else if($rowe['c_action']==8){
    echo "<div class='badge badge-dark badge-pill'>".$rowe['action_name']."</div>";
}
else {
  echo "<div class='badge badge-warning badge-pill'>".$rowe['action_name']."</div>";
}


 ?>


</h1>
        <div>


          <a title="Back" href="parcel.php" class="btn btn-primary btn-icon mr-2">
            <i class="fas fa-angle-double-left"></i></a>
            <?php
            if (!$rowe['file'] == "") {?>
              <a title="Download" href="<?php echo $rowe['file']; ?>" class="btn btn-green btn-icon mr-2">
                <i class="fas fa-arrow-alt-circle-down"></i></a>
              <?php  } ?>


             <?php if ($_SESSION['role'] =='5') {?>
               <?php if ($rowe['c_action']=='5') {?>
                 <a title="It cannot be edited"  class="btn btn-primary btn-icon mr-2">
                   <i class="far fa-edit"></i></a>
               <?php }else if($rowe['c_action']=='9'){ ?>
                 <a title="It cannot be edited"  class="btn btn-primary btn-icon mr-2">
                   <i class="far fa-edit"></i></a>
               <?php  } else { ?>
                 <a title="Parcel Edit" href="updateParcel.php?id=<?php echo $rowe['parcel_id']; ?>" class="btn btn-primary btn-icon mr-2">
                   <i class="far fa-edit"></i></a>
               <?php } ?>

          <?php } ?>

            <a title="Print" class="btn btn-warning btn-icon mr-2" onclick="window.open('print_parcel.php?id=<?php echo $rowe['parcel_id']; ?>','POPUP WINDOW TITLE HERE','').print()">
              <i class="fas fa-print"></i></a>



                 <?php if ($_SESSION['role'] =='5') {?>
                   <?php if ($rowe['c_action']=='5') {?>
                     <a title="Update"  class="btn btn-dark btn-icon"><i class="fas fa-cogs"></i>
                     </a>
                   <?php }else if($rowe['c_action']=='9'){ ?>
                     <a title="Update"  class="btn btn-dark btn-icon"><i class="fas fa-cogs"></i>
                     </a>
                   <?php  } else { ?>
                     <a title="It can no longer be updated" data-toggle="modal" data-target="#exampleModalCenter<?php echo $rowe['parcel_id']; ?>"  class="btn btn-dark btn-icon"><i class="fas fa-cogs"></i>
                     </a>
                   <?php } ?>

            <?php } ?>

            <!-- admin Modal -->
            <div class="modal fade" id="exampleModalCenter<?php echo $rowe['parcel_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalCenterTitle">      <?php
                                  if ($rowe['trId']=="") {
                                    echo "PEON786592". $rowe['parcel_id'];
                                  }else {
                                    echo  $rowe['trId'];
                                  }
                                   ?></h5>
                            <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                        </div>
                        <div class="modal-body">
                          <!-- Content  -->
                          <form action="action_up_view.php" method="post" enctype="multipart/form-data">
                            <input type="hidden" name="pid"  value="<?php echo $rowe['parcel_id']; ?>" >
                <div class="form-group">
                  <input type="hidden" name="trId" value="<?php echo $rowe['trId']; ?>">
                  <input type="hidden" name="c_number" value="<?php echo $rowe['c_number']; ?>">
                  <input type="hidden" name="business" value="<?php echo $rowe['c_m_business']; ?>">
                  <input type="hidden" name="c_price" value="<?php echo $rowe['c_price']; ?>">
                  <input type="hidden" name="c_name" value="<?php echo $rowe['c_name']; ?>">
                  <input type="hidden" name="c_charge" value="<?php echo $rowe['c_charge']; ?>">
                  <input type="hidden" name="hero_name" value="<?php echo $rowe['hero_name']; ?>">
                  <input type="hidden" name="hero_mobile" value="<?php echo $rowe['hero_mobile']; ?>">
                  <input type="hidden" name="c_service" value="<?php echo $rowe['c_service']; ?>">
                  <input type="hidden" name="c_service" value="<?php echo $rowe['c_service']; ?>">

                  <label for="exampleFormControlInput9">Because</label>
                  <input name="reason" class="form-control" id="exampleFormControlInput9" type="text" >

                  <?php if ($rowe['c_service'] == "6") {  ?>
                    <label class="mt-3" for="exampleForm235">Charge</label>
                    <input name="cherg" class="form-control" id="exampleForm235" type="text" value="<?php echo $rowe['c_charge']; ?>">
                  <?php  }else { ?>
                    <input type="hidden" name="cherg" value="<?php echo $rowe['c_charge']; ?>">
                <?php  } ?>

                    <label class="mt-3" for="example">Action</label>
                    <select required name="c_action" class="form-control" id="example">
                        <option selected disabled>Select one</option>
                        <?php
                               include 'config.php';
                               $query_s = "SELECT * FROM action";
                               $result_s = mysqli_query($connection,$query_s)or die("ERROR");

                               if (mysqli_num_rows($result_s) > 0) {
                                 while ($row_S = mysqli_fetch_assoc($result_s)) {

                                   if ($row['c_action'] == $row_S['action_id']) {
                                     $selected = "selected";
                                   }else {
                                     $selected = "";
                                   }

                                   echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
                                 }
                               }
                                ?>
                    </select>
                    <label  class="mt-3" for="exampleFormControlSelect2">Hero</label>
                    <select name="c_heros" class="form-control " id="exampleFormControlSelecth">
                        <option selected value="">Choose a hero</option>
                        <?php
                               include 'config.php';
                               $query_h = "SELECT * FROM hero";
                               $result_h = mysqli_query($connection,$query_h)or die("ERROR");

                               if (mysqli_num_rows($result_h) > 0) {
                                 while ($row_h = mysqli_fetch_assoc($result_h)) {

                                   if ($row['c_hero'] == "2") {
                                     $selected = "selected";
                                   }else {
                                     $selected = "";
                                   }

                                   echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
                                 }
                               }
                                ?>
                    </select>
                    <label for="formFileLg" class="form-label mt-3">File upload</label>
                    <input name="file" class="form-control form-control-lg" id="formFileLg" type="file" />
                    <input type="hidden" name="old_action" value="<?php echo $rowe['c_action']; ?>">
                </div>



                          <!-- Content  -->
                        </div>
                        <div class="modal-footer">
                          <button class="btn btn-dark" type="button" data-dismiss="modal">Close</button>
                          <input class=" btn btn-primary" type="submit" name="submit" value="Save" required>
                          </form>
                        </div>
                    </div>
                </div>
            </div>


            <!-- admin Modal -->
        </div>
    </div>
</div>
   <hr class="mt-0 mb-4" />
   <div class="row">
      <div class="col-xl-6">
         <!-- Account details card-->
         <div class="card card-waves">
            <div class="card-header">Sender </div>
            <div class="card-body">
              <span >Merchant Name:&nbsp;&nbsp;  </span>  <span class="font-weight-900"><?php echo $rowe['name']; ?></span><br>
              <span >Merchant Business:&nbsp;&nbsp;  </span>  <span class="font-weight-900"><?php echo $rowe['business']; ?></span><br>
                        <span>Merchant mobile number :&nbsp;&nbsp;</span>  <span class="font-weight-900"><?php echo $rowe['number']; ?></span><br>

                        <!-- <span>Merchant name:&nbsp;&nbsp;</span>  <span class="font-weight-900"><?php echo $rowe['name']; ?></span><br> -->

                        <span >Email:</span>  <span class="font-weight-900"><?php echo $rowe['email']; ?></span><br>
                        <span >Booking date:</span>  <span class="font-weight-900"><?php echo $rowe['Ptime']." ".$rowe['Pdate']; ?></span><br>



                        <span class="btn shadow-lg">Service:&nbsp;&nbsp; <span class="font-weight-900"><?php echo $rowe['sName']; ?></span></span>
                        <span class="btn shadow-lg">Total charge: &nbsp;&nbsp;<span class="font-weight-900"><?php echo $rowe['c_charge']; ?> </span>&nbsp;&nbsp;BDT</span>
            </div>
          </div>
          <!-- Account details card-->
        </div>
      <div class="col-xl-6">
         <!-- Account details card-->
         <div class="card card-waves">
            <div class="card-header">Recipient </div>
            <div class="card-body">
              <span >Merchant Reference:&nbsp;&nbsp; </span>  <span class="font-weight-900"> <?php echo $rowe['c_Inv']; ?></span> <br>
              <span >Tracking: &nbsp;&nbsp;</span>  <span class="font-weight-900">      <?php
                    if ($rowe['trId']=="") {
                      echo "PEON786592". $rowe['parcel_id'];
                    }else {
                      echo  $rowe['trId'];
                    }
                     ?></span><br>
              <span >Recipient name: &nbsp;&nbsp;  </span>  <span class="font-weight-900"><?php echo $rowe['c_name']; ?></span><br>
              <span >Mobile number: &nbsp;&nbsp;</span>  <span class="font-weight-900"><?php echo $rowe['c_number']; ?></span><br>
              <span >Address: &nbsp;&nbsp;</span>  <span class="font-weight-900"><?php echo $rowe['c_address']; ?></span><br>
              <span >Area: &nbsp;&nbsp;</span>  <span class="font-weight-900"><?php echo $rowe['area_name']; ?></span><br>
              <span >Order Note:</span>  <span class="font-weight-900"><?php echo $rowe['note']; ?></span><br>
              <span class="btn shadow-lg">Weight:&nbsp;&nbsp;  <span class="font-weight-900"><?php echo $rowe['weight']; ?></span>&nbsp;&nbsp; Kg</span>
              <span class="btn shadow-lg">Cash collection: &nbsp;&nbsp;  <span class="font-weight-900"><?php echo $rowe['c_price']; ?></span> &nbsp;&nbsp;BDT</span>

            </div>
          </div>
          <!-- Account details card-->

        </div>



      </div>
      <!-- Fade In Animation -->
      <div class="card card-angles mt-3">
          <div class="card-body">
            <div class="row">
               <div class="col-xl-4">
                 </div>
                 <div class="col-xl-8">
            <!-- Timeline -->
            <?php
            include 'config.php';
            $queryx = "SELECT * FROM tracking
            LEFT JOIN action ON tracking.action_id_traking = action.action_id
            LEFT JOIN hero ON tracking.tr_hero = hero.hero_id
            WHERE tracking.traking_parcel_id = {$parcel_id} ORDER BY tracking_id DESC ";
            $resultx = mysqli_query($connection,$queryx) or die("Query Faield.");
            $countx = mysqli_num_rows($resultx);
            if ($countx>0) {

                     ?>
            <?php
               if ($countx>0) {
               while ($rowx = mysqli_fetch_assoc($resultx)) {
                 ?>
            <!-- Fade In Animation -->
            <div class="timeline">
                <div class="timeline-item">
                    <div class="timeline-item-marker">
                        <div class="timeline-item-marker-text"><?php echo $rowx['time_tarking']; ?> <br> <?php echo $rowx['date_tarking']; ?></div>
                        <div class="timeline-item-marker-indicator"><img class="rounded-circle img-fluid" src="<?php echo $_SESSION['p_photo']; ?>" /></div>
                    </div>
                    <div class="timeline-item-content">
                      <?php
                        echo "The parcel has been ";
                        if (!$rowx['action_name'] == "") {
                          $update = $rowx['action_name'];
                        }else {
                          $update = "updated.";
                        }


                      echo $update; ?>


                       <?php if ($_SESSION['role'] =='5') {?>
                        <span class="text-muted"><br> <?php echo $rowx['user']; ?></span>
                     <?php } ?>

                      <?php
                      if (!$rowx['reason'] == "") {
                        echo "Reason:".$rowx['reason'];
                      }

                       ?>


                    </div>
                </div>

<?php }}}else {
  ?>
  <div class="timeline">
      <div class="timeline-item">
          <div class="timeline-item-marker">
              <div class="timeline-item-marker-text">N/A</div>
              <div class="timeline-item-marker-indicator"><i data-feather="check"></i></div>
          </div>
          <div class="timeline-item-content">The order is still pending.</div>
      </div>


  <?php
} ?>
            </div>

            </div>
            </div>

            <!-- Timeline -->
          </div>
      </div>
      <?php }} ?>
   </div>

</main>
<?php include 'footer.php';?>
