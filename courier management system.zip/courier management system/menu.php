<?php
   session_start();
   if (!isset($_SESSION['username'])) {
       header("location: index.php");
      }
    ?>
<!DOCTYPE html>
<!--/**
 *Bismillah Hirrahmanir Rahim
 * Bond Courier Management System
 * Version:           0.6
 * Author:            FinaleBond
 * Author URI:        http://finalebond.com/
 * Author Contect:    marzanbay@gmil.com | 01994205327
 */-->
<html lang="en">
   <head>
      <meta charset="utf-8" />
      <meta http-equiv="X-UA-Compatible" content="IE=edge" />
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <meta name="description" content="" />
      <meta name="author" content="" />
<style>
nav.sticky {
  position: -webkit-sticky;
  position: sticky;
  top: 0;
}
</style>
      <title><?php echo $title; ?></title>

      <link href="css/styles.css" rel="stylesheet" />
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
            <link href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" rel="stylesheet" crossorigin="anonymous" />
                  <script data-search-pseudo-elements defer src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/js/all.min.js" crossorigin="anonymous"></script>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet"/>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" ></script>
              <script src="https://cdnjs.cloudflare.com/ajax/libs/feather-icons/4.28.0/feather.min.js" crossorigin="anonymous"></script>
        <script>
                  $(document).ready(function()
                  {
                    $("#serchble").select2 ({

                    });
                  });
        </script>
      <link href="css/dataTables.css" rel="stylesheet" />
      <link rel="icon" type="image/x-icon" href="assets/img/favicon.png" />
      <script data-search-pseudo-elements defer src="js/all.min.js" crossorigin="anonymous"></script>
      <script src="js/feather.min.js" crossorigin="anonymous"></script>
   </head>

<!-- <div class="shadow-none" role="alert">
<h1>পিয়ন</h1>
</div> -->

   <body class="">
      <nav class="topnav navbar navbar-expand shadow justify-content-between justify-content-sm-start navbar-light bg-white sticky" id="sidenavAccordion">
         <a href="index.php"></a>        
         </a><span title="Come to the home page" href="index.php" class="mr-2 ml-1"></span>
         <!-- Sidenav   Toggle Button-->
         <button class="btn btn-icon btn-transparent-dark order-1 order-lg-0 mr-lg-2" id="sidebarToggle"><i data-feather="menu"></i></button>
         <!-- Navbar Search Input-->
         <!-- * * Note: * * Visible only on and above the md breakpoint-->
         <form class="form-inline mr-auto d-none d-md-block mr-3" action="serch.php" method="get">
            <div class="input-group input-group-joined input-group-solid">
               <input title="Search for Order ID" class="form-control mr-sm-2" type="search" name="serch" placeholder="Search: ID, name, number ..." aria-label="Search" />
               <div class="input-group-append">
                  <div class="input-group-text"><i data-feather="search"></i></div>
               </div>
            </div>
         </form>

         
         <!-- Navbar Items-->
           </div>
            <!-- Messages Dropdown-->
            <?php if ($_SESSION['role'] =='2') {?>
            <li class="nav-item dropdown no-caret d-none d-sm-block mr-3 dropdown-notifications">
               <a title="Add a new parcel" class="btn btn-icon btn-primary" href="addParcel.php" role="button"  ><i class="fas fa-plus 1.33em"></i></a>
            </li>
          <?php } ?>

<?php if ($_SESSION['role'] =='5') {?>
            <div class="dropdown  mr-3">
    <a class="btn-icon btn btn-outline-primary" id="dropdownMenuButton" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-plus 1.33em"></i></a>
      <div class="dropdown-menu">
          <a class="dropdown-item" href="sendSms.php">
              <div class="dropdown-item-icon">
                  <i class="far fa-paper-plane"></i>
              </div>
              Send SMS
          </a>
          <a class="dropdown-item" href="addSajon.php">
              <div class="dropdown-item-icon">
                  <i class="fas fa-users"></i>
              </div>
              Add new merchants
          </a>
          <a class="dropdown-item" href="addNotification.php">
              <div class="dropdown-item-icon">
                  <i class="fas fa-bell"></i>
              </div>
              Add new notifications
          </a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="addParcel.php">
              <div class="dropdown-item-icon">
                  <i class="fas fa-plus 1.33em mr-2"></i>
              </div>
              Add new parcel
          </a>
      </div>

</div>
<?php } ?>
            <!-- Navbar Items-->
            <li class="nav-item dropdown no-caret mr-3 mr-lg-0 dropdown-user">
               <a title="Click to view the account or logout option" class="btn btn-icon btn-transparent-dark dropdown-toggle" id="navbarDropdownUserImage" href="javascript:void(0);" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img class="img-fluid" src="<?php echo $_SESSION['p_photo']; ?>" /></a>
               <div class="dropdown-menu dropdown-menu-right border-0 shadow animated--fade-in-up" aria-labelledby="navbarDropdownUserImage">
                  <h6 class="dropdown-header d-flex align-items-center">
                     <img  class="dropdown-user-img" src="<?php echo $_SESSION['p_photo']; ?>" />
                     <div class="dropdown-user-details">
                        <div class="dropdown-user-details-name"><?php echo $_SESSION['business']; ?></div>
                        <div class="dropdown-user-details-email"><?php echo $_SESSION['name']; ?></div>
                     </div>
                  </h6>
                  <div class="dropdown-divider"></div>
                  <a title="View your account details" class="dropdown-item" href="profile.php?id=<?php echo $_SESSION['id']; ?>">
                     <div class="dropdown-item-icon"><i data-feather="settings"></i></div>
                     Account
                  </a>
                  <a title="See your balance details" class="dropdown-item" href="peoney.php?id=<?php echo $_SESSION['id']; ?>">
                     <div class="dropdown-item-icon"><i class="fas fa-wallet"></i></div>
                     Balance
                  </a>
                  <a title="লগআউট করুন" class="dropdown-item" href="logout.php">
                     <div class="dropdown-item-icon"><i data-feather="log-out"></i></div>
                     Logout
                  </a>
               </div>
            </li>
         </ul>
      </nav>
      <div id="layoutSidenav">
      <div id="layoutSidenav_nav">
         <nav class="sidenav shadow-right sidenav-light">
            <div class="sidenav-menu">
               <div class="nav accordion" id="accordionSidenav">
                  <!-- Sidenav Menu Heading (Account)-->
                  <!-- * * Note: * * Visible only on and above the sm breakpoint-->
                  <div class="sidenav-menu-heading d-sm-none">Account</div>
                  <!-- Sidenav Heading (Addons)-->
                  <a title="Add a new parcel" class="btn btn-primary m-3 " href="addParcel.php">
                     <div class="nav-link-icon"><i class="fas fa-plus 1.33em mr-2"></i></div>
                     Add new parcel
                  </a>
                  <a title="" class="nav-link" href="dashboard.php">
                     <div class="nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                     Dashboard
                  </a>
                  <a title="View all parcels" class="nav-link" href="parcel.php">
                     <div class="nav-link-icon"><i class="fas fa-box-open"></i></div>
                     Parcel
                  </a>
                  <?php if ($_SESSION['role'] =='1') {?>
                  <a title="View all payment statements" class="nav-link" href="peoney.php?id=<?php echo $_SESSION['id']; ?>">
                     <div class="nav-link-icon"><i class="fas fa-scroll"></i></div>
                     Payment
                  </a>
                  <a target="" title="সকল  পেমেন্ট স্টেটমেন্ট দেখুন" class="nav-link" href="#">
                     <div class="nav-link-icon"><i class="fab fa-facebook"></i></div>
                     Discussion
                  </a>
                <?php } ?>
                  <?php if ($_SESSION['role'] =='5') {?>
                  <a title="See All Hero " class="nav-link" href="hero.php">
                     <div class="nav-link-icon"><i class="fas fa-biking"></i></div>
                     Rider
                  </a>
                  <a title="See All Service" class="nav-link" href="service.php">
                     <div class="nav-link-icon"><i class="fas fa-list-alt"></i></div>
                     Service
                  </a>
                  <a title="See All Area" class="nav-link" href="area.php">
                     <div class="nav-link-icon"><i class="fas fa-map-marked-alt"></i></div>
                     Area
                  </a>
                  <?php } ?>
<?php
include 'config.php';
$queryn = "SELECT * FROM notification
WHERE notification_default = 1
 ORDER BY notification_id  DESC LIMIT 1";
$resultn = mysqli_query($connection,$queryn) or die("Query Faield.");
$countn = mysqli_num_rows($resultn);
?>
<?php
if ($countn>0) {
while ($rown = mysqli_fetch_assoc($resultn)) {
?>
<div class="m-2">
<div class="bg-gray-100 rounded p-3">
    <p class="text-center m-1 "><?php echo $rown['notification_content']; ?></p>
    <a class="<?php echo $rown['notification_color']; ?> btn-sm d-flex justify-content-center" href="<?php echo $rown['notification_link']; ?>"><?php echo $rown['notification_text']; ?></a>
</div>
</div>
<?php }} ?>

                  <!-- অন্যান্য  -->
               </div>
            </div>
            <!-- Sidenav Footer-->
            <div class="sidenav-footer">
               <div class="sidenav-footer-content">
                  <div  class="sidenav-footer-subtitle">Logged in as:</div>
                  <div class="sidenav-footer-title"><?php echo $_SESSION['name']; ?></div>
               </div>
            </div>
         </nav>
      </div>
      <div id="layoutSidenav_content">
      <!-- Main Content -->
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5e6e963aeec7650c33202caf/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
