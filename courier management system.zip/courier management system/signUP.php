<?php ob_start(); ?>
<?php
session_start();
if (isset($_SESSION['username'])) {
  header('location: dashboard.php');
  bo_enf_fluch();
}?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="smartLogcustom.js"></script>
<link rel="stylesheet" href="smartLogcustom.css">



<!-- All the files that are required -->
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link href='https://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.13.1/jquery.validate.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>সাইনআপ | পিয়ন কুরিয়ার লিমেটেড</title>
<link rel="icon" type="image/x-icon" href="assets/img/favicon.png" />
<!-- REGISTRATION FORM -->
<div class="text-center" style="padding:50px 0">
	<div class="logo">রেজিস্টার</div>
	<!-- Main Form -->
	<div class="login-form-1">

		<!--PHP New User -->
		<?php
		   if (isset($_POST['submit'])) {
		   include 'config.php';
		   $username = mysqli_real_escape_string($connection,$_POST['username']);
		   $password = mysqli_real_escape_string($connection,$_POST['password']);
		   $email = mysqli_real_escape_string($connection,$_POST['email']);
		   $number = mysqli_real_escape_string($connection,$_POST['number']);
		   $business = mysqli_real_escape_string($connection,$_POST['business']);
		   $businessLink = mysqli_real_escape_string($connection,$_POST['businessLink']);
		   $address = mysqli_real_escape_string($connection,$_POST['address']);
		   $name = mysqli_real_escape_string($connection,$_POST['name']);

		   $query2 ="SELECT username FROM merchant WHERE username='$username'";
		   $result2 = mysqli_query($connection,$query2) or die("কিউরি ফেইল হয়েছে।");

		   $count = mysqli_num_rows($result2);
		   if($count > 0){
		   echo 'এই ইউজারনেম ইতোমধ্যেই রয়েছে';
		   }else{
		   $query1 = "INSERT INTO merchant (username,number,password,email,business,address,name,w_link)
		   VALUE ('$username','$number','$password','$email','$business','$address','$name','$businessLink')";
		   $result1 = mysqli_query($connection,$query1) or die("কিউরি ফেইল হয়েছে।");
		   if($result1){
				 header('location: dashboard.php');
					 bo_enf_fluch();

		   }


		   }

		   }

		   ?>

		<!--PHP New User -->


		<form id="register-form" class="text-left" action="<?php $_SERVER['PHP_SELF'] ?>"  method="post">
			<div class="login-form-main-message"></div>
			<div class="main-login-form">
				<div class="login-group">


						<div class="form-group">
							<label for="reg_fullname" class="sr-only">সম্পূর্ণ নাম</label>
							<input required type="text" class="form-control" id="reg_fullname" name="name" placeholder="সম্পূর্ণ নাম">
						</div>

						<div class="form-group">
							<label for="reg_fullname" class="sr-only">বিজনেস নাম</label>
							<input required type="text" class="form-control" id="reg_fullname" name="business" placeholder="বিজনেস নাম">
						</div>
						<div class="form-group">
							<label for="reg_fullname" class="sr-only">বিজনেস লিংক</label>
							<input required type="text" class="form-control" id="reg_fullname" name="businessLink" placeholder="বিজনেস লিংক">
						</div>
						<div class="form-group">
						<div class="form-group">
							<label for="reg_fullname" class="sr-only">পিকআপ ঠিকানা</label>
							<input required type="text" class="form-control" id="reg_fullname" name="address" placeholder="পিকআপ ঠিকান">
						</div>

						<div class="form-group">
							<label for="reg_fullname" class="sr-only">মোবাইল নম্বর</label>
							<input required type="text" class="form-control" id="reg_fullname" name="number" placeholder="মোবাইল নম্বর">
						</div>

						<label for="reg_username" class="sr-only">ইউজারনেম</label>
						<input required type="text" class="form-control" id="reg_username" name="username" placeholder="ইউজারনেম">
					</div>
					<div class="form-group">
						<label for="reg_password" class="sr-only">পাসওয়ার্ড</label>
						<input required type="password" class="form-control" id="reg_password" name="password" placeholder="পাসওয়ার্ড">
					</div>
					<div class="form-group">
						<label for="reg_email" class="sr-only">ইমেইল</label>
						<input type="email" class="form-control" id="reg_email" name="email" placeholder="ইমেইল">
					</div>



					<div class="form-group login-group-checkbox">
						<input required type="checkbox" class="" id="reg_agree" name="reg_agree">
						<label for="reg_agree">আমি রাজি <a href="https://peonbd.com/terms/">টার্মস এবং কন্ডিশান</a></label>
					</div>
				</div>
				<input type="submit" class="login-button" name="submit" value="&#10097;">
			</div>
			<div class="etc-login-form">
				<p>ইতোমধ্যেই স্বজন ? <a href="index.php">লগইন করুন</a></p>
			</div>
		</form>
	</div>
	<!-- end:Main Form -->
</div>
<div class="footer fixed-bottom">
	<img src="footer.png" class="footer-img">
</div>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5e6e963aeec7650c33202caf/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
