<?php ob_start();
 $title = "All riders";
 include 'menu.php';
if ($_SESSION['role']== '1' or $_SESSION['role']== '0') {
  header("location: index.php");
  die;
}
 ?>
 <main>
    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
        <div class="container">
            <div class="page-header-content pt-4">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto mt-4">
                        <h1 class="page-header-title">
                            <div class="page-header-icon"><i class="fas fa-biking"></i></div>
                            Rider
                        </h1>
                        <div class="page-header-subtitle">Rider</div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Main page content-->
    <div class="container mt-n10">
        <div class="card mb-4">
            <div class="card-header">All riders &nbsp;
            <a href="addHero.php" class="btn btn-primary btn-xs btn-icon ">
            <i class="fas fa-plus-circle"></i>
          </a>
            </div>



            <div class="card-body">
                <div class="datatable">
                    <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

<?php
include 'config.php';
$query = "SELECT * FROM hero ORDER BY hero_id DESC";
$result = mysqli_query($connection,$query) or die("Query Faield.");
$count = mysqli_num_rows($result);
if ($count>0) {

         ?>

                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>No.</th>
                                <th>Address</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                              <th>Name</th>
                              <th>No.</th>
                              <th>Address</th>
                              <th>Action</th>
                            </tr>
                        </tfoot>


                        <tbody>
<?php
while ($row = mysqli_fetch_assoc($result)) {
?>
                            <tr>
                                <td><?php echo $row['hero_name']; ?><br>
                                Father: <?php echo $row['hero_father']; ?>

                                </td>
                                <td><?php echo $row['hero_mobile']; ?><br>
                                  <?php echo $row['hero_b_number']; ?>
                                </td>
                                <td><?php echo $row['hero_addr']; ?></td>
                                <td><a href="updateHero.php?id=<?php echo $row['hero_id']; ?>" class="btn btn-datatable btn-icon btn-transparent-dark"><i class="fas fa-pencil-alt"></i></a></td>
                            </tr>
                            <?php } ?>
                        </tbody>
                        <?php } ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php include 'footer.php';?>
