<?php include 'part1.php';?>
<?php include 'part2.php';?>
<?php include 'footer.php';?>
