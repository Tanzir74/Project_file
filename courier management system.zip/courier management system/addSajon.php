<?php ob_start(); ?>
<?php $title = "Merchant addition"; ?>
<?php include 'menu.php'; ?>
<?php
if (!$_SESSION['role']== '5') {
  header("location: index.php");
}
 ?>
<?php
if (isset($_POST['submit'])) {
  include 'config.php';
  $id = mysqli_real_escape_string($connection,$_POST['id']);
  $name = mysqli_real_escape_string($connection,$_POST['name']);
  $username = mysqli_real_escape_string($connection,$_POST['username']);
  $business = mysqli_real_escape_string($connection,$_POST['business']);
  $email = mysqli_real_escape_string($connection,$_POST['email']);
  $number = mysqli_real_escape_string($connection,$_POST['number']);
  $address = mysqli_real_escape_string($connection,$_POST['address']);
  $bk_number = mysqli_real_escape_string($connection,$_POST['bk_number']);
 $password = mysqli_real_escape_string($connection,$_POST['password']);


               $query ="SELECT username FROM merchant WHERE username='$username'";
               $result = mysqli_query($connection,$query) or die("ERROR");

               $count = mysqli_num_rows($result);
               if($count > 0){
               echo "This username already exists.";
               }else{
               $query1 = "INSERT INTO merchant (name,business,username,number,address,email,bk_number,password)
               VALUE ('$name','$business','$username','$number','$address','$email','$bk_number','$password')";
               $result1 = mysqli_query($connection,$query1) or die("ERROR");
               if($result1){
               header('location: sajon.php');

               bo_enf_fluch();
               }


               }

               }

               ?>












                <main>
                    <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                        <div class="container-fluid">
                            <div class="page-header-content">
                                <div class="row align-items-center justify-content-between pt-3">
                                    <div class="col-auto mb-3">
                                        <h1 class="page-header-title">
                                            <div class="page-header-icon"><i data-feather="user"></i></div>
                                            Adding new merchants
                                        </h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                    <!-- Main page content-->
                    <div class="container mt-4">
                        <hr class="mt-0 mb-4" />
                        <div class="row">
                            <!-- <div class="col-xl-4">

                                <div hidden class="card">
                                    <div class="card-header pr-5">বিজনেস ছবি  <div class='badge badge-info badge-pill'>আসছে</div></div>
                                    <div class="card-body text-center">
                                        <img class="img-account-profile rounded-circle mb-2" src="assets/img/illustrations/profiles/profile-1.png" alt="" />
                                        <div class="small font-italic text-muted mb-4">JPG অথবা PNG সর্বচ্চ সাইজ 5 MB</div>
                                        <button class="btn btn-primary" type="button">নতুন ছবি আপলোড</button>
                                    </div>
                                </div>

                            </div> -->
                            <div class="col-xl-8">
                                <!-- Account details card-->
                                <div class="card mb-4">
                                    <div class="card-header">Account details</div>
                                    <div class="card-body">

                                        <form action="addSajon.php" method="POST" autocomplete="off">
                                            <input type="hidden" name="id" >
                                            <!-- Form Group (username)-->
                                            <div class="form-group">
                                                <label  class="small mb-1" for="inputUsername">Username</label>
                                                <input  class="form-control"  name="username" type="text" placeholder="Your username (not changeable)"  />
                                            </div>
                                            <!-- Form Row-->
                                            <div class="form-row">
                                                <!-- Form Group (name)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputFirstName">Full name</label>
                                                    <input name="name" class="form-control" id="inputFirstName" type="text" placeholder="Your full name"  />
                                                </div>
                                                <!-- Form Group (Moble)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputLastName">Mobile number</label>
                                                    <input name="bk_number" class="form-control" id="inputLastName" type="text" placeholder="Mobile number" />
                                                </div>
                                            </div>
                                            <!-- Form Row        -->
                                            <div class="form-row">
                                                <!-- Form Group (organization name)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputOrgName">Business name</label>
                                                    <input name="business" class="form-control" id="inputOrgName" type="text" placeholder="Your business name" />
                                                </div>
                                                <!-- Form Group (Number)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputLocation">Business Number (Main Number)</label>
                                                  <input class="form-control" id="inputPhone" type="tel" name="number" placeholder="Enter your business mobile number" />
                                                </div>
                                            </div>
                                            <!-- Form Group (email address)-->
                                            <div class="form-group">
                                                <label class="small mb-1" for="inputEmailAddress">Email address</label>
                                                <input name="email" class="form-control" id="inputEmailAddress" type="email" placeholder="Your email address"  />
                                            </div>
                                            <!-- Form Group (email address)-->
                                            <div class="form-group">
                                                <label class="small mb-1" for="inputEmailAddress">Pickup address</label>
                                                <input name="address" class="form-control" id="inputLocation" type="text" placeholder="Your pickup address"  />
                                            </div>

                                              <div class="form-group">
                                                <label class="small mb-1" for="inputEmailAddress">Password</label>
                                                <input name="password" class="form-control" id="inputLocation" type="text" placeholder="Password" />
                                            </div>

                                            <!-- Form Row-->
                                            <div class="form-row">
                                                <a href="sajon.php" class="btn btn-dark" type="button"><i class="fas fa-reply"></i> &nbsp;&nbsp;Back to Merchant</a>
                                                &nbsp;&nbsp;&nbsp;
                                            <button type="submit" name="submit" class="btn btn-primary" type="button">Update save</button>


                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>

<?php include 'footer.php';?>
