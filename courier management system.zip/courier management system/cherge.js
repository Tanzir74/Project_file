const serviceOption = document.getElementById('serviceOption');
const charge = document.getElementById('charge');
const payable = document.getElementById('payable');

let serviceName = ''
let inputWeightDefaultValue = '';
let inputCashCollection = '';

serviceOption.addEventListener('change', e => {
    serviceName = e.target.value;
    calculatePayment(serviceName, inputWeightDefaultValue, inputCashCollection);
});

function calculatePayment(serviceOptionValue, inputWeightValue, inputDefaultCash) {
    if (serviceOptionValue === '1' && inputWeightValue < 11 && inputWeightValue && inputCashCollection &&  inputCashCollection > 0) {
        const serviceCharge = (inputWeightValue * 20) + 80;
        const paybleCharge = inputDefaultCash - serviceCharge;
        payable.innerText = paybleCharge;
        charge.innerText = serviceCharge;
    }
    else if (serviceOptionValue === '2' && inputWeightValue < 11 && inputWeightValue && inputCashCollection &&  inputCashCollection > 0) {
        const serviceCharge = (inputWeightValue * 15) + 60;
          const paybleCharge = inputDefaultCash - serviceCharge;
        payable.innerText = paybleCharge;
        charge.innerText = serviceCharge;
    }
    else {
        payable.innerText = '00';
        charge.innerText = '00';
    }
}

function myFunction(a) {
    inputWeightDefaultValue = a;
        if(inputWeightDefaultValue > 0 && inputCashCollection > 0){
      calculatePayment(serviceName, inputWeightDefaultValue, inputCashCollection)
    }
}

function myNewFunction(value){
  inputCashCollection = value
  if(inputWeightDefaultValue > 0 && inputCashCollection > 0){
    calculatePayment(serviceName, inputWeightDefaultValue, inputCashCollection)
  }
}
