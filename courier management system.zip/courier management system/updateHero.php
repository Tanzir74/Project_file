<?php ob_start();
$title = "Rider Edit";
 include 'menu.php';
if ($_SESSION['role']== '1' or $_SESSION['role']== '0') {
  header("location: index.php");
  die;
}
 ?>
<?php
if (isset($_POST['submit'])) {
  include 'config.php';
  $id = mysqli_real_escape_string($connection,$_POST['id']);
  $hero_name = mysqli_real_escape_string($connection,$_POST['hero_name']);
  $hero_username = mysqli_real_escape_string($connection,$_POST['hero_username']);
  $hero_mobile = mysqli_real_escape_string($connection,$_POST['hero_mobile']);
  $hero_b_number = mysqli_real_escape_string($connection,$_POST['hero_b_number']);
  $hero_DOB_day = mysqli_real_escape_string($connection,$_POST['hero_DOB_day']);
  $hero_DOB_month = mysqli_real_escape_string($connection,$_POST['hero_DOB_month']);
  $hero_DOB_year = mysqli_real_escape_string($connection,$_POST['hero_DOB_year']);
  $hero_father = mysqli_real_escape_string($connection,$_POST['hero_father']);
  $hero_mother = mysqli_real_escape_string($connection,$_POST['hero_mother']);
  $hero_addr = mysqli_real_escape_string($connection,$_POST['hero_addr']);


  $query1 = "UPDATE `hero` SET
  `hero_name` = '$hero_name',
  `hero_username` = '$hero_username',
  `hero_mobile` = '$hero_mobile',
  `hero_b_number` = '$hero_b_number',
  `hero_DOB_day` = '$hero_DOB_day',
  `hero_DOB_month` = '$hero_DOB_month',
  `hero_DOB_year` = '$hero_DOB_year',
  `hero_father` = '$hero_father',
  `hero_mother` = '$hero_mother',
  `hero_addr` = '$hero_addr' WHERE `hero`.`hero_id` = $id";

  $result1 = mysqli_query($connection,$query1) or die("ERROR".mysqli_error());
  if ($result1) {
    header("location: hero.php");
    bo_enf_fluch();
  }
}

?>









                <main>
                    <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                        <div class="container-fluid">
                            <div class="page-header-content">
                                <div class="row align-items-center justify-content-between pt-3">
                                    <div class="col-auto mb-3">
                                        <h1 class="page-header-title">
                                            <div class="page-header-icon"><i data-feather="user"></i></div>
                                            Account Settings - Rider
                                        </h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                    <!-- Main page content-->
                    <div class="container mt-4">
                        <hr class="mt-0 mb-6" />
                        <div class="row">
                            <div class="col-xl-6">
                              <?php
                              $user_id = $_GET['id'];

                              include 'config.php';
                              $query = "SELECT * FROM hero WHERE hero_id  = {$user_id}";
                              $result = mysqli_query($connection,$query) or die("Query Faield.");
                              $count = mysqli_num_rows($result);


                              if ($count>0) {
                              while ($row = mysqli_fetch_assoc($result)) {
                              ?>
                                <div class="card mb-4">
                                    <div class="card-header">Account details</div>
                                    <div class="card-body">

                                        <form action="<?php $_SERVER["PHP_SELF"] ?>" method="POST" autocomplete="off">
                                            <input type="hidden" name="id" value="<?php echo $row['hero_id']; ?>">
                                            <!-- Form Group (username)-->
                                            <div class="form-group">
                                                <label  class="small mb-1" for="inputUsername">Username</label>
                                                <input  class="form-control"  name="hero_username" type="text" placeholder="Username (not changeable)"  value="<?php echo $row['hero_username']; ?>" />
                                            </div>
                                            <!-- Form Row-->
                                            <div class="form-row">
                                                <!-- Form Group (name)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputFirstName">Full name</label>
                                                    <input name="hero_name" class="form-control" id="inputFirstName" type="text" placeholder="Full name"  value="<?php echo $row['hero_name']; ?>" />
                                                </div>
                                                <!-- Form Group (Moble)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputLastName">Mobile number</label>
                                                    <input name="hero_mobile" class="form-control" id="inputLastName" type="text" placeholder="Mobile number"  value="<?php echo $row['hero_mobile']; ?>"/>
                                                </div>
                                            </div>
                                            <!-- Form Row-->
                                            <div class="form-row">
                                                <!-- Form Group (name)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputFirstName">Alternate mobile number</label>
                                                    <input name="hero_b_number" class="form-control" id="inputFirstName" type="text" placeholder="Alternate mobile number"  value="<?php echo $row['hero_b_number']; ?>" />
                                                </div>
                                                <!-- Form Group (Moble)-->
                                                <div class="form-group col-md-2">
                                                    <label class="small mb-1" for="hero_DOB_day">Date of birth</label>
                                                        <input name="hero_DOB_day" class="form-control" id="hero_DOB" type="text" placeholder="Date of birth" value="<?php echo $row['hero_DOB_day']; ?>" />
                                                </div>
                                                <div class="form-group col-md-2">
                                                    <label class="small mb-1" for="hero_DOB_month">Month of birth</label>
                                                        <input name="hero_DOB_month" class="form-control" id="hero_DOB" type="text" placeholder="Month of birth" value="<?php echo $row['hero_DOB_month']; ?>" />
                                                </div>
                                                <div class="form-group col-md-2">
                                                    <label class="small mb-1" for="hero_DOB">Year of birth</label>
                                                        <input name="hero_DOB_year" class="form-control" id="hero_DOB" type="text" placeholder="Year of birth" value="<?php echo $row['hero_DOB_year']; ?>" />
                                                </div>
                                            </div>
                                            <!-- Form Row-->
                                            <div class="form-row">
                                                <!-- Form Group (name)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputFirstName">Father's name</label>
                                                    <input name="hero_father" class="form-control" id="inputFirstName" type="text" placeholder="Father's name"  value="<?php echo $row['hero_father']; ?>" />
                                                </div>
                                                <!-- Form Group (Moble)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputLastName">Mother's name</label>
                                                    <input name="hero_mother" class="form-control" id="inputLastName" type="text" placeholder="Mother's name" value="<?php echo $row['hero_mother']; ?>" />
                                                </div>
                                            </div>
                                            <!-- Form Group (email address)-->
                                            <div class="form-group">
                                                <label class="small mb-1" for="inputEmailAddress">Address</label>
                                                <input name="hero_addr" class="form-control" id="inputLocation" type="text" placeholder=" Address"  value="<?php echo $row['hero_addr']; ?>" />
                                            </div>

                                            <!-- Form Row-->
                                            <div class="form-row">
                                                <a href="hero.php" class="btn btn-dark" type="button"><i class="fas fa-reply"></i> &nbsp;&nbsp;Return to rider list</a>
                                                &nbsp;&nbsp;&nbsp;
                                            <button type="submit" name="submit" class="btn btn-primary" type="button">Save</button>
                                        </form>
                                      <?php }}else {
                                        echo "ERROR";
                                      }
                                                     ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>

<?php include 'footer.php';?>
