<?php
$connection = mysqli_connect('localhost','root','','maagbdco_courier') or die("ডাটা সেন্টার কানেক্ট হয়নি !".mysqli_error());

 ?>
