<?php ob_start(); ?>
<?php $title = "Bulk parcel addition"; ?>
<?php include 'menu.php'; ?>
<main>
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
      <div class="container-fluid">
         <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
               <div class="col-auto mb-3">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i class="fas fa-box-open"></i></div>
                     Bulk parcel addition
                  </h1>
               </div>
            </div>
         </div>
      </div>
   </header>
   <?php
      $c_m_business = "";
        include 'config.php';

        // Auto ID Genaretor
        date_default_timezone_set("Asia/Dhaka");
        $Ptime = strtoupper(date("h:i:s a"));
        $Pdate = strtoupper(date("d M y"));

        if (isset($_POST["import"])) {
          $fileName = $_FILES["file"]["tmp_name"];

          if ($_SESSION['role'] =='1') {
             $c_m_business = $_SESSION['id'];
          }else if ($_SESSION['role'] =='5') {
          $c_m_business = $_POST["merchant"];
          }


          if ($_FILES["file"]["size"] > 0 ) {
            $file = fopen($fileName, "r");

            while (($column = fgetcsv($file, 1000, ",")) !== FALSE) {

              $zero = $column[0];
              $one = $column[1];
              $tow = $column[2];
              $three = $column[3];
              $four = $column[4];
              $five = $column[5];
              $six = $column[6];
              $sevin = $column[7];
              $eight = $column[8];

              //Service Price
         include 'chargecsv.php';

              $sqlInsert  = "INSERT into parcel (c_Inv , c_name , c_number , c_b_number , c_address , c_price , weight 	, c_service , note , c_m_business , Ptime , Pdate , c_charge) values ('" . $zero . "',
                '" . $one . "',
                '" . $tow . "',
                '" . $three . "',
                '" . $four . "',
                '" . $five . "',
                '" . $six . "',
                '" . $sevin . "',
                '" . $eight . "',
                '" . $c_m_business . "',
                '" . $Ptime . "',
                '" . $Pdate . "',
                '" . $cost . "')";

              $result = mysqli_query($connection, $sqlInsert);

              if (!empty($result)) {
                echo "<p class='alert alert-green ml-5 mr-5'>Your file has been uploaded successfully. </p>";
              }else {
                echo "<p class='alert alert-red ml-5 mr-5'> Your file has not been uploaded for any reason. Please let us know about this problem in a live chat. </p>";
              }

            }
          }
        }

        ?>
   <!-- Main page content-->
   <div class="container mt-4">
      <hr class="mt-0 mb-4" />
      <div class="row">
         <div class="col-xl-6">
            <!-- Account details card-->
            <div class="card card-waves">
               <div class="card-header">CSV file upload</div>
               <div class="card-body">
                  <form class="form-horizoontal" action="" method="post" name="uploadCsv" enctype="multipart/form-data">
                     <?php if ($_SESSION['role'] =='5') { ?>
                     <select required class="form-control mb-3" searchable="Search ....." name="merchant">
                        <option value="" disabled selected>Select a merchant</option>
                        <?php
                           include 'config.php';
                             $query_s = "SELECT * FROM merchant";
                               $result_s = mysqli_query($connection,$query_s)or die("ERROR");
                               if (mysqli_num_rows($result_s) > 0) {
                             while ($row_S = mysqli_fetch_assoc($result_s)) {
                           echo "<option value='{$row_S['id']}'>{$row_S['business']}</option>";
                           }  } ?>
                     </select>
                     <?php } ?>
                     <div class="input-group mb-3">
                        <div class="input-group-prepend">
                           <span class="input-group-text" id="inputGroupFileAddon01">Upload</span>
                        </div>
                           <input required type="file" name="file" class="form-control form-control" accept=".csv">
                     </div>
                     <button type="submit" name="import" class="btn btn-primary btn-md btn-block">Upload</button>
                  </form>
               </div>
            </div>
            <!-- Account details card-->
         </div>
         <div class="col-xl-6">
            <!-- Account details card-->
            <div class="card card-waves">
               <div class="card-header">Information about bulk uploads</div>
               <div class="card-body">
                  <div class="alert alert-green">
                     <p><i class="fas fa-arrow-alt-circle-down"></i> &nbsp;&nbsp; First download our example file from the <b> Download </b> button below. </p>
                     <p><i class="fas fa-language"></i> &nbsp;&nbsp; In case of bulk upload only complete data in English.</p>
                     <p><i class="fas fa-box-open"></i> &nbsp;&nbsp; The H number column of the CSV file or the cell of the service is basically for selecting service 1 or 2. In this case a specific code has to be put there. For example, if you want to specify 'DMP 48 hour' service, its service code is "1". If you want to select ‘DMP 36 hours’ service, its service code will be “2”. Also, if you have a specific corporate service, then enter your specific service code.
                     </p>
                  </div>
                  <p class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i>&nbsp;&nbsp; After entering the complete data in your CSV file, you must delete the first line or (title row). The complete file will contain only your parcel information. There will be no titles or anything like that.  </p>
                  <p class="alert alert-green"><i class="fas fa-text-width"></i> &nbsp;&nbsp;Simply enter your parcel details in that file. And save as CSV file.</p>
                  <a href="excel/ExampleFile.csv" class="btn btn-success btn-block" type="button" name="button">DOWNLOAD</a>
               </div>
            </div>
            <!-- Account details card-->
         </div>
      </div>
   </div>
</main>
<?php include 'footer.php';?>
