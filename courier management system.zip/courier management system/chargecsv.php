<?php
// Same Day Service Price
$percentage= 1;
if ($sevin == 1 and $six == 1) {
$cost = "100";
}else if($sevin == 1 and $six == 2){
 $cost = "120";
}else if($sevin == 1 and $six == 3){
 $cost = "140";
}else if($sevin == 1 and $six == 4){
 $cost = "160";
}else if($sevin == 1 and $six == 5){
 $cost = "180";
}else if($sevin == 1 and $six == 6){
 $cost = "200";
}else if($sevin == 1 and $six == 7){
 $cost = "220";
}else if($sevin == 1 and $six == 8){
 $cost = "240";
}else if($sevin == 1 and $six == 9){
 $cost = "260";
}else if($sevin == 1 and $six == 10){
 $cost = "280";
}
// Next Day Service Price
if ($sevin == 2 and $six == 1) {
$cost = "60";
}else if($sevin == 2 and $six == 2){
 $cost = "75";
}else if($sevin == 2 and $six == 3){
 $cost = "90";
}else if($sevin == 2 and $six == 4){
 $cost = "105";
}else if($sevin == 2 and $six == 5){
 $cost = "120";
}else if($sevin == 2 and $six == 6){
 $cost = "135";
}else if($sevin == 2 and $six == 7){
 $cost = "150";
}else if($sevin == 2 and $six == 8){
 $cost = "165";
}else if($sevin == 2 and $six == 9){
 $cost = "180";
}else if($sevin == 2 and $six == 10){
 $cost = "195";
}

// Frozen Service Price
if ($sevin == 3 and $six == 1) {
  $charge = 100;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 3 and $six == 2){
  $charge = 120;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 3 and $six == 3){
  $charge = 140;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 3 and $six == 4){
  $charge = 160;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 3 and $six == 5){
  $charge = 180;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 3 and $six == 6){
  $charge = 200;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 3 and $six == 7){
  $charge = 220;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 3 and $six == 8){
  $charge = 240;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 3 and $six == 9){
  $charge = 260;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 3 and $six == 10){
  $charge = 280;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}



//Dhaka Sub City
if ($sevin == 4 and $six == 1) {
  $charge = 100;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 4 and $six == 2){
  $charge = 115;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 4 and $six == 3){
  $charge = 130;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 4 and $six == 4){
  $charge = 145;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 4 and $six == 5){
  $charge = 160;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 4 and $six == 6){
  $charge = 175;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 4 and $six == 7){
  $charge = 190;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 4 and $six == 8){
  $charge = 205;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 4 and $six == 9){
  $charge = 220;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 4 and $six == 10){
  $charge = 235;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}

//Out of Dhaka
if ($sevin == 5 and $six == 1) {
  $charge = 130;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 5 and $six == 2){
  $charge = 160;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 5 and $six == 3){
  $charge = 190;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 5 and $six == 4){
  $charge = 220;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 5 and $six == 5){
  $charge = 250;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 5 and $six == 6){
  $charge = 280;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 5 and $six == 7){
  $charge = 310;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 5 and $six == 8){
  $charge = 340;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 5 and $six == 9){
  $charge = 370;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 5 and $six == 10){
  $charge = 400;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}

// 3rd Booking Service Price
if ($sevin == 6 and $six == 1) {
  $charge = 20;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 6 and $six == 2){
  $charge = 20;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 6 and $six == 3){
  $charge = 20;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 6 and $six == 4){
  $charge = 20;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 6 and $six == 5){
  $charge = 20;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 6 and $six == 6){
  $charge = 20;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 6 and $six == 7){
  $charge = 20;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 6 and $six == 8){
  $charge = 20;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 6 and $six == 9){
  $charge = 20;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}else if($sevin == 6 and $six == 10){
  $charge = 20;
  $cod = $five;
  $percentage = 1;
  $price = ($percentage / 100) * $cod;
  $cost = $price + $charge;
}
// 3rd Booking Service Price
 ?>
