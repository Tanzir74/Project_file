<?php
  include 'config.php';
  $usernmae=$_POST['usname'];
  $password=$_POST['password'];
  $data=$_POST[$abc];
  $sql= mysqli_query($connection,"INSERT INTO admin (username,password,email)
    VALUES('".$usernmae."','".$password."','".$data."')");
 ?>
