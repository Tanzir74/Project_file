<?php ob_start();
 $title = "All areas";
 include 'menu.php';
if ($_SESSION['role']== '1' or $_SESSION['role']== '0') {
  header("location: index.php");
  die;
}
 ?><main>
    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
        <div class="container">
            <div class="page-header-content pt-4">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto mt-4">
                        <h1 class="page-header-title">
                            <div class="page-header-icon"><i class="fas fa-map-marked-alt"></i></div>
                            Area
                        </h1>
                        <div class="page-header-subtitle">Extensive coverage across the country </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Main page content-->
    <div class="container mt-n10 col-md-10">
        <div class="card mb-4">
            <div class="card-header">All areas &nbsp;
            <a href="addArea.php" class="btn btn-primary btn-xs btn-icon ">
            <i class="fas fa-plus-circle"></i>
          </a>
            </div>



            <div class="card-body">
                <div class="datatable">
                    <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

<?php
include 'config.php';
$query = "SELECT * FROM area ORDER BY id ASC";
$result = mysqli_query($connection,$query) or die("Query Faield.");
$count = mysqli_num_rows($result);
if ($count>0) {

         ?>

                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tfoot>
                            <tr>
                              <th>Name</th>
                              <th>Action</th>
                            </tr>
                        </tfoot>


                        <tbody>
<?php
while ($row = mysqli_fetch_assoc($result)) {
?>
                            <tr>
                                <td><?php echo $row['area_name']; ?></td>
                                <td>

                                    <button data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" id="dropdownFadeInUp<?php echo $row['id']; ?>" class="btn btn-datatable btn-icon btn-transparent-dark mr-2"><i data-feather="more-vertical"></i></button>
                                        <div class="dropdown-menu animated--fade-in-up" aria-labelledby="dropdownFadeInUp<?php echo $row['id']; ?>">
                                            <a data-toggle="modal" data-target="#staticBackdrops<?php echo $row['id']; ?>" class="dropdown-item" >Update area</a>







                                            <!-- Delete -->
                                            <a data-toggle="modal" data-target="#exampleModalSm<?php echo $row['id']; ?>" class="dropdown-item text-danger" >Delete</a>
                                                    </div>
                                            <!-- Small modal -->

                                            <div class="modal fade" id="exampleModalSm<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-sm" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title">The important thing</h5>
                                                            <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Do you want to delete <?php echo $row['area_name']; ?>areas? </p>
                                                        </div>
                                                        <div class="modal-footer">
                                                          <button class="btn btn-primary" type="button" data-dismiss="modal">না! থাক</button>
                                                          <a class="btn btn-danger" type="button" href="delete_area.php?id=<?php echo $row['id']; ?>">Delete</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>


                                            <!-- Modal -->
                                            <div class="modal fade" id="staticBackdrops<?php echo $row['id']; ?>" data-backdrop="static" tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="staticBackdropLabel">Role change</h5>
                                                            <button class="close" type="button" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
                                                        </div>
                                                        <div class="modal-body">
                                                          <form class="" action="updateArea.php" method="post">
                                                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

                                                             <div class="form-group">
                                                               <label>Service name</label>
                                                               <input name="area_name" class="form-control" type="text" placeholder="Service name" value="<?php echo $row['area_name']; ?>">
                                                             </div>
                                                             <div class="form-group">
                                                               <label>Service price</label>
                                                               <input name="price" class="form-control" type="text" placeholder="Service price" value="<?php echo $row['price']; ?>">
                                                             </div>

                                                        </div>
                                                        <div class="modal-footer"><button class="btn btn-dark" type="button" data-dismiss="modal">No, stay!</button>
                                                          <button class="btn btn-info my-4" type="submit" name="submit">Save</button>
                                                        </form>


                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                </td>
                            </tr>
                            <?php } ?>
                        </tbody>
                        <?php } ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php include 'footer.php';?>
