<?php
   session_start();
   if (!isset($_SESSION['username'])) {
     header("location: index.php");
   }
    ?>
<!-- Percel Action -->
<?php
   include 'config.php';
    include 'tokensms.php';
   if (isset($_REQUEST['subaction'])) {

     $c_heros = mysqli_real_escape_string($connection,$_POST['c_heros']);
     $c_actions = mysqli_real_escape_string($connection,$_POST['c_actions']);
     // $foo = mysqli_real_escape_string($connection,$_POST['foo']);

     $foo=$_POST['foo'];
     foreach($foo as $row)
     {
       $data=json_decode($row);
       // echo "<pre>"; print_r($data); exit();
       $parcel_id  =$data->parcel_id;
       $trId  =$data->trId;
       $c_Inv  =$data->c_Inv;
       $c_name  =$data->c_name;
       $c_number  =$data->c_number;
       $c_address  =$data->c_address;
       $c_area  =$data->c_area;
       $action_name  =$data->action_name;
       $c_m_business  =$data->c_m_business;
       $c_charge  =$data->c_charge;
       $c_price  =$data->c_price;
       $bk_number  =$data->bk_number;
       $c_service  =$data->c_service;

         $query = " UPDATE `parcel` SET
          `c_action` = '$c_actions',
          `c_hero` = '$c_heros'
          WHERE `parcel_id` = '$parcel_id' ";
          $result = mysqli_query($connection,$query) or die("Query Faield 1".mysqli_error($connection));



      $query1 = "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user,tr_hero) VALUE
      ('$parcel_id','$c_actions','{$_SESSION["name"]}','$c_heros')";
     $result1 = mysqli_query($connection,$query1) or die("Query Faield 2".mysqli_error($connection));

     if ($c_actions == "5") {
      // Calculation
      $sum=0;
      $totaldue=0;
      $CODsumTotal=0;
      // টোটাল চার্জ
      $sum += $c_charge;
      // টোটাল COD
      $CODsumTotal += $c_price;
      $totaldue = $CODsumTotal-$sum;
      // Calculation
      $query7 = "UPDATE merchant SET PEONEY = PEONEY + $totaldue WHERE merchant.id  = '$c_m_business'";
       $result1 = mysqli_query($connection,$query7) or die("Query Faield".mysqli_error($connection));

       $Pdate = strtoupper(date("d M y"));
      $queryin = "UPDATE `parcel` SET `lastAction` = '$Pdate' WHERE `parcel_id` = '$parcel_id' ";
       $resultin = mysqli_query($connection,$queryin) or die("Query Faield".mysqli_error($connection));
     }elseif ($c_actions == "9"){
       if ($c_service == "5") {
         // Calculation
         $sum=0;
         // টোটাল চার্জ
         $sum += $c_charge;
         $query7 = "UPDATE merchant SET PEONEY = PEONEY - ($sum/2) WHERE merchant.id  = '$c_m_business'";
          $result1 = mysqli_query($connection,$query7) or die("Query Faield".mysqli_error($connection));

          $Pdate = strtoupper(date("d M y"));
         $queryin = "UPDATE `parcel` SET `lastAction` = '$Pdate' WHERE `parcel_id` = '$parcel_id' ";
          $resultin = mysqli_query($connection,$queryin) or die("Query Faield".mysqli_error($connection));
       } else {
         // Calculation
         $sum=0;
         // টোটাল চার্জ
         $sum += $c_charge;
         $query7 = "UPDATE merchant SET PEONEY = PEONEY - $sum WHERE merchant.id  = '$c_m_business'";
          $result1 = mysqli_query($connection,$query7) or die("Query Faield".mysqli_error($connection));

          $Pdate = strtoupper(date("d M y"));
         $queryin = "UPDATE `parcel` SET `lastAction` = '$Pdate' WHERE `parcel_id` = '$parcel_id' ";
          $resultin = mysqli_query($connection,$queryin) or die("Query Faield".mysqli_error($connection));
       }


     }

   if ($result) {
     if (!$trId=="") {
       $track = ".Track order: - http://www.track.peonbd.com?serch=". $trId;
     }else {
       $track = ".Your Tracking Id: SPEEDY786592".$parcel_id;
     }
if ($c_actions == "4") {
$queryeh = "SELECT * FROM hero
WHERE hero_id = {$c_heros}";
$resulteh = mysqli_query($connection,$queryeh) or header("location: index.php");
$counteh = mysqli_num_rows($resulteh);
if ($counteh>0) {
while ($roweh = mysqli_fetch_assoc($resulteh)) {
       // SMS
       $sercice = $c_service;

       switch ($sercice) {
         case "1":
         $to = $c_number;
         $token = $tokens;
         $message = "Assalamu Alaikum! Dear " .$c_name. "! " .$roweh['hero_name']." - ".$roweh['hero_mobile']. " will deliver your parcel today . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
           break;
         case "2":
         $to = $c_number;
         $token = $tokens;
         $message = "Assalamu Alaikum! Dear " .$c_name. "! " .$roweh['hero_name']." - ".$roweh['hero_mobile']. " will deliver your parcel today . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
           break;
         case "3":
         $to = $c_number;
         $token = $tokens;
         $message = "Assalamu Alaikum! Dear " .$c_name. "! " .$roweh['hero_name']." - ".$roweh['hero_mobile']. " will deliver your parcel today . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
           break;
         case "4":
         $to = $c_number;
         $token = $tokens;
         $message = "Assalamu Alaikum! Dear " .$c_name. "! " .$roweh['hero_name']." - ".$roweh['hero_mobile']. " will deliver your parcel Within 3 days . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
           break;
         case "5":
         $to = $c_number;
         $token = $tokens;
         $message = "Assalamu Alaikum! Dear " .$c_name. "! " .$roweh['hero_name']." - ".$roweh['hero_mobile']. " will deliver your parcel Within 3-7 days . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
           break;
         case "5":
         $to = $c_number;
         $token = $tokens;
         $message = "Assalamu Alaikum! Dear " .$c_name. "! " .$roweh['hero_name']." - ".$roweh['hero_mobile']. " will deliver your parcel Within 2-3 days . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
           break;
         default:
         $message = "Assalamu Alaikum! Dear " .$c_name. "! We will deliver your parcel within a short time . Your Payable Amount -".$c_price." ৳  " .$track."   -Peon Courier Ltd";
       }

       $url = "http://api.greenweb.com.bd/api.php?json";


       $data= array(
       'to'=>"$to",
       'message'=>"$message",
       'token'=>"$token"
       ); // Add parameters in key value
       $ch = curl_init(); // Initialize cURL
       curl_setopt($ch, CURLOPT_URL,$url);
       curl_setopt($ch, CURLOPT_ENCODING, '');
       curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
       curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
       $smsresult = curl_exec($ch);
}}
       // SMS
     }
       header("location: parcel.php");
   }
        }
          }
      ?>
<!-- Percel Action -->





<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
            <meta http-equiv="x-ua-compatible" content="ie=edge">
            <title>Print | SPEEDY ALADDIN</title>
            <link rel="icon" type="image/x-icon" href="assets/img/favicon.png" />
                    <!--<link rel="icon" type="image/x-icon" href="assets/img/favicon.png" />-->
            <link rel="preconnect" href="https://fonts.gstatic.com">
            <link href="https://fonts.googleapis.com/css2?family=Baloo+Da+2:wght@400;500;600;700;800&family=Hind+Siliguri:wght@300;400;500;600;700&family=Mina:wght@400;700&display=swap" rel="stylesheet">
            <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">

            <link rel="stylesheet" href="css2/nstyles.css">
            <link rel="stylesheet" href="css2/bootstrap.min.css">
            <link rel="stylesheet" href="css2/mdb.min.css">
            <link rel="stylesheet" href="css2/style.css">
            <link rel="stylesheet" href="css2/responsive.css">
            <link rel="stylesheet" href="css2/datatables.min.css">
            <link rel="stylesheet" href="css2/datatables-select.min.css">
    </head>
    <body>
<link rel="stylesheet" href="css\print_parcel.css">
<?php        if (isset($_REQUEST['print'])) {
  $foo=$_POST['foo'];
  foreach($foo as $row)
  {
    $data=json_decode($row);
    // echo "<pre>"; print_r($data); exit();
    $parcel_id  =$data->parcel_id;
    $trId  =$data->trId;
    $c_Inv  =$data->c_Inv;
    $c_name  =$data->c_name;
    $c_number  =$data->c_number;
    $c_address  =$data->c_address;
    $c_area  =$data->area_name;
    $action_name  =$data->action_name;
    $c_m_business  =$data->business;
    $business_number  =$data->number;
    $c_charge  =$data->c_charge;
    $c_price  =$data->c_price;
    $bk_number  =$data->bk_number;


  ?>
<div class="book">
  <div class="page">
    <div class="subpage">

            <!--  -->
            <div class="text-center">
<!--<img src="assets/img/peon.png" alt="Peon" width="700" height="auto">-->
<h1 class="new5 bolt">SPEEDY ALADDIN</h1>
<span>&#9741; www.speedyaladdin.com</span>&nbsp;&nbsp; <span>&#9743; 02-84118072</span>&nbsp;&nbsp; <span>&#9993; speedyaladdin@gmail.com</span>

<hr class="new5">

<h1>Sender</h1>
<h1 class="bolt"><?php echo $c_m_business; ?></h1>
<h1><?php echo $business_number; ?></h1>
<hr class="new5">
<h1 >Recipient</h1>
<h1 class="bolt">Name:<?php echo $c_name; ?></h1>
<h1 class="bolt"> Mobile:<?php echo $c_number; ?></h1>
<h1>Address:<?php echo $c_address; ?></h1>
<h1 class="bolt">Area:<?php echo $c_area; ?></h1>
<h1 class="bolt">Collection:  <?php echo $c_price; ?> BDT</h1>

<hr><hr><hr>
<?php
if ($trId=="") {
  echo "<h1 class='bolt'>SPEEDY ALADDIN ID: SPEEDY786592". $parcel_id."</h1>";
}else {
  echo "<h1 class='bolt'>SPEEDY ALADDIN ID: ". $trId."</h1>";
}
 ?>
<h1>Merchant ID:<?php echo $c_Inv; ?></h1>
<!-- <img src="https://chart.googleapis.com/chart?chs=300x300&cht=qr&chl=<?php echo $trId; ?>&choe=UTF-8" title="Link to Google.com"  height="400" width="400"/> -->
<img src="http://www.splio3.fr/barcode/barcode.php?code=<?php echo $trId; ?>&type=code39"   width="600"/>

</div>
</div>
</div>
</div>
            <?php }

?>
<script type="text/javascript">
        window.print();
</script>

<?php
            }else {
            echo "You have no such parcel!";
            }
            ?>



<script src="js2/jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="js2/popper.min.js"></script>
<script type="text/javascript" src="js2/bootstrap.js"></script>
<script type="text/javascript" src="js2/mdb.min.js"></script>
<script src="js2/jquery.slimscroll.js"></script>
<script src="js2/sticky-kit.min.js"></script>
<script src="js2/custom.min-2.js"></script>
<script src="js2/datatables.min.js"></script>
<script src="js2/datatables-select.min.js"></script>
<script src="js2/custom.js"></script>
<script src="js2/axios.min.js"></script>
<script src="js\ionicons.js"></script>
<script src="js2/nmain.js"></script>
</body>
</html>
