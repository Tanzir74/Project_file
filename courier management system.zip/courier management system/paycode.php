<?php
  include 'config.php';
if (isset($_POST['submit'])) {
    $peoney = $_POST['peoney'];
    $merchant = $_POST['merchant'];
    $comments = $_POST['comments'];
    $oldbalench = $_POST['oldbalench'];
    $rec_file = $_FILES['upload_image'];

    // Auto ID Genaretor
    $all_keys = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y'
      ,'Z','1','2','3','4','5','6','7','8','9','0'
    );
    $rendomKey = "";
    for ($i=0; $i < 3; $i++) {
      shuffle($all_keys);
     $rendomKey .= $all_keys[0];
    }


    $image_name = $rec_file['name'];
    $image_tmp_name = $rec_file['tmp_name'];
    date_default_timezone_set("Asia/Dhaka");
    $name_changer = date("MdDhiy").$rendomKey.".xls";
    if (!empty($image_name)) {
      $loction = "excel/".$name_changer;
      move_uploaded_file($image_tmp_name, $loction);
    }else {
      ?>
      <div class="alert alert-warning m-4" role="alert">
          আপনি কোন ফাইল আপলোড দেন নি!
      </div>
      <?php
    }
    // Photo

    $statement_balance = $oldbalench - $peoney;

  $query7 = "UPDATE merchant SET PEONEY = PEONEY - $peoney WHERE merchant.id  = $merchant";
   $result7 = mysqli_query($connection,$query7) or die("Query Faield".mysqli_error($connection));


    // Auto ID Genaretor
      $all_keys = array('A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y'
        ,'Z','1','2','3','4','5','6','7','8','9','0');
      $rendomKey = "";
      for ($i=0; $i < 3; $i++) {
        shuffle($all_keys);
       $rendomKey .= $all_keys[0];
      }
      date_default_timezone_set("Asia/Dhaka");
       $month = date("M");
       $date = date("d");
     echo $trId=   strtoupper("PONEY$month$rendomKey");
      // Auto ID Genaretor


   // Auto ID Genaretor
   date_default_timezone_set("Asia/Dhaka");
   $Ptime = strtoupper(date("h:i:s a"));
   $Pdate = strtoupper(date("d M y"));
   // Auto ID Genaretor


   $query8 = "INSERT INTO `statement`
   (statement_trid, statement_date, statement_time, statement_merchant, statement_comment, statement_credit_amount, statement_balance, statement_file)
   VALUES
   ('$trId','$Pdate','$Ptime','$merchant','$comments','$peoney','$statement_balance','$loction')";
    $result8 = mysqli_query($connection,$query8) or die("Query Faield".mysqli_error($connection));



   if ($result8) {
     header("location: merchant.php");
   }
}
 ?>
