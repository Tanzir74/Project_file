<?php ob_start();?>
<?php $title = "Profile";?>
<?php include 'menu.php'; ?>
<style>
.avatars {
  vertical-align: middle;
  width: 100px;
  height: 100px;
  border-radius: 50%;
}
</style>

<?php  if (isset($_POST['submit'])) {
    include 'config.php';
    $id = mysqli_real_escape_string($connection,$_POST['id']);
    $name = mysqli_real_escape_string($connection,$_POST['name']);
    $business = mysqli_real_escape_string($connection,$_POST['business']);
    $email = mysqli_real_escape_string($connection,$_POST['email']);
    $number = mysqli_real_escape_string($connection,$_POST['number']);
    $address = mysqli_real_escape_string($connection,$_POST['address']);
    $bk_number = mysqli_real_escape_string($connection,$_POST['bk_number']);
    $bank_name = mysqli_real_escape_string($connection,$_POST['bank_name']);
    $b_ac_name = mysqli_real_escape_string($connection,$_POST['b_ac_name']);
    $branch_number = mysqli_real_escape_string($connection,$_POST['branch_number']);
    $b_ac_number = mysqli_real_escape_string($connection,$_POST['b_ac_number']);
    $password = mysqli_real_escape_string($connection,$_POST['password']);
    $payment_media = mysqli_real_escape_string($connection,$_POST['payment_media']);
    $m_category = mysqli_real_escape_string($connection,$_POST['m_category']);
    $m_ac_number = mysqli_real_escape_string($connection,$_POST['m_ac_number']);


    $query1 = "UPDATE `merchant` SET
    `name` = '$name',
    `business` = '$business',
    `email` = '$email',
    `number` = '$number',
    `password` = '$password',
    `bank_name` = '$bank_name',
    `b_ac_name` = '$b_ac_name',
    `branch_number` = '$branch_number',
    `b_ac_number` = '$b_ac_number',
    `payment_media` = '$payment_media',
    `m_category` = '$m_category',
    `m_ac_number` = '$m_ac_number',
    `bk_number` = '$bk_number',
    `address` = '$address' WHERE `merchant`.`id` = $id";

    $result1 = mysqli_query($connection,$query1) or die("ERROR".mysqli_error());
    if ($result1) {
      header("location: sajon.php");
      bo_enf_fluch();
    }
  }



?>


                <main>
                    <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                        <div class="container-fluid">
                            <div class="page-header-content">
                                <div class="row align-items-center justify-content-between pt-3">
                                    <div class="col-auto mb-3">
                                        <h1 class="page-header-title">
                                            <div class="page-header-icon"><i data-feather="user"></i></div>
                                            Account Settings - Profile
                                        </h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                    <!-- Main page content-->
                    <div class="container mt-4">
                        <!-- Account page navigation-->
                        <nav class="nav nav-borders">
                            <a class="nav-link active ml-0" href="profile.php?id=<?php echo $_SESSION['id']; ?>">Profile</a>
                            <a class="nav-link" href="peoney.php?id=<?php echo $_SESSION['id']; ?>">Payment</a>
                        </nav>
                        <hr class="mt-0 mb-4" />
                        <div class="row">
                            <div class="col-xl-4">
                              <?php
                              if ($_SESSION['role']== '5') {
                                $user_id = $_GET['id'];
                              }elseif ($_SESSION['role']== '1') {
                                $user_id = $_SESSION['id'];
                              }

                              include 'config.php';
                              $query = "SELECT * FROM merchant WHERE id = {$user_id}";
                              $result = mysqli_query($connection,$query) or die("Query Faield.");
                              $count = mysqli_num_rows($result);


                              if ($count>0) {
                              while ($row = mysqli_fetch_assoc($result)) {
                              ?>

                                <!-- Profile picture card-->
                                <div class="card ">
                                    <div class="card-header pr-5">Business photo</div>
                                    <div class="card-body text-center">
                                        <!-- Profile picture image-->
                                        <img class="avatars" src="<?php echo $row['p_photo']; ?>" alt="" />
                                        <!-- Profile picture help block-->
                                        <div class="small font-italic text-muted mb-4">Only JPG or PNG Maximum size 5 MB</div>
                                        <!-- Profile picture upload button-->
                                        <form class="" action="profileUp.php" method="post" enctype="multipart/form-data">
                                          <input type="hidden" name="ide" value="<?php echo $_SESSION['id']; ?>">
                                            <div class="custom-file mb-4">
                                              <input type="file" name="upload_image" class="custom-file-input" id="customFile" required>
                                            <label class="custom-file-label" for="customFile">Give the photo</label>
                                          </div>

                                          <input class="btn btn-primary" type="submit" name="submit" value="Upload new pictures">
                                        </form>
                                    </div>
                                </div>




<!-- Bank Collops Card -->
<form action="profile.php" method="POST" autocomplete="off">
  <div class="card mt-3">
      <div class="card-header pr-5">Payment info &nbsp;
      <a href="peoney.php?id=<?php echo $user_id; ?>" class="btn btn-primary btn-xs btn-icon ">
      <i class="fas fa-cogs"></i>
      </a></div>
      <div class="card-body text-center">

                                          <?php
                                          include 'config.php';
                                          $query1 = "SELECT * FROM payaccount WHERE payAccount_merchant = {$user_id} and payAccount_default = 1";
                                          $result1 = mysqli_query($connection,$query1) or die("Query Faield.");
                                          $count1 = mysqli_num_rows($result1);
                                          if ($count1>0) {
                                          while ($row1 = mysqli_fetch_assoc($result1)) {
                                            $PaymentGateway = $row1['payAccount_type'];

                                            switch ($PaymentGateway) {
                                              case "1":
                                            ?>
                                            <div class="d-flex align-items-center justify-content-between">
                                                <div class="d-flex align-items-center">
                                                <i class="fas fa-university fa-2x"></i>
                                                    <div class="ml-4">
                                                        <div class="small"><?php echo $row1['payAccount_owner']; ?> | <?php echo $row1['payAccount_number']; ?></div>
                                                        <div class="text-xs text-muted"><?php echo $row1['payAccount_branch']; ?> | <?php echo $row1['payAccount_name']; ?></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                                break;
                                              case "2":
                                            ?>
                                            <div class="d-flex align-items-center justify-content-between">
                                                <div class="d-flex align-items-center">
                                                    <img src="images/bkash.png" width="full" height="25">
                                                    <div class="ml-4">
                                                        <div class="small"><?php echo $row1['payAccount_number']; ?></div>
                                                        <div class="text-xs text-muted"><?php if ($row1['payAccount_typeof'] == "1") {
                                                          echo "bKash Parsonal";
                                                        }else {
                                                          echo "bKash Merchant";
                                                        } ?></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                                break;
                                              case "3":
                                            ?><div class="d-flex align-items-center justify-content-between">
                                                <div class="d-flex align-items-center">
                                                    <img src="https://download.logo.wine/logo/Nagad/Nagad-Logo.wine.png" width="full" height="25">
                                                    <div class="ml-4">
                                                        <div class="small"><?php echo $row1['payAccount_number']; ?></div>
                                                        <div class="text-xs text-muted"><?php if ($row1['payAccount_typeof'] == "1") {
                                                          echo "Nagad Parsonal";
                                                        }else {
                                                          echo "Nagad Merchant";
                                                        } ?></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                                break;
                                              case "4":
                                            ?><div class="d-flex align-items-center justify-content-between">
                                                <div class="d-flex align-items-center">
                                                    <img src="https://seeklogo.com/images/D/dutch-bangla-rocket-logo-B4D1CC458D-seeklogo.com.png" width="full" height="25">
                                                    <div class="ml-4">
                                                        <div class="small"><?php echo $row1['payAccount_number']; ?></div>
                                                        <div class="text-xs text-muted"><?php if ($row1['payAccount_typeof'] == "1") {
                                                          echo "Rocket Parsonal";
                                                        }else {
                                                          echo "Rocket Merchant";
                                                        } ?></div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                                break;
                                              case "5":
                                            ?><div class="d-flex align-items-center justify-content-between">
                                                <div class="d-flex align-items-center">
                                                  <img src="https://seeklogo.com/images/E/eastern-bank-limited-logo-3DD509DA8B-seeklogo.com.png" width="full" height="25">
                                                    <div class="ml-4">
                                                      <div class="small"><?php echo $row1['payAccount_owner']; ?> | <?php echo $row1['payAccount_number']; ?></div>
                                                      <div class="text-xs text-muted"><?php echo $row1['payAccount_branch']; ?> | EBL Card</div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                                break;
                                              default:
                                                echo "No Data!";
                                            }
                                          }}else {
                                            echo "The merchant did not add any payment gateway or default.";
                                          }
                                          ?>
      </div>
  </div>



                            </div>
                            <div class="col-xl-8">
                                <!-- Account details card-->
                                <div class="card mb-4">
                                    <div class="card-header">Account details  </div>
                                    <div class="card-body">


                                            <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                                            <!-- Form Group (username)-->
                                            <div class="form-group">
                                                <label  class="small mb-1" for="inputUsername">Username</label>
                                                <input disabled  class="form-control"  name="username" type="text" placeholder="Your username (not changeable)" value="<?php echo $row['username']; ?>" />
                                            </div>
                                            <!-- Form Row-->
                                            <div class="form-row">
                                                <!-- Form Group (name)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputFirstName">Full name</label>
                                                    <input name="name" class="form-control" id="inputFirstName" type="text" placeholder="Your full name" value="<?php echo $row['name']; ?>" />
                                                </div>
                                                <!-- Form Group (Moble)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputLastName">Mobile number</label>
                                                    <input name="bk_number" class="form-control" id="inputLastName" type="text" placeholder="Enter your mobile number" value="<?php echo $row['bk_number']; ?>" />
                                                </div>
                                            </div>
                                            <!-- Form Row        -->
                                            <div class="form-row">
                                                <!-- Form Group (organization name)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputOrgName">Business name</label>
                                                    <input name="business" class="form-control" id="inputOrgName" type="text" placeholder="Your business name" value="<?php echo $row['business']; ?>" />
                                                </div>
                                                <!-- Form Group (Number)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputLocation">Business Number (Main Number)</label>
                                                  <input class="form-control" id="inputPhone" type="tel" name="number" placeholder="Enter your business mobile number" value="<?php echo $row['number']; ?>"/>
                                                </div>
                                            </div>
                                            <!-- Form Group (email address)-->
                                            <div class="form-group">
                                                <label class="small mb-1" for="inputEmailAddress">Email address</label>
                                                <input name="email" class="form-control" id="inputEmailAddress" type="email" placeholder="Email address" value="<?php echo $row['email']; ?>" />
                                            </div>
                                            <!-- Form Group (email address)-->
                                            <div class="form-group">
                                                <label class="small mb-1" for="inputEmailAddress">Pickup address</label>
                                                <input name="address" class="form-control" id="inputLocation" type="text" placeholder="Your pickup address" value="<?php echo $row['address']; ?>" />
                                            </div>
                                            <!-- Form Group (email address)-->
                                            <div class="form-group">
                                                <label class="small mb-1" for="inputEmailAddress">Password</label>
                                                <input name="password" class="form-control" id="inputLocation" type="text" placeholder="Password" value="<?php echo $row['password']; ?>" />
                                            </div>
                                            <!-- Form Row-->
                                            <div class="form-row">
                                            <button type="submit" name="submit" class="btn btn-primary" type="button">Save change</button>
                                        </form>
                                      <?php }}else {
                                        echo "ERROR";
                                      }
                                                     ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>

<?php include 'footer.php';?>
