<?php


                     $result = mysqli_query($connection,$query) or die("Query Faield.");
                     $count = mysqli_num_rows($result);
                     ?>
                  <thead>
                     <tr>
                        <th>আইডি</th>
                        <th>প্রেরক</th>
                        <th>প্রাপক</th>
                        <th>নোট</th>
                        <th>স্টাটাস</th>
                        <th>অ্যাকশান</th>
                     </tr>
                  </thead>
                  <tfoot>
                     <tr>
                        <th>আইডি</th>
                        <th>প্রেরক</th>
                        <th>প্রাপক</th>
                        <th>নোট</th>
                        <th>স্টাটাস</th>
                        <th>অ্যাকশান</th>
                     </tr>
                  </tfoot>
                  <tbody>
                     <?php
                        if ($count>0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                          ?>
                     <tr>
                        <td class="th-sm">
                          <?php
                          if ($row['trId']=="") {
                            echo "<span class='text-green'>PEON786592". $row['parcel_id']."</span><br>";
                          }else {
                            echo "<span class='text-green'>". $row['trId']."</span><br>";
                          }
                           ?>
                           M.Inv:<?php echo $row['c_Inv']; ?><br>
                           <?php echo $row['Ptime']; ?> <br>
                           <?php echo $row['Pdate']; ?>
                        </td>
                        <td class="th-sm cb">
                           <?php echo $row['business']; ?> <br>
                           <?php echo $row['number']; ?>  <br>
                           <?php echo $row['address']; ?>
                           <div class="row ">
                              <div class="col-md-12">
                                 <div class="row">
                                    <div class="col-md-6">
                                       <span class="text-green font-weight-900"> ওজন: <?php echo $row['weight']; ?> কেজি</span>
                                    </div>
                                    <div class="col-md-6">
                                       <span class="text-green font-weight-900">
                                          চার্জ:  <?php

                                        echo $row['c_charge'];

                                           ?> &#2547;

                                        </span>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </td>
                        <td class="th-sm cb">
                           <?php echo $row['c_name'];?> <br>
                           <?php echo $row['c_number']; ?>,  <?php echo $row['c_b_number']; ?>  <br>
                           <?php echo $row['c_address']; ?>
                           <span class="text font-weight-900"> এরিয়া: <?php echo $row['area_name']; ?></span>
                           <div class="row ">
                              <div class="col-md-12">
                                 <span class="text-green font-weight-900"> ক্যাশ কালেকশান: <?php echo $row['c_price']; ?> &#2547;</span>
                              </div>
                           </div>
                        </td>
                        <td class="th-sm cbNote">
                        <?php echo $row['note'];?>
                        </td>
                        <td>
                           <?php
                              if ($row['c_action']==1) {
                                  echo "<div class='badge badge-danger badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==2){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==3){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==4){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==5){
                                  echo "<div class='badge badge-green badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==6){
                                  echo "<div class='badge badge-dark badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==7){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['action_name']."</div>";
                              }
                              else if($row['c_action']==8){
                                  echo "<div class='badge badge-dark badge-pill'>".$row['action_name']."</div>";
                              }
                              else {
                                echo "<div class='badge badge-warning badge-pill'>".$row['action_name']."</div>";
                              }
                              ?>
                           <br>
                           <?php
                              if ($row['c_service']==1) {
                                  echo "<div class='badge badge-orange badge-pill'>".$row['sName']."</div>";
                              }
                              else if($row['c_service']==2){
                                  echo "<div class='badge badge-primary badge-pill'>".$row['sName']."</div>";
                              }
                              else {
                                echo "<div class='badge badge-warning badge-pill'>".$row['sName']."</div>";
                              }
                              ?>
                        </td>
                        <td>


                           <a href="viewParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="fas fa-eye"></i></a>
                           <a class="btn btn-outline-primary btn-icon btn-sm" onclick="window.open('print_parcel.php?id=<?php echo $row['parcel_id']; ?>','POPUP WINDOW TITLE HERE','').print()"><i class="fas fa-print"></i></a>
                        </td>
                     </tr>
                     <?php } ?>
                  </tbody>
                  <?php } ?>
               </table>
            </div>
         </div>
      </div>
   </div>
</main>
