<?php
$title = "ফ্রড চেক";
 include 'menu.php';?>
<main>
   <!-- <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
      <div class="container">
         <div class="page-header-content pt-4">
            <div class="row align-items-center justify-content-between">
               <div class="col-auto mt-4">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i class="fab fa-searchengin"></i></div>
                     ফ্রড চেক
                  </h1>
                  <div class="page-header-subtitle">অর্ডার আইডি দিয়ে খুজন যেকোন পার্সেল</div>
               </div>
               <form class="" action="index.html" method="post">
                 <input class="form-control" type="text" name="" value="">
                 <input class="form-control" type="submit" name="" value="">
               </form>
            </div>
         </div>
      </div>
   </header> -->

   <header class="page-header page-header-dark bg-gradient-primary-to-secondary mb-4">
    <div class="container">
        <div class="page-header-content pt-4">
            <div class="row align-items-center justify-content-between">
                <div class="col-auto mt-4">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i class="fas fa-theater-masks"></i></div>
                      ফ্রড চেক
                    </h1>
                    <div class="page-header-subtitle">ক্রেতার নম্বর দিয়ে চেক করুন তার পূর্বের অনলাইন কেনাকাটা কেমন ছিল ? </div>
                </div>
            </div>
            <form class="form-inline mr-auto d-none d-md-block mr-3" action="" method="get">
            <div class="page-header-search mt-4">
                <div class="input-group input-group-joined">
                    <input class="form-control" type="text" name="serch" placeholder="01..." aria-label="Search" autofocus />
                    <div class="input-group-append">
                        <span class="input-group-text"><i data-feather="search"></i></span>
                    </div>
                </div>
            </div>
          </form>
        </div>
    </div>
</header>
   <!-- Main page content-->

                     <?php

                     if (isset($_GET['serch'])) {
                       $parcel_id = $_GET['serch'];
                        include 'config.php';
                        if ($_SESSION['role']== '5') {
                        $query = "SELECT * FROM parcel
                        LEFT JOIN action ON parcel.c_action = action.action_id
                        WHERE parcel.c_action = 5 or parcel.c_action = 9 and  (parcel.c_number LIKE '%$parcel_id%' or parcel.c_b_number LIKE '%$parcel_id%')";
                       }else {
                        ?>
                     <div class="container p-5">
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                           <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                           <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                           <span aria-hidden="true">&times;</span>
                           </button>
                        </div>
                        <div class="alert alert-success" role="alert">
                           <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                           <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                           <hr>
                           <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                        </div>
                     </div>
                     <?php
                        die;
                        }
                        $result = mysqli_query($connection,$query) or die("Query Faield.");
                        $count = mysqli_num_rows($result);

                        ?>
                        <div class="row">
                          <div class="col-md-6">
   <div class="container mt-10">
      <div class="card mb-4">
            <div class="">

                  <tbody>
                     <?php
                        if ($count>0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                          ?>
                     <tr>
                        <td class="th-sm">
                          <?php if ($row['action_id'] == "5") {
                            echo "<div class='badge badge-green badge-pill'><i class='fas fa-spinner'></i>&nbsp;&nbsp; সফল </div>";
                          }elseif ($row['action_id'] == "9"){
                            echo "<div class='badge badge-danger badge-pill'><i class='fas fa-spinner'></i>&nbsp;&nbsp; রিটার্ণ </div>";
                          } ?>
                        </td>
                     </tr>
                     <?php } ?>
                  </tbody>
                  <?php } ?>
            </div>
      </div>
   </div>

 </div>
</div>
       <?php } ?>
</main>
<?php include 'footer.php';?>
