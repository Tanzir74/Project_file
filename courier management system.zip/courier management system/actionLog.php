<?php $title = "অ্যাকশান লগ"; ?>
<?php include 'menu.php';?>

<main>
    <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
        <div class="container">
            <div class="page-header-content pt-4">
                <div class="row align-items-center justify-content-between">
                    <div class="col-auto mt-4">
                        <h1 class="page-header-title">
                            <div class="page-header-icon"><i class="fas fa-list-alt"></i></div>
                            অ্যাকশান লগ
                        </h1>
                        <div class="page-header-subtitle">সুশৃঙ্খল অর্ডার ম্যানেজমেন্ট</div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- Main page content-->
    <div class="container mt-n10">
        <div class="card mb-4">
            <div class="card-header">অ্যাকশান লগ
            </div>



            <div class="card-body">
                <div class="datatable">
                    <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">

<?php
include 'config.php';
$query = "SELECT * FROM action ORDER BY action_id ";
$result = mysqli_query($connection,$query) or die("Query Faield.");
$count = mysqli_num_rows($result);
if ($count>0) {

         ?>
<!-- New Table -->
<table class="table mb-0">
    <thead>
        <tr>
            <th scope="col"> নাম</th>
            <th scope="col">পার্সেলর সংখ্যা</th>
        </tr>
    </thead>
    <tbody>
      <?php
      while ($row = mysqli_fetch_assoc($result)) {
      ?>
        <tr>
            <td><?php echo $row['action_name']; ?></td>
            <td><span class="badge badge-light"><?php echo $row['action_parcel']; ?></span></td>
        </tr>
<?php } ?>
    </tbody>
      <?php } ?>
</table>
<!-- New Table -->
                </div>
            </div>
        </div>
    </div>
</main>
<?php include 'footer.php';?>
