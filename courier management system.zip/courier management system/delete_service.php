<?php ob_start(); ?>
<?php
$user_id = $_GET['id'];

include 'config.php';
$query = "DELETE FROM `services` WHERE id = {$user_id}";
$result = mysqli_query($connection,$query) or die("Query Faield.");
if ($result) {
  header("location: service.php");
    bo_enf_fluch();
}else{
echo   "<div class='alert alert-primary' role='alert'>
    Delete Fail!
</div>";
}

 ?>
