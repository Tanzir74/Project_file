<?php ob_start(); ?>
<?php include 'menu.php';?>
    <?php
       if (isset($_POST['submit'])) {
       include 'config.php';
     $query1 =   "UPDATE parcel SET
       c_action ='{$_POST["c_action"]}',
       weight ='{$_POST["weight"]}',
       c_charge ='{$_POST["c_charge"]}'
       WHERE parcel.parcel_id = {$_POST["pid"]};";

       if ($_POST["old_action"] != $_POST["c_action"]) {
         $query1 .= "UPDATE action  SET 	action_parcel= 	action_parcel - 1 WHERE action_id = {$_POST["old_action"]};";
         $query1 .= "UPDATE action  SET 	action_parcel= 	action_parcel + 1 WHERE action_id = {$_POST["c_action"]};";
         $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','{$_POST["c_action"]}','{$_SESSION["name"]}');";
       }

    $result1 = mysqli_multi_query($connection,$query1) or die("ডাটা সেন্টার কানেক্ট হয়নি !".mysqli_error());
    if ($result1) {


if ($_POST["c_action"] == 3) {

      $to = $_POST["c_number"];
      $token = "69a9e1162ef97e9cc0f314fe26475048";
      $message = "Hello  ".$_POST["c_name"]." ! We have received your parcel from ".$_POST["business"]." which payable amount ".$_POST["c_price"]." taka. We will deliver it very soon. Stay well.
-Peon Courier Ltd.";


      $url = "http://api.greenweb.com.bd/api.php?json";


      $data= array(
      'to'=>"$to",
      'message'=>"$message",
      'token'=>"$token"
      ); // Add parameters in key value
      $ch = curl_init(); // Initialize cURL
      curl_setopt($ch, CURLOPT_URL,$url);
      curl_setopt($ch, CURLOPT_ENCODING, '');
      curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      $smsresult = curl_exec($ch);

      }




      header('location: parcel.php');
      bo_enf_fluch();
        }
    }

       ?>
