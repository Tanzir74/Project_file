<?php
   session_start();
   if (!isset($_SESSION['username'])) {
     header("location: index.php");
   }
    ?>
<?php
   if (isset($_POST['submit'])) {
   include 'config.php';
   //Service Price
include 'charge.php';

 $query1 =   "UPDATE parcel SET
   c_Inv='{$_POST["c_Inv"]}',
   c_name='{$_POST["c_name"]}',
   c_number='{$_POST["c_number"]}',
   c_b_number='{$_POST["c_b_number"]}',
   c_address='{$_POST["c_address"]}',
   c_price='{$_POST["c_price"]}',
   c_charge='{$cost}',
   weight='{$_POST["weight"]}',
   c_service='{$_POST["c_service"]}',
   c_area='{$_POST["c_area"]}',
   note='{$_POST["note"]}'
   WHERE parcel.parcel_id = {$_POST["pid"]};";

   if ($_POST["c_InvOLD"] != $_POST["c_Inv"]) {
     $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
   }else if ($_POST["c_nameOLD"] != $_POST["c_name"]){
      $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
   }else if ($_POST["c_numberOLD"] != $_POST["c_number"]){
      $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
   }else if ($_POST["c_b_numberOLD"] != $_POST["c_b_number"]){
      $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
   }else if ($_POST["c_addressOLD"] != $_POST["c_address"]){
      $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
   }else if ($_POST["c_priceOLD"] != $_POST["c_price"]){
      $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
   }else if ($_POST["weightOLD"] != $_POST["weight"]){
      $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
   }else if ($_POST["c_serviceOLD"] != $_POST["c_service"]){
      $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
   }else if ($_POST["c_areaOLD"] != $_POST["c_area"]){
      $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
   }else if ($_POST["noteOLD"] != $_POST["note"]){
      $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
   }



$result1 = mysqli_multi_query($connection,$query1) or die("ডাটা সেন্টার কানেক্ট হয়নি !".mysqli_error());
if ($result1) {

    }
}

   ?>
