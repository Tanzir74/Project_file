<?php
$title = "ভার্সন 0.7 (বেটা)";
 include 'menu.php';?>
                <main>
                    <!-- Main page content-->
                    <div class="container mt-4">
                        <!-- Knowledge base home header option-->
                        <header class="card card-waves">
                            <div class="card-body px-5 pt-5 pb-0">
                                <div class="row align-items-center justify-content-between">
                                    <div class="col-lg-6">
                                        <h1 class="text-primary">নতুন কি এলো ?</h1>
                                        <p class="lead mb-4"> দেশ সেরা অত্যধুনিক সফটর তৈরীতে সার্বক্ষনিক কাজ করে যাচ্ছে পিয়নের নিজস্ব টিম সফটয়্যার !</p>
                                        <div class="shadow rounded">
                                            <div class="input-group input-group-joined input-group-joined-xl border-0">
                                              <textarea disabled class="form-control" name="name" rows="8" cols="80">লিখুন আপনার পরামর্শ ! (Coming on version 1.0 ..)</textarea>
                                            </div>
                                        </div>
                                        <input disabled class=" btn btn-primary btn-block mt-3" type="submit" name="" value="পাঠান">
                                    </div>
                                    <div class="col-lg-4"><img class="img-fluid" src="assets/img/illustrations/problem-solving.svg" /></div>
                                </div>
                                <span class="float-right">আপডেট তারিখঃ ৩১ জানুয়ারি ২০২১</span>

<?php  include 'VersionMenu.php'; ?>
                            </div>
                        </header>
                        <hr class="mt-4 mb-4" />
                        <!-- Knowledge base main category card 1-->
                        <div class="card card-icon lift lift-sm mb-4" >
                            <div class="row no-gutters">
                                <div class="col-auto card-icon-aside bg-primary"><i class="text-white-50 fab fa-sketch" ></i></div>
                                <div class="col">
                                    <div class="card-body py-5">
                                      <p class="card-text mb-1"><i class="fas fa-plus-circle"></i>&nbsp;&nbsp; অটোমেটিক অ্যাকাউন্ট সিস্টেম যুক্তকরণ</p>
                                      <p class="card-text mb-1"><i class="fas fa-plus-circle"></i>&nbsp;&nbsp; পার্সেলের সার্ভিস ও স্টাটাস ফিল্টার ফিচার যুক্তকরণ</p>
                                      <p class="card-text mb-1"><i class="fas fa-plus-circle"></i>&nbsp;&nbsp; ডেলিভারি অ্যাসাইনে রাইডারের নাম,নম্বর ও পরিশোধযোগ্য মূল্য সহ sms প্রেরণ (জানুয়ারি ১ তারিখ থেকে এটা বন্ধ ছিল)</p>
                                      <p class="card-text mb-1"><i class="fas fa-plus-circle"></i>&nbsp;&nbsp; উইজারনেম ও পাসওয়ার্ড রিকভারি ফিচার সংযুক্তি</p>
                                      <p class="card-text mb-1"><i class="fas fa-plus-circle"></i>&nbsp;&nbsp; ট্রাকিং ফিচার সংযুক্তি</p>
                                      <p class="card-text mb-1"><i class="fas fa-shield-alt"></i>&nbsp;&nbsp; সার্বিক সিকিউরিটি আরও উন্নত করণ</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                  </div>
                </main>

