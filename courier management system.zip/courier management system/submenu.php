<link href="css/coustome.css" rel="stylesheet" />
 <?php
    $link= $_SERVER['PHP_SELF'];

 switch ($link) {
   case "/v3/parcel.php":
     echo "<div class='col-12 col-xl-auto mb-3'>
     <a class='btn btn-sm btn-light text-primary m-1 active' href='parcel.php'>সবগুলো </a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllPending.php'>পেন্ডিং </a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllPick.php'>পিকআপ অ্যাসাইন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllRecived.php'>রিসিভ</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivaryAssign.php'>ডেলিভারী অ্যাসাইন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivared.php'>ডেলিভারী সম্পন্ন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllReschedule.php'>রি-শিডিউল</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='allBackPeon.php'>ব্যাক টু পিয়ন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='allReturnAssign.php'>রিটার্ণ অ্যাসাইন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllReturn.php'>রিটার্ণ</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='duePay.php'>পেমেন্ট ডিউ </a>
      <a class='btn btn-sm btn-light text-primary m-1' href='Paid.php'>পেইড</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllCancel.php'>ক্যানসেল</a>
     </div>";
     break;
   case "/v3/AllPending.php":
     echo "<div class='col-12 col-xl-auto mb-3'>
     <a class='btn btn-sm btn-light text-primary m-1' href='parcel.php'>সবগুলো </a>
      <a class='btn btn-sm btn-light text-primary m-1 active' href='AllPending.php'>পেন্ডিং </a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllPick.php'>পিকআপ অ্যাসাইন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllRecived.php'>রিসিভ</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivaryAssign.php'>ডেলিভারী অ্যাসাইন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivared.php'>ডেলিভারী সম্পন্ন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllReschedule.php'>রি-শিডিউল</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='allBackPeon.php'>ব্যাক টু পিয়ন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='allReturnAssign.php'>রিটার্ণ অ্যাসাইন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllReturn.php'>রিটার্ণ</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='duePay.php'>পেমেন্ট ডিউ </a>
      <a class='btn btn-sm btn-light text-primary m-1' href='Paid.php'>পেইড</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllCancel.php'>ক্যানসেল</a>
     </div>";
     break;
   case "/v3/AllPick.php":
     echo "<div class='col-12 col-xl-auto mb-3'>
     <a class='btn btn-sm btn-light text-primary m-1' href='parcel.php'>সবগুলো </a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllPending.php'>পেন্ডিং </a>
      <a class='btn btn-sm btn-light text-primary m-1 active' href='AllPick.php'>পিকআপ অ্যাসাইন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllRecived.php'>রিসিভ</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivaryAssign.php'>ডেলিভারী অ্যাসাইন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivared.php'>ডেলিভারী সম্পন্ন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllReschedule.php'>রি-শিডিউল</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='allBackPeon.php'>ব্যাক টু পিয়ন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='allReturnAssign.php'>রিটার্ণ অ্যাসাইন</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllReturn.php'>রিটার্ণ</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='duePay.php'>পেমেন্ট ডিউ </a>
      <a class='btn btn-sm btn-light text-primary m-1' href='Paid.php'>পেইড</a>
      <a class='btn btn-sm btn-light text-primary m-1' href='AllCancel.php'>ক্যানসেল</a>
     </div>";
     break;
     case "/v3/AllRecived.php":
       echo "<div class='col-12 col-xl-auto mb-3'>
       <a class='btn btn-sm btn-light text-primary m-1' href='parcel.php'>সবগুলো </a>
        <a class='btn btn-sm btn-light text-primary m-1' href='AllPending.php'>পেন্ডিং </a>
        <a class='btn btn-sm btn-light text-primary m-1' href='AllPick.php'>পিকআপ অ্যাসাইন</a>
        <a class='btn btn-sm btn-light text-primary m-1 active' href='AllRecived.php'>রিসিভ</a>
        <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivaryAssign.php'>ডেলিভারী অ্যাসাইন</a>
        <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivared.php'>ডেলিভারী সম্পন্ন</a>
        <a class='btn btn-sm btn-light text-primary m-1' href='AllReschedule.php'>রি-শিডিউল</a>
        <a class='btn btn-sm btn-light text-primary m-1' href='allBackPeon.php'>ব্যাক টু পিয়ন</a>
        <a class='btn btn-sm btn-light text-primary m-1' href='allReturnAssign.php'>রিটার্ণ অ্যাসাইন</a>
        <a class='btn btn-sm btn-light text-primary m-1' href='AllReturn.php'>রিটার্ণ</a>
        <a class='btn btn-sm btn-light text-primary m-1' href='duePay.php'>পেমেন্ট ডিউ </a>
        <a class='btn btn-sm btn-light text-primary m-1' href='Paid.php'>পেইড</a>
        <a class='btn btn-sm btn-light text-primary m-1' href='AllCancel.php'>ক্যানসেল</a>
       </div>";
       break;
       case "/v3/AllDelivaryAssign.php":
         echo "<div class='col-12 col-xl-auto mb-3'>
         <a class='btn btn-sm btn-light text-primary m-1' href='parcel.php'>সবগুলো </a>
          <a class='btn btn-sm btn-light text-primary m-1' href='AllPending.php'>পেন্ডিং </a>
          <a class='btn btn-sm btn-light text-primary m-1' href='AllPick.php'>পিকআপ অ্যাসাইন</a>
          <a class='btn btn-sm btn-light text-primary m-1' href='AllRecived.php'>রিসিভ</a>
          <a class='btn btn-sm btn-light text-primary m-1 active' href='AllDelivaryAssign.php'>ডেলিভারী অ্যাসাইন</a>
          <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivared.php'>ডেলিভারী সম্পন্ন</a>
          <a class='btn btn-sm btn-light text-primary m-1' href='AllReschedule.php'>রি-শিডিউল</a>
          <a class='btn btn-sm btn-light text-primary m-1' href='allBackPeon.php'>ব্যাক টু পিয়ন</a>
          <a class='btn btn-sm btn-light text-primary m-1' href='allReturnAssign.php'>রিটার্ণ অ্যাসাইন</a>
          <a class='btn btn-sm btn-light text-primary m-1' href='AllReturn.php'>রিটার্ণ</a>
          <a class='btn btn-sm btn-light text-primary m-1' href='duePay.php'>পেমেন্ট ডিউ </a>
          <a class='btn btn-sm btn-light text-primary m-1' href='Paid.php'>পেইড</a>
          <a class='btn btn-sm btn-light text-primary m-1' href='AllCancel.php'>ক্যানসেল</a>
         </div>";
         break;
         case "/v3/AllDelivared.php":
           echo "<div class='col-12 col-xl-auto mb-3'>
           <a class='btn btn-sm btn-light text-primary m-1' href='parcel.php'>সবগুলো </a>
            <a class='btn btn-sm btn-light text-primary m-1' href='AllPending.php'>পেন্ডিং </a>
            <a class='btn btn-sm btn-light text-primary m-1' href='AllPick.php'>পিকআপ অ্যাসাইন</a>
            <a class='btn btn-sm btn-light text-primary m-1' href='AllRecived.php'>রিসিভ</a>
            <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivaryAssign.php'>ডেলিভারী অ্যাসাইন</a>
            <a class='btn btn-sm btn-light text-primary m-1 active' href='AllDelivared.php'>ডেলিভারী সম্পন্ন</a>
            <a class='btn btn-sm btn-light text-primary m-1' href='AllReschedule.php'>রি-শিডিউল</a>
            <a class='btn btn-sm btn-light text-primary m-1' href='allBackPeon.php'>ব্যাক টু পিয়ন</a>
            <a class='btn btn-sm btn-light text-primary m-1' href='allReturnAssign.php'>রিটার্ণ অ্যাসাইন</a>
            <a class='btn btn-sm btn-light text-primary m-1' href='AllReturn.php'>রিটার্ণ</a>
            <a class='btn btn-sm btn-light text-primary m-1' href='duePay.php'>পেমেন্ট ডিউ </a>
            <a class='btn btn-sm btn-light text-primary m-1' href='Paid.php'>পেইড</a>
            <a class='btn btn-sm btn-light text-primary m-1' href='AllCancel.php'>ক্যানসেল</a>
           </div>";
           break;
           case "/v3/AllReschedule.php":
             echo "<div class='col-12 col-xl-auto mb-3'>
             <a class='btn btn-sm btn-light text-primary m-1' href='parcel.php'>সবগুলো </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllPending.php'>পেন্ডিং </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllPick.php'>পিকআপ অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllRecived.php'>রিসিভ</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivaryAssign.php'>ডেলিভারী অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivared.php'>ডেলিভারী সম্পন্ন</a>
              <a class='btn btn-sm btn-light text-primary m-1 active' href='AllReschedule.php'>রি-শিডিউল</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='allBackPeon.php'>ব্যাক টু পিয়ন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='allReturnAssign.php'>রিটার্ণ অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllReturn.php'>রিটার্ণ</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='duePay.php'>পেমেন্ট ডিউ </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='Paid.php'>পেইড</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllCancel.php'>ক্যানসেল</a>
             </div>";
             break;
           case "/v3/allBackPeon.php":
             echo "<div class='col-12 col-xl-auto mb-3'>
             <a class='btn btn-sm btn-light text-primary m-1' href='parcel.php'>সবগুলো </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllPending.php'>পেন্ডিং </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllPick.php'>পিকআপ অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllRecived.php'>রিসিভ</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivaryAssign.php'>ডেলিভারী অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivared.php'>ডেলিভারী সম্পন্ন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllReschedule.php'>রি-শিডিউল</a>
              <a class='btn btn-sm btn-light text-primary m-1 active' href='allBackPeon.php'>ব্যাক টু পিয়ন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='allReturnAssign.php'>রিটার্ণ অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllReturn.php'>রিটার্ণ</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='duePay.php'>পেমেন্ট ডিউ </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='Paid.php'>পেইড</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllCancel.php'>ক্যানসেল</a>
             </div>";
             break;
           case "/v3/allReturnAssign.php":
             echo "<div class='col-12 col-xl-auto mb-3'>
             <a class='btn btn-sm btn-light text-primary m-1' href='parcel.php'>সবগুলো </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllPending.php'>পেন্ডিং </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllPick.php'>পিকআপ অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllRecived.php'>রিসিভ</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivaryAssign.php'>ডেলিভারী অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivared.php'>ডেলিভারী সম্পন্ন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllReschedule.php'>রি-শিডিউল</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='allBackPeon.php'>ব্যাক টু পিয়ন</a>
              <a class='btn btn-sm btn-light text-primary m-1 active' href='allReturnAssign.php'>রিটার্ণ অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllReturn.php'>রিটার্ণ</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='duePay.php'>পেমেন্ট ডিউ </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='Paid.php'>পেইড</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllCancel.php'>ক্যানসেল</a>
             </div>";
             break;
           case "/v3/AllReturn.php":
             echo "<div class='col-12 col-xl-auto mb-3'>
             <a class='btn btn-sm btn-light text-primary m-1' href='parcel.php'>সবগুলো </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllPending.php'>পেন্ডিং </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllPick.php'>পিকআপ অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllRecived.php'>রিসিভ</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivaryAssign.php'>ডেলিভারী অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivared.php'>ডেলিভারী সম্পন্ন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllReschedule.php'>রি-শিডিউল</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='allBackPeon.php'>ব্যাক টু পিয়ন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='allReturnAssign.php'>রিটার্ণ অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1 active' href='AllReturn.php'>রিটার্ণ</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='duePay.php'>পেমেন্ট ডিউ </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='Paid.php'>পেইড</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllCancel.php'>ক্যানসেল</a>
             </div>";
             break;
           case "/v3/duePay.php":
             echo "<div class='col-12 col-xl-auto mb-3'>
             <a class='btn btn-sm btn-light text-primary m-1' href='parcel.php'>সবগুলো </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllPending.php'>পেন্ডিং </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllPick.php'>পিকআপ অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllRecived.php'>রিসিভ</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivaryAssign.php'>ডেলিভারী অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivared.php'>ডেলিভারী সম্পন্ন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllReschedule.php'>রি-শিডিউল</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='allBackPeon.php'>ব্যাক টু পিয়ন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='allReturnAssign.php'>রিটার্ণ অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllReturn.php'>রিটার্ণ</a>
              <a class='btn btn-sm btn-light text-primary m-1 active' href='duePay.php'>পেমেন্ট ডিউ </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='Paid.php'>পেইড</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllCancel.php'>ক্যানসেল</a>
             </div>";
             break;
           case "/v3/Paid.php":
             echo "<div class='col-12 col-xl-auto mb-3'>
              <a class='btn btn-sm btn-light text-primary m-1' href='parcel.php'>সবগুলো </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllPending.php'>পেন্ডিং </a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllPick.php'>পিকআপ অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllRecived.php'>রিসিভ</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivaryAssign.php'>ডেলিভারী অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivared.php'>ডেলিভারী সম্পন্ন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllReschedule.php'>রি-শিডিউল</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='allBackPeon.php'>ব্যাক টু পিয়ন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='allReturnAssign.php'>রিটার্ণ অ্যাসাইন</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllReturn.php'>রিটার্ণ</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='duePay.php'>পেমেন্ট ডিউ </a>
              <a class='btn btn-sm btn-light text-primary m-1 active' href='Paid.php'>পেইড</a>
              <a class='btn btn-sm btn-light text-primary m-1' href='AllCancel.php'>ক্যানসেল</a>
             </div>";
             break;
   default:
     echo "<div class='col-12 col-xl-auto mb-3'>
     <a class='btn btn-sm btn-light text-primary m-1' href='parcel.php'>সবগুলো </a>
     <a class='btn btn-sm btn-light text-primary m-1' href='AllPending.php'>পেন্ডিং </a>
     <a class='btn btn-sm btn-light text-primary m-1' href='AllPick.php'>পিকআপ অ্যাসাইন</a>
     <a class='btn btn-sm btn-light text-primary m-1' href='AllRecived.php'>রিসিভ</a>
     <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivaryAssign.php'>ডেলিভারী অ্যাসাইন</a>
     <a class='btn btn-sm btn-light text-primary m-1' href='AllDelivared.php'>ডেলিভারী সম্পন্ন</a>
     <a class='btn btn-sm btn-light text-primary m-1' href='AllReschedule.php'>রি-শিডিউল</a>
     <a class='btn btn-sm btn-light text-primary m-1' href='allBackPeon.php'>ব্যাক টু পিয়ন</a>
     <a class='btn btn-sm btn-light text-primary m-1' href='allReturnAssign.php'>রিটার্ণ অ্যাসাইন</a>
     <a class='btn btn-sm btn-light text-primary m-1' href='AllReturn.php'>রিটার্ণ</a>
     <a class='btn btn-sm btn-light text-primary m-1' href='duePay.php'>পেমেন্ট ডিউ </a>
     <a class='btn btn-sm btn-light text-primary m-1' href='Paid.php'>পেইড</a>
     <a class='btn btn-sm btn-light text-primary m-1 active' href='AllCancel.php'>ক্যানসেল</a>
     </div>";
 }
 ?>
