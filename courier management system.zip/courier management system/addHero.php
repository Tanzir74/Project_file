<?php ob_start(); ?>
<?php $title = "Adding new riders"; ?>
<?php include 'menu.php'; ?>
<?php
if (!$_SESSION['role']== '5') {
  header("location: index.php");
}
 ?>
<?php
if (isset($_POST['submit'])) {
  include 'config.php';
  $hero_name = mysqli_real_escape_string($connection,$_POST['hero_name']);
  $hero_username = mysqli_real_escape_string($connection,$_POST['hero_username']);
  $hero_mobile = mysqli_real_escape_string($connection,$_POST['hero_mobile']);
  $hero_b_number = mysqli_real_escape_string($connection,$_POST['hero_b_number']);
  $hero_DOB_day = mysqli_real_escape_string($connection,$_POST['hero_DOB_day']);
  $hero_DOB_month = mysqli_real_escape_string($connection,$_POST['hero_DOB_month']);
  $hero_DOB_year = mysqli_real_escape_string($connection,$_POST['hero_DOB_year']);
  $hero_father = mysqli_real_escape_string($connection,$_POST['hero_father']);
  $hero_mother = mysqli_real_escape_string($connection,$_POST['hero_mother']);
  $hero_addr = mysqli_real_escape_string($connection,$_POST['hero_addr']);


               $query ="SELECT hero_username FROM hero WHERE hero_username ='$hero_username'";
               $result = mysqli_query($connection,$query) or die("ERROR");

               $count = mysqli_num_rows($result);
               if($count > 0){
               echo "This username already exists.";
               }else{
               $query1 = "INSERT INTO hero (hero_name,hero_username,hero_mobile,hero_b_number,hero_DOB_day,hero_DOB_month,hero_DOB_year,hero_father,hero_mother,hero_addr)
               VALUE ('$hero_name','$hero_username','$hero_mobile','$hero_b_number','$hero_DOB_day','$hero_DOB_month','$hero_DOB_year','$hero_father','$hero_mother','$hero_addr')";
               $result1 = mysqli_query($connection,$query1) or die (mysqli_error());
               if($result1){
               header('location: hero.php');
                bo_enf_fluch();
               }}}?>












                <main>
                    <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
                        <div class="container-fluid">
                            <div class="page-header-content">
                                <div class="row align-items-center justify-content-between pt-3">
                                    <div class="col-auto mb-3">
                                        <h1 class="page-header-title">
                                            <div class="page-header-icon"><i class="fas fa-biking"></i></div>
                                            Account Settings - Rider
                                        </h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </header>
                    <!-- Main page content-->
                    <div class="container mt-4">
                        <hr class="mt-0 mb-6" />
                        <div class="row">
                            <div class="col-xl-6">
                                <!-- Profile picture card-->
                                <!-- <div class="card">
                                    <div class="card-header pr-5">হিরো ছবি </div>
                                    <div class="card-body text-center">
                                        <img class="img-account-profile rounded-circle mb-2" src="assets/img/illustrations/profiles/profile-1.png" alt="" />
                                        <div class="small font-italic text-muted mb-4">JPG অথবা PNG সর্বচ্চ সাইজ 5 MB</div>
                                        <button class="btn btn-primary" type="button">নতুন ছবি আপলোড</button>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-8"> -->
                                <!-- Account details card -->
                                <div class="card mb-4">
                                    <div class="card-header">Account details</div>
                                    <div class="card-body">

                                        <form action="addHero.php" method="POST" autocomplete="off">
                                            <input type="hidden" name="id" >
                                            <!-- Form Group (username)-->
                                            <div class="form-group">
                                                <label  class="small mb-1" for="hero_username">Username</label>
                                                <input  class="form-control" id="hero_username"  name="hero_username" type="text" placeholder="Username (not changeable)"  />
                                            </div>
                                            <!-- Form Row-->
                                            <div class="form-row">
                                                <!-- Form Group (name)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputFirstName">Full name</label>
                                                    <input name="hero_name" class="form-control" id="inputFirstName" type="text" placeholder="Full name"  />
                                                </div>
                                                <!-- Form Group (Moble)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="inputLastmd">Mobile number</label>
                                                    <input name="hero_mobile" class="form-control" id="inputLastmd" type="text" placeholder="Mobile number" />
                                                </div>
                                            </div>
                                            <!-- Form Row-->
                                            <div class="form-row">
                                                <!-- Form Group (name)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="hero_b_number">Alternate mobile number</label>
                                                    <input name="hero_b_number" class="form-control" id="hero_b_number" type="text" placeholder="Alternate mobile number"  />
                                                </div>
                                                <!-- Form Group (Moble)-->
                                                <div class="form-group col-md-2">
                                                    <label class="small mb-1" for="hero_DOB_day">Date of birth</label>
                                                        <input name="hero_DOB_day" class="form-control" id="hero_DOB" type="text" placeholder="Date of birth" />
                                                </div>
                                                <div class="form-group col-md-2">
                                                    <label class="small mb-1" for="hero_DOB_month">Month of birth</label>
                                                        <input name="hero_DOB_month" class="form-control" id="hero_DOB" type="text" placeholder="Month of birth" />
                                                </div>
                                                <div class="form-group col-md-2">
                                                    <label class="small mb-1" for="hero_DOB">Year of birth</label>
                                                        <input name="hero_DOB_year" class="form-control" id="hero_DOB" type="text" placeholder="Year of birth" />
                                                </div>
                                            </div>
                                            <!-- Form Row-->
                                            <div class="form-row">
                                                <!-- Form Group (name)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="hero_father">Father's name</label>
                                                    <input name="hero_father" class="form-control" id="hero_father" type="text" placeholder="Father's name"  />
                                                </div>
                                                <!-- Form Group (Moble)-->
                                                <div class="form-group col-md-6">
                                                    <label class="small mb-1" for="hero_mother">Mother's name</label>
                                                    <input name="hero_mother" class="form-control" id="hero_mother" type="text" placeholder="Mother's name" />
                                                </div>
                                            </div>
                                            <!-- Form Group (email address)-->
                                            <div class="form-group">
                                                <label class="small mb-1" for="hero_addr">Address</label>
                                                <input name="hero_addr" class="form-control" id="hero_addr" type="text" placeholder=" Address"  />
                                            </div>

                                            <!-- Form Row-->
                                            <div class="form-row">
                                                <a href="hero.php" class="btn btn-dark" type="button"><i class="fas fa-reply"></i> &nbsp;&nbsp;Return to rider list</a>
                                                &nbsp;&nbsp;&nbsp;
                                            <button type="submit" name="submit" class="btn btn-primary" type="button">Save</button>


                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>

<?php include 'footer.php';?>
