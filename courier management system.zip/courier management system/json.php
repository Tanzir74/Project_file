<?php
include 'config.php';
if (isset($_REQUEST['Paysubmit'])) {

  $foo=$_POST['foo'];
  foreach($foo as $row)
  {
    $data=json_decode($row);
    //echo "<pre>"; print_r($data); exit();
  // echo  $name=$data->c_name;
  // echo  $number=$data->c_address;
echo $check_data =$data->parcel_id.",";
 // echo  $all_marked = chunk_split($check_data,1,".");


  }

   }
 ?>
