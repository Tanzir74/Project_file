<?php ob_start(); ?>
<?php $title = "Adding new area"; ?>
<?php include 'menu.php'; ?>
<?php
   if (isset($_POST['submit'])) {
     include 'config.php';
     $area_name = mysqli_real_escape_string($connection,$_POST['area_name']);
     $price = mysqli_real_escape_string($connection,$_POST['price']);


      $query1 = "INSERT INTO area (area_name)
                 VALUE ('$area_name')";
      $result1 = mysqli_query($connection,$query1) or die("ERROR");
               if($result1){
               header('location: addArea.php');
               bo_enf_fluch();  }}




                  ?>
<main>
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
      <div class="container-fluid">
         <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
               <div class="col-auto mb-3">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i data-feather="user"></i></div>
                     Area | New Area
                  </h1>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- Main page content-->
   <div class="container mt-4">
   <hr class="mt-0 mb-4" />
   <div class="row">
      <div class="col-xl-4">
         <!-- Account details card-->
         <div class="card mb-4">
            <div class="card-header">New Area</div>
            <div class="card-body">
               <form action="addArea.php" method="POST" autocomplete="off">
                  <input type="hidden" name="id" >
                  <!-- Form Group (username)-->
                  <div class="form-group">
                     <label  class="small mb-1" for="inputUsername">Name</label>
                     <input  class="form-control"  name="area_name" type="text" placeholder="Area name"  />
                  </div>
                  <!-- Form Row-->

                     <!-- Form Group (name)-->

                        <!-- <label class="small mb-1" for="inputFirstName">টাকা</label> -->
                        <!-- <input name="price" class="form-control" id="inputFirstName" type="text" placeholder="এরিয়া ভিত্তিক মূল্য"  /> -->


                  <div class="form-row mt-3">
                     <a href="area.php" class="btn btn-dark" type="button"><i class="fas fa-reply">&nbsp;&nbsp;   </i>   &nbsp;&nbsp;  Return to area</a>
                     &nbsp;&nbsp;&nbsp;
                     <button type="submit" name="submit" class="btn btn-primary" type="button">Save</button>
               </form>
               </div>
            </div>
         </div>
      </div>
   </div>
</main>
<?php include 'footer.php';?>
