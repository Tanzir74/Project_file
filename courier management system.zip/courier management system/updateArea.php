<?php ob_start();
 include 'menu.php';
if ($_SESSION['role']== '1' or $_SESSION['role']== '0') {
  header("location: index.php");
  die;
}
 ?>
               <?php
                if (isset($_POST['submit'])) {
                include 'config.php';
                $id = mysqli_real_escape_string($connection,$_POST['id']);
                $area_name = mysqli_real_escape_string($connection,$_POST['area_name']);
                $price = mysqli_real_escape_string($connection,$_POST['price']);

                  $query1 = "UPDATE area SET
                  area_name = '$area_name',
                  price = '$price'
                  WHERE id = $id";

if (mysqli_query($connection,$query1 )) {
  header('location: area.php');
  bo_enf_fluch();
}else {
  echo "কিউরি ফেইল হয়েছ";
 }}?>
