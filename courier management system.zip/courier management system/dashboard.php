<?php $title = "Fast Trace Curiar"; ?>
<?php include 'menu.php';?>
<?php

// পেন্ডিং
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE action.action_id = 1
ORDER BY parcel.parcel_id DESC";
}elseif ($_SESSION['role']== '1') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 1
ORDER BY parcel.parcel_id DESC";
}else {
?>
<div class="container p-5">
   <div class="alert alert-warning alert-dismissible fade show" role="alert">
      <strong>Sorry!</strong>Your account has not yet been activated!
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
      </button>
   </div>
   <div class="alert alert-success" role="alert">
      <h4 class="alert-heading">Dear Merchant!</h4>
      <p>Welcome to SPEEDY ALADDIN! Your merchant account is still inactive. We review each merchant request by specific team. It may take a maximum of 1 working day to be reviewed. If you still don't approve, please knock on the live chat.</p>
      <hr>
      <p class="mb-0">Please <a class="btn btn-warning btn-sm text-dark" href="logout.php">Logout</a>  and try again.Or knock on the live chat to get updates.</p>
   </div>
</div>
<?php
   die;
   }
$result = mysqli_query($connection,$query) or die("Development work in progress. Please wait.");
$countp = mysqli_num_rows($result);
// পেন্ডিং //


// সব পার্সেল
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
ORDER BY parcel.parcel_id DESC";
}elseif ($_SESSION['role']== '1') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE parcel.c_m_business = {$_SESSION['id']}
ORDER BY parcel.parcel_id DESC";
}



$result = mysqli_query($connection,$query) or die("Development work in progress. Please wait.");
$countAll = mysqli_num_rows($result);
// সব পার্সেল

// সফল পার্সেল
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE action.action_id = 5
ORDER BY parcel.parcel_id DESC";
}elseif ($_SESSION['role']== '1') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 5
ORDER BY parcel.parcel_id DESC";
}
$result = mysqli_query($connection,$query) or die("Development work in progress. Please wait.");
$countSuc = mysqli_num_rows($result);
// সফল পার্সেল

// Part 2

// অ্যাসাইন টু ডেলিভার
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE  action.action_id = 4
ORDER BY parcel.parcel_id DESC";
}elseif ($_SESSION['role']== '1') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE parcel.c_m_business = {$_SESSION['id']} and  action.action_id = 4
ORDER BY parcel.parcel_id DESC";
}
$result = mysqli_query($connection,$query) or die("Development work in progress. Please wait.");
$countAtD = mysqli_num_rows($result);
// অ্যাসাইন টু ডেলিভার
// অ্যাসাইন টু পিকআপ
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE  action.action_id = 2
ORDER BY parcel.parcel_id DESC";
}elseif ($_SESSION['role']== '1') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE parcel.c_m_business = {$_SESSION['id']} and  action.action_id = 2
ORDER BY parcel.parcel_id DESC";
}
$resultassP = mysqli_query($connection,$query) or die("Development work in progress. Please wait.");
$countassP = mysqli_num_rows($resultassP);
// অ্যাসাইন টু পিকআপ

// Return
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE action.action_id = 9
ORDER BY parcel.parcel_id DESC";
}elseif ($_SESSION['role']== '1') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 9
ORDER BY parcel.parcel_id DESC";
}
$result = mysqli_query($connection,$query) or die("Development work in progress. Please wait.");
$countRe = mysqli_num_rows($result);
// Return


// Return assign
include 'config.php';
if ($_SESSION['role']== '5') {
$queryReASS = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE action.action_id = 8
ORDER BY parcel.parcel_id DESC";
}elseif ($_SESSION['role']== '1') {
$queryReASS = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 8
ORDER BY parcel.parcel_id DESC";
}
$resultReASS = mysqli_query($connection,$queryReASS) or die("Development work in progress. Please wait.");
$countReReASS = mysqli_num_rows($resultReASS);
// Return assign

// ResHIDULE
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE action.action_id = 6
ORDER BY parcel.parcel_id DESC";
}elseif ($_SESSION['role']== '1') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 6
ORDER BY parcel.parcel_id DESC";
}


$result = mysqli_query($connection,$query) or die("Development work in progress. Please wait.");
$countrES = mysqli_num_rows($result);
// Reshudle


// Back To peon
include 'config.php';
if ($_SESSION['role']== '5') {
$queryBack = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE action.action_id = 7
ORDER BY parcel.parcel_id DESC";
}elseif ($_SESSION['role']== '1') {
$queryBack = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 7
ORDER BY parcel.parcel_id DESC";
}


$resultBack = mysqli_query($connection,$queryBack) or die("Development work in progress. Please wait.");
$countrESBack = mysqli_num_rows($resultBack);
// Back To peon

// Invo
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE action.action_id = 3
ORDER BY parcel.parcel_id DESC";
}elseif ($_SESSION['role']== '1') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE parcel.c_m_business = {$_SESSION['id']} and action.action_id = 3
ORDER BY parcel.parcel_id DESC";
}
$result = mysqli_query($connection,$query) or die("Development work in progress. Please wait.");
$countRecive = mysqli_num_rows($result);
// Invo

// ক্যানসেল
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE action.action_id = 10
ORDER BY parcel.parcel_id DESC";
}elseif ($_SESSION['role']== '1') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE parcel.c_m_business = {$_SESSION['id']}  and action.action_id = 10
ORDER BY parcel.parcel_id DESC";
}
$resultC = mysqli_query($connection,$query) or die("Development work in progress. Please wait.");
$countC = mysqli_num_rows($resultC);
// ক্যানসেল



// টোটাল ডিও
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
LEFT JOIN pay ON parcel.p_Pay = pay.payID
WHERE pay.payID = 1 ";
}elseif ($_SESSION['role']== '1') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
LEFT JOIN pay ON parcel.p_Pay = pay.payID
WHERE parcel.c_m_business = {$_SESSION['id']} and pay.payID = 1";
}
$resultdue = mysqli_query($connection,$query) or die("Development work in progress. Please wait.");
$countdue = mysqli_num_rows($resultdue);
$sum3=0;
$totaldue=0;
$CODsumTotal=0;
while ($rowdue = mysqli_fetch_assoc($resultdue)){
// টোটাল চার্জ
    $sum3 += $rowdue['c_charge'];
// টোটাল COD
    $CODsumTotal += $rowdue['c_price'];
    $totaldue = $CODsumTotal-$sum3;
}
// টোটাল ডিও


// টোটাল ক্যাশ কালেকশান
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
LEFT JOIN pay ON parcel.p_Pay = pay.payID
WHERE action.action_id = 5 or action.action_id = 7";
}elseif ($_SESSION['role']== '1') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
LEFT JOIN pay ON parcel.p_Pay = pay.payID
WHERE parcel.c_m_business = {$_SESSION['id']} and (action.action_id = 5 or action.action_id = 7)";
}
$resultTC = mysqli_query($connection,$query) or die("Development work in progress. Please wait.");
$countTC = mysqli_num_rows($resultTC);
$sumTC=0;
while ($rowTC = mysqli_fetch_assoc($resultTC)){
    $sumTC += $rowTC['c_price'];
}
// টোটাল ক্যাশ কালেকশান

// টোটাল চার্জ
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE action.action_id = 5 or action.action_id = 7
ORDER BY parcel.parcel_id DESC";
}elseif ($_SESSION['role']== '1') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
WHERE parcel.c_m_business = {$_SESSION['id']} and (action.action_id = 5 or action.action_id = 7)
ORDER BY parcel.parcel_id DESC";
}
$resultc = mysqli_query($connection,$query) or die("Development work in progress. Please wait.");
$sumc=0;
while ($rowc = mysqli_fetch_assoc($resultc)){
    $valuec = $rowc['c_charge'];
    $sumc += $valuec;
}
// টোটাল চার্জ

// Total Paid
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
LEFT JOIN pay ON parcel.p_Pay = pay.payID
WHERE pay.payID = 2
ORDER BY parcel.parcel_id DESC";
}elseif ($_SESSION['role']== '1') {
$query = "SELECT * FROM parcel
LEFT JOIN services ON parcel.c_service = services.id
LEFT JOIN area ON parcel.c_area = area.id
LEFT JOIN merchant ON parcel.c_m_business = merchant.id
LEFT JOIN action ON parcel.c_action = action.action_id
LEFT JOIN hero ON parcel.c_hero = hero.hero_id
LEFT JOIN pay ON parcel.p_Pay = pay.payID
WHERE parcel.c_m_business = {$_SESSION['id']} and pay.payID = 2
ORDER BY parcel.parcel_id DESC";
}
$resultpd = mysqli_query($connection,$query) or die("Development work in progress. Please wait.");
$countpd = mysqli_num_rows($resultpd);
$sum=0;
$totalPaid=0;
$CODsum=0;
while ($rowpd = mysqli_fetch_assoc($resultpd)){
// টোটাল চার্জ
    $sum += $rowpd['c_charge'];
// টোটাল COD
    $CODsum += $rowpd['c_price'];

    $totalPaid =$CODsum-$sum;
}
// Total Paid

// জেনারেটেড পে অ্যামাউন্ট
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM invoice
LEFT JOIN merchant ON invoice.merchant = merchant.id
LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
WHERE  invoice.status_invoice = 1
ORDER BY invoice.id_invoice DESC";
}elseif ($_SESSION['role']== '1') {
  $query = "SELECT * FROM invoice
  LEFT JOIN merchant ON invoice.merchant = merchant.id
  LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
  WHERE invoice.merchant = {$_SESSION['id']} and invoice.status_invoice = 1
  ORDER BY invoice.id_invoice DESC";
}
$resultPay = mysqli_query($connection,$query) or die("Query Faield.");
$countPay = mysqli_num_rows($resultPay);
$sumPay=0;
while ($rowPay = mysqli_fetch_assoc($resultPay)){
// টোটাল চার্জ
    $sumPay += $rowPay['totalPrice'];
}
// জেনারেটেড পে অ্যামাউন্ট


// জেনারেটেড সেন্ড অ্যামাউন্ট
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM invoice
LEFT JOIN merchant ON invoice.merchant = merchant.id
LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
WHERE  invoice.status_invoice = 2
ORDER BY invoice.id_invoice DESC";
}elseif ($_SESSION['role']== '1') {
  $query = "SELECT * FROM invoice
  LEFT JOIN merchant ON invoice.merchant = merchant.id
  LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
  WHERE invoice.merchant = {$_SESSION['id']} and invoice.status_invoice = 2
  ORDER BY invoice.id_invoice DESC";
}
$resultSend = mysqli_query($connection,$query) or die("Query Faield.");
$countSend = mysqli_num_rows($resultSend);
$sumSend=0;
while ($rowSend = mysqli_fetch_assoc($resultSend)){
// টোটাল চার্জ
    $sumSend += $rowSend['totalPrice'];
}
// জেনারেটেড সেন্ড অ্যামাউন্ট


// সকল অ্যামাউন্ট
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM invoice
LEFT JOIN merchant ON invoice.merchant = merchant.id
LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
ORDER BY invoice.id_invoice DESC";
}elseif ($_SESSION['role']== '1') {
  $query = "SELECT * FROM invoice
  LEFT JOIN merchant ON invoice.merchant = merchant.id
  LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
  WHERE invoice.merchant = {$_SESSION['id']}
  ORDER BY invoice.id_invoice DESC";
}
$resultTotal = mysqli_query($connection,$query) or die("Query Faield.");
$countTotal = mysqli_num_rows($resultTotal);
$sumTotal=0;
while ($rowTotal = mysqli_fetch_assoc($resultTotal)){
// টোটাল চার্জ
    $sumTotal += $rowTotal['totalPrice'];
}
// সকল অ্যামাউন্ট

//সেপারেট অ্যামাউন্ট
include 'config.php';
if ($_SESSION['role']== '5') {
$query = "SELECT * FROM invoice
LEFT JOIN merchant ON invoice.merchant = merchant.id
LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
WHERE  invoice.status_invoice = 3
ORDER BY invoice.id_invoice DESC";
}elseif ($_SESSION['role']== '1') {
  $query = "SELECT * FROM invoice
  LEFT JOIN merchant ON invoice.merchant = merchant.id
  LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
  WHERE invoice.merchant = {$_SESSION['id']} and invoice.status_invoice = 3
  ORDER BY invoice.id_invoice DESC";
}
$resultSeparate = mysqli_query($connection,$query) or die("Query Faield.");
$countSeparate = mysqli_num_rows($resultSeparate);
$sumSeparate=0;
while ($rowSeparate = mysqli_fetch_assoc($resultSeparate)){
// টোটাল চার্জ
    $sumSeparate += $rowSeparate['totalPrice'];
}
// সেপারেটঅ্যামাউন্ট
?>



<main>
                   <main>
                       <header class="page-header page-header-compact page-header-primary border-bottom bg-primary mb-4">
                           <div class="container-fluid">
                               <div class="page-header-content">
                                   <div class="row align-items-center justify-content-between pt-3">
                                       <div class="col-auto mb-3">
                                           <h1 class="page-header-title text-light">
                                               <div class="page-header-icon"><i class="fas fa-tachometer-alt"></i></div>
                                               Dashboard
                                           </h1>
                                       </div>
                                       <div class="col-12 col-xl-auto mb-3">
                                         <ul class="nav nav-tabs card-header-tabs" id="cardTab" role="tablist">
                                             <li class="nav-item  text-light">
                                                 <a class="btn btn-sm btn-light text-primary m-2 active" id="overview-tab" href="#overview" data-toggle="tab" role="tab" aria-controls="overview" aria-selected="true">Parcel</a>
                                             </li>
                                             <li class="nav-item">
                                                 <!-- <a class="btn btn-sm btn-light text-primary m-2" id="example-tab" href="#example" data-toggle="tab" role="tab" aria-controls="example" aria-selected="false">অ্যাকাউন্টস</a> -->
                                             </li>
                                         </ul>
                                       </div>
                                   </div>
                               </div>
                           </div>
                       </header>

                   <!-- Main page content-->
                   <div class="container">
                             <div class="tab-content" id="cardTabContent">
                                 <div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="overview-tab">
                                   <!-- Example Colored Cards for Dashboard Demo-->
                                   <div class="row">


                                       <div class="col-xl-3 col-md-3 mb-4">
                                         <!-- Dashboard info widget 1-->
                                         <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-red  h-100">
                                             <div class="card-body">
                                                 <div class="d-flex align-items-center">
                                                     <div class="flex-grow-1">
                                                         <div class="small font-weight-bold text-black mb-1"> Add new order</div>
                                                         <div class="h5"><?php echo $countp; ?> parcels</div>
                                                     </div>
                                                     <div class="ml-2">
                                                       <i class="fas fa-hourglass-half fa-2x text-gray-200"></i>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>


                                       <div class="col-xl-3 col-md-3 mb-4">
                                         <!-- Dashboard info widget 1-->
                                         <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-red  h-100">
                                             <div class="card-body">
                                                 <div class="d-flex align-items-center">
                                                     <div class="flex-grow-1">
                                                         <div class="small font-weight-bold text-black mb-1"> In total</div>
                                                         <div class="h5"><?php echo $countAll; ?> parcels</div>
                                                     </div>
                                                     <div class="ml-2">
                                                       <i class="fas fa-boxes fa-2x text-gray-200"></i>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>


                                       <div class="col-xl-3 col-md-3 mb-4">
                                         <!-- Dashboard info widget 1-->
                                         <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-red  h-100">
                                             <div class="card-body">
                                                 <div class="d-flex align-items-center">
                                                     <div class="flex-grow-1">
                                                         <div class="small font-weight-bold text-black mb-1"> Successful delivery</div>
                                                         <div class="h5"><?php echo $countSuc; ?> parcels</div>
                                                     </div>
                                                     <div class="ml-2">
                                                       <i class="feather-xl fa-2x text-gray-200"></i>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>

                                       <div class="col-xl-3 col-md-3 mb-4">
                                         <!-- Dashboard info widget 1-->
                                         <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-red  h-100">
                                             <div class="card-body">
                                                 <div class="d-flex align-items-center">
                                                     <div class="flex-grow-1">
                                                         <div class="small font-weight-bold text-black mb-1"> Cash collection</div>
                                                         <div class="h5"><?php echo $sumTC; ?> ৳</div>
                                                     </div>
                                                     <div class="ml-2">
                                                       <i class="fa fa-hourglass fa-2x text-gray-200"></i>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     </div>

                                   </div>
                                   <!-- Line 2 -->

                  <!-- Assign -->
            <div class="row">
                <div class="col-xl-3 col-md-3 mb-4">
                    <!-- Dashboard info widget 2-->
                    <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-red h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <div class="small font-weight-bold text-black mb-1">Pickup Assign</div>
                                    <div class="h5"><?php echo $countassP; ?> parcels</div>
                                </div>
                                <div class="ml-2"><i class="fas fa-truck-pickup fa-2x text-gray-200"></i></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-3 mb-4">
                  <!-- Dashboard info widget 1-->
                  <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-red  h-100">
                      <div class="card-body">
                          <div class="d-flex align-items-center">
                              <div class="flex-grow-1">
                                  <div class="small font-weight-bold text-black mb-1"> Delivery Assignment</div>
                                  <div class="h5"><?php echo $countAtD; ?> parcels</div>
                              </div>
                              <div class="ml-2">
                                <i class="fas fa-shipping-fast fa-2x text-gray-200"></i>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>

              <div class="col-xl-3 col-md-3 mb-4">
                    <!-- Dashboard info widget 3-->
                    <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-red h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <div class="small font-weight-bold text-black mb-1">Re-schedule</div>
                                    <div class="h5"><?php echo $countrES; ?> parcels</div>
                                </div>
                                <div class="ml-2"><i class="fas fa-retweet fa-2x text-gray-200"></i></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-3 col-md-3 mb-4">
                    <!-- Dashboard info widget 4-->
                    <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-red h-100">
                        <div class="card-body">
                            <div class="d-flex align-items-center">
                                <div class="flex-grow-1">
                                    <div class="small font-weight-bold text-black mb-1">Return assignment</div>
                                    <div class="h5"><?php echo $countReReASS; ?> parcels</div>
                                </div>
                                <div class="ml-2"><i class="fas fa-dolly fa-2x text-gray-200"></i></div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <!-- Assign -->

<!-- Blude BOrd -->
            <div class="row">

              <div class="col-xl-3 col-md-3 mb-4">
                <!-- Dashboard info widget 1-->
                <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-red  h-100">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-grow-1">
                                <div class="small font-weight-bold text-black mb-1"> Receive</div>
                                <div class="h5"><?php echo $countRecive; ?> parcels</div>
                            </div>
                            <div class="ml-2">
                              <i class="fas fa-warehouse fa-2x text-gray-200"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-3 mb-4">
              <!-- Dashboard info widget 1-->
              <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-red  h-100">
                  <div class="card-body">
                      <div class="d-flex align-items-center">
                          <div class="flex-grow-1">
                              <div class="small font-weight-bold text-black mb-1"> Back to Peon</div>
                              <div class="h5"><?php echo $countRecive; ?> parcels</div>
                          </div>
                          <div class="ml-2">
                            <i class="fas fa-store fa-2x text-gray-200"></i>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
            <div class="col-xl-3 col-md-3 mb-4">
              <!-- Dashboard info widget 1-->
              <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-red  h-100">
                  <div class="card-body">
                      <div class="d-flex align-items-center">
                          <div class="flex-grow-1">
                              <div class="small font-weight-bold text-black mb-1"> Cancel</div>
                              <div class="h5"><?php echo $countC; ?> parcels</div>
                          </div>
                          <div class="ml-2">
                            <i class="far fa-hourglass fa-2x text-gray-200"></i>
                          </div>
                      </div>
                  </div>
              </div>
          </div>

            <div class="col-xl-3 col-md-3 mb-4">
              <!-- Dashboard info widget 1-->
              <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-red  h-100">
                  <div class="card-body">
                      <div class="d-flex align-items-center">
                          <div class="flex-grow-1">
                              <div class="small font-weight-bold text-black mb-1"> Return</div>
                              <div class="h5"><?php echo $countRe; ?> parcels</div>
                          </div>
                          <div class="ml-2">
                            <i class="fas fa-exchange-alt feather-xl text-gray-200"></i>
                          </div>
                      </div>
                  </div>
              </div>
          </div>



            </div>
            <!-- Blue BOrd -->

<!-- Part 2 -->
                                 </div>
                                 <div class="tab-pane fade" id="example" role="tabpanel" aria-labelledby="example-tab">



            <div class="row">
              <div class="col-xxl-3 col-lg-6">
                  <div class="card bg-primary text-white mb-4">
                      <div class="card-body">
                          <div class="d-flex justify-content-between align-items-center">
                              <div class="mr-3">
                                  <div class="text-white-75 small">পেমেন্ট ডিউ</div>
                                  <div class="text-lg font-weight-bold"><?php echo $totaldue; ?> টাকা </div>
                              </div>
                              <i class="far fa-hourglass feather-xl text-white-50"></i>
                          </div>
                      </div>
                      <!-- <div class="card-footer d-flex align-items-center justify-content-between">
                          <a class="small text-white stretched-link" href="duePay.php">ভিউ পার্সেল</a>
                          <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                      </div> -->
                  </div>
              </div>
              <div class="col-xxl-3 col-lg-6">
                  <div class="card bg-primary text-white mb-4">
                      <div class="card-body">
                          <div class="d-flex justify-content-between align-items-center">
                              <div class="mr-3">
                                  <div class="text-white-75 small">টোটাল পেইড</div>
                                  <div class="text-lg font-weight-bold"><?php echo $totalPaid; ?> টাকা </div>
                              </div>
                              <i class="fas fa-hourglass feather-xl text-white-50"></i>
                          </div>
                      </div>
                      <!-- <div class="card-footer d-flex align-items-center justify-content-between">
                          <a class="small text-white stretched-link" href="Paid.php">ভিউ পার্সেল</a>
                          <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                      </div> -->
                  </div>
              </div>
              <div class="col-xxl-3 col-lg-6">
                  <div class="card bg-primary text-white mb-4">
                      <div class="card-body">
                          <div class="d-flex justify-content-between align-items-center">
                              <div class="mr-3">
                                  <div class="text-white-75 small">টোটাল চার্জ</div>
                                  <div class="text-lg font-weight-bold"><?php echo $sumc; ?> টাকা </div>
                              </div>
                              <i class="fas fa-hand-holding-usd feather-xl text-white-50"></i>
                          </div>
                      </div>
                      <!-- <div class="card-footer d-flex align-items-center justify-content-between">
                          <a class="small text-white stretched-link" href="#">ভিউ পার্সেল</a>
                          <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                      </div> -->
                  </div>
              </div>
              <div class="col-xxl-3 col-lg-6">
                  <div class="card bg-primary text-white mb-4">
                      <div class="card-body">
                          <div class="d-flex justify-content-between align-items-center">
                              <div class="mr-3">
                                  <div class="text-white-75 small">ক্যাশ কালেকশান</div>
                                  <div class="text-lg font-weight-bold"><?php echo $sumTC; ?> টাকা </div>
                              </div>
                              <i class="fas fa-person-booth feather-xl text-white-50"></i>
                          </div>
                      </div>
                      <!-- <div class="card-footer d-flex align-items-center justify-content-between">
                          <a class="small text-white stretched-link" href="#">ভিউ পার্সেল</a>
                          <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                      </div> -->
                  </div>
              </div>
            </div>
            <!-- Line 2 -->
            <div class="row">
            <div class="col-xl-3 col-md-3 mb-4">
            <!-- Dashboard info widget 2-->
            <!-- <a class="card card-icon lift lift-sm mb-4"  href="invoiceGenerated.php"> -->
            <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-primary h-100">
            <div class="card-body">
            <div class="d-flex align-items-center">
            <div class="flex-grow-1">
             <div class="small font-weight-bold text-primary mb-1">জেনারেটেড স্টেটমেন্ট</div>
             <div class="h5"> <?php echo $countPay; ?> টি |  <?php echo $sumPay; ?> টাকা </div>
            </div>
            <div class="ml-2"><i class="fas fa-magic fa-2x text-gray-200"></i></div>
            </div>
            </div>
            </div>
            </a>
            </div>
            <div class="col-xl-3 col-md-3 mb-4">
            <!-- Dashboard info widget 1-->
            <!-- <a class="card card-icon lift lift-sm mb-4"  href="invoicePay.php"> -->
            <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-primary  h-100">
            <div class="card-body">
            <div class="d-flex align-items-center">
            <div class="flex-grow-1">
            <div class="small font-weight-bold text-primary mb-1">পেইড স্টেটমেন্ট</div>
            <div class="h5"> <?php echo $countSend; ?> টি |  <?php echo $sumSend; ?> টাকা </div>
            </div>
            <div class="ml-2">
            <i class="far fa-paper-plane fa-2x text-gray-200"></i>
            </div>
            </div>
            </div>
            </div>
            </a>
            </div>
            <div class="col-xl-3 col-md-3 mb-4">
            <!-- Dashboard info widget 3-->
            <!-- <a class="card card-icon lift lift-sm mb-4"  href="invoiceAll.php"> -->
            <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-primary h-100">
            <div class="card-body">
            <div class="d-flex align-items-center">
            <div class="flex-grow-1">
             <div class="small font-weight-bold text-primary mb-1">সকল স্টেটমেন্ট</div>
             <div class="h5"><?php echo $countTotal; ?> টি |  <?php echo $sumTotal; ?> টাকা </div>
            </div>
            <div class="ml-2"><i class="fas fa-boxes fa-2x text-gray-200"></i></div>
            </div>
            </div>
            </div>
            </a>
            </div>
            <div class="col-xl-3 col-md-3 mb-4">
            <!-- Dashboard info widget 4-->
            <!-- <a class="card card-icon lift lift-sm mb-4"  href="invoiceDone.php"> -->
            <div class="card border-top-0 border-bottom-0 border-right-0 border-left-lg border-primary h-100">
            <div class="card-body">
            <div class="d-flex align-items-center">
            <div class="flex-grow-1">
             <div class="small font-weight-bold text-primary mb-1">সেপারেট স্টেটমেন্ট</div>
             <div class="h5"><?php echo $countSeparate; ?> টি |  <?php echo $sumSeparate; ?> টাকা </div>
            </div>
            <div class="ml-2"><i class="fas fa-check-circle  fa-2x text-gray-200"></i></div>
            </div>
            </div>
            </div>
            </a>
            </div>
            </div>
                                 </div>
                             </div>



    </div>


               </main>
               <footer class="footer mt-auto footer-light">
                   <div class="container-fluid">
                       <div class="row">
                           <div class="col-md-6 small">Copyright &copy; TanzirTec 2020-<?php echo date("Y");?> | <a>Version 0.7(Beta)</a></div>
                           <div class="col-md-6 text-md-right small">
Developed by : <a href="https://www.facebook.com/tanzirahmed74266/">TanzirTec</a> 
                           </div>
                       </div>
                   </div>
               </footer>
<?php include 'footer.php';?>
