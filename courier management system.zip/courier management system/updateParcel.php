<?php ob_start();
$title = "আপডেট পার্সেল";
 include 'menu.php';
if ($_SESSION['role']== '1' or $_SESSION['role']== '0') {
  header("location: index.php");
  die;
}
 ?>
 <?php
    if (isset($_POST['submit'])) {
    include 'config.php';

    //Service Price
 include 'charge.php';
$c_Inv = mysqli_real_escape_string($connection,$_POST['c_Inv']);
$c_name = mysqli_real_escape_string($connection,$_POST['c_name']);
$c_number = mysqli_real_escape_string($connection,$_POST['c_number']);
$c_b_number = mysqli_real_escape_string($connection,$_POST['c_b_number']);
$c_address = mysqli_real_escape_string($connection,$_POST['c_address']);
$c_price = mysqli_real_escape_string($connection,$_POST['c_price']);
$weight = mysqli_real_escape_string($connection,$_POST['weight']);
$c_service = mysqli_real_escape_string($connection,$_POST['c_service']);
$c_area = mysqli_real_escape_string($connection,$_POST['c_area']);
$note = mysqli_real_escape_string($connection,$_POST['note']);
$pid = mysqli_real_escape_string($connection,$_POST['pid']);


  $query1 =   "UPDATE parcel SET
    `c_Inv`='{$c_Inv}',
    `c_name`='{$c_name}',
    `c_number`='{$c_number}',
    `c_b_number`='{$c_b_number}',
    `c_address`='{$c_address}',
    `c_price`='{$c_price}',
    `c_charge`='{$cost}',
    `weight`='{$weight}',
    `c_service`='{$c_service}',
    `c_area`='{$c_area}',
    `note`='{$note}'
    WHERE parcel.parcel_id = {$pid};";

    if ($_POST["c_InvOLD"] != $_POST["c_Inv"]) {
      $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
    }else if ($_POST["c_nameOLD"] != $_POST["c_name"]){
       $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
    }else if ($_POST["c_numberOLD"] != $_POST["c_number"]){
       $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
    }else if ($_POST["c_b_numberOLD"] != $_POST["c_b_number"]){
       $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
    }else if ($_POST["c_addressOLD"] != $_POST["c_address"]){
       $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
    }else if ($_POST["c_priceOLD"] != $_POST["c_price"]){
       $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
    }else if ($_POST["weightOLD"] != $_POST["weight"]){
       $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
    }else if ($_POST["c_serviceOLD"] != $_POST["c_service"]){
       $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
    }else if ($_POST["c_areaOLD"] != $_POST["c_area"]){
       $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
    }else if ($_POST["noteOLD"] != $_POST["note"]){
       $query1 .= "INSERT INTO tracking 	(traking_parcel_id,action_id_traking,user) VALUE ('{$_POST["pid"]}','Edit','{$_SESSION["name"]}');";
    }



 $result1 = mysqli_multi_query($connection,$query1) or die("ডাটা সেন্টার কানেক্ট হয়নি !".mysqli_error($connection));
 if ($result1) {

     }
 }

    ?>
 <?php $parcel_id =$_GET['id'];
 include 'config.php';

 $querye = "SELECT * FROM parcel
 LEFT JOIN services ON parcel.c_service = services.id
 LEFT JOIN area ON parcel.c_area = area.id
 LEFT JOIN merchant ON parcel.c_m_business = merchant.id
 WHERE parcel.parcel_id = {$parcel_id}";


 $resulte = mysqli_query($connection,$querye) or die("Query Faield.11");
 $counte = mysqli_num_rows($resulte);

 if ($counte>0) {

 while ($rowe = mysqli_fetch_assoc($resulte)) {

  ?>

 <main>
    <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
       <div class="container-fluid">
          <div class="page-header-content">
             <div class="row align-items-center justify-content-between pt-3">
                <div class="col-auto mb-3">
                   <h1 class="page-header-title">
                      <div class="page-header-icon"><i class="fas fa-pen-nib"></i></div>
                      পার্সেল এডিট | &nbsp;                           <?php
                                                if ($rowe['trId']=="") {
                                                  echo "<span class='text-green'>PEON786592". $rowe['parcel_id']."</span><br>";
                                                }else {
                                                  echo "<span class='text-green'>". $rowe['trId']."</span><br>";
                                                }
                                                 ?>
                   </h1>
                </div>
             </div>
          </div>
       </div>
    </header>
    <!-- Main page content-->
    <div class="container mt-4">
    <hr class="mt-0 mb-4" />
    <div class="row">
       <div class="col-xl-6">
          <!-- Account details card-->
          <div class="card card-waves">
             <div class="card-header">ক্রেতার তথ্য</div>
             <div class="card-body">
               <form class="" action="" method="POST" autocomplete="off">

                 <div class="form-row">
                    <!-- Form Group (name)-->
                     <div class="form-group col-md-4">
                      <input type="hidden" name="pid"class="form-control mb-3" value="<?php echo $rowe['parcel_id']; ?>" >
                       <label class="small mb-1" for="inputFirstNameinv">মার্চেন্ট ইনভয়েস নং</label>
                       <input name="c_Inv" class="form-control" id="inputFirstNameinv" type="text" placeholder="মারচেন্ট ইনভয়েস নং" value="<?php echo $rowe['c_Inv']; ?>"/>
                       <input type="hidden" name="c_InvOLD" class="form-control mb-3"  value="<?php echo $rowe['c_Inv']; ?>">
                    </div>
                    <!-- Form Group (Moble)-->
                    <div class="form-group col-md-8">
                       <label class="small mb-1" for="inputLastNamecname">ক্রেতার নাম</label>
                       <input required name="c_name" class="form-control" id="inputLastNamecname" type="text" placeholder="ক্রেতার সম্পূর্ণ নাম" value="<?php echo $rowe['c_name']; ?>"/>
                       <input type="hidden" name="c_nameOLD" class="form-control mb-3"  value="<?php echo $rowe['c_name']; ?>">
                    </div>
                 </div>
                   <!-- Content -->
                 <div class="form-row">
                    <!-- Form Group (name)-->
                    <div class="form-group col-md-6">
                       <label class="small mb-1" for="inputFirstNamenumber">মোবাইল নম্বর</label>
                       <input required name="c_number" class="form-control" id="inputFirstNamenumber" type="text" placeholder="ক্রেতার মোবাইল নম্বর" value="<?php echo $rowe['c_number']; ?>"/>
                       <input type="hidden" name="c_numberOLD" class="form-control mb-3"  value="<?php echo $rowe['c_number']; ?>">
                    </div>
                    <!-- Form Group (Moble)-->
                    <div class="form-group col-md-6">
                       <label class="small mb-1" for="inputLastNamebk_number">বিকল্প মোবাইল নম্বর</label>
                       <input name="c_b_number" class="form-control" id="inputLastNamebk_number" type="text" placeholder="ক্রেতার মোবাইল নম্বর" value="<?php echo $rowe['c_b_number']; ?>"/>
                       <input type="hidden" name="c_b_numberOLD" class="form-control mb-3"  value="<?php echo $rowe['c_b_number']; ?>">

                    </div>
                 </div>
                   <!-- Content -->
                 <div class="form-row">
                    <!-- Form Group (name)-->
                    <div class="form-group col-md-4">
                       <label class="small " for="inputFirstNames_price">ক্যাশ কালেকশন</label>
                       <input required name="c_price" class="form-control" id="inputFirstNames_price" type="text" placeholder="ক্যাশ কালেকশনে" value="<?php echo $rowe['c_price']; ?>"/>
                       <input type="hidden" name="c_priceOLD" class="form-control mb-3"  value="<?php echo $rowe['c_price']; ?>">

                   </div>
                    <!-- Form Group (Moble)-->
                    <div class="form-group col-md-8">
              <label for="exampleFormControlSelect1WT">ওজন(কেজি 1 থেকে 10 এর ভিতর)</label>
                <input required min="1" max="10" name="weight" class="form-control" id="inputFirstNames_price" type="number" placeholder="কেজি" value="<?php echo $rowe['weight']; ?>"/>
                <input type="hidden" name="weightOLD" class="form-control mb-3"  value="<?php echo $rowe['weight']; ?>">
                    </div>
                 </div>
                 <div class="form-group">
                   <label for="exampleFormControlTextareaADDR">সম্পূর্ণ ঠিকানা</label>
                   <textarea name="c_address" class="form-control" id="exampleFormControlTextareaADDR" rows="2"><?php echo $rowe['c_address']; ?> </textarea>
                   <input type="hidden" name="c_addressOLD" class="form-control mb-3"  value="<?php echo $rowe['c_address']; ?>">
                 </div>
                   <!-- Content -->
             </div>
           </div>
           <!-- Account details card-->
         </div>
       <div class="col-xl-6">
          <!-- Account details card-->
          <div class="card card-waves">
             <div class="card-header">সার্ভিস তথ্য</div>
             <div class="card-body">
               <div class="row">
                  <div class="col-xl-6">
               <label for="exampleFormControlSelectservices">সার্ভিস</label>
               <select required name="c_service" class="form-control " id="exampleFormControlSelectservices">
                 <option value="" disabled selected>একটি সার্ভিস সিলেক্ট করুন</option>
                 <?php
                                    include 'config.php';
                                    $query_s = "SELECT * FROM services";
                                    $result_s = mysqli_query($connection,$query_s)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                    if (mysqli_num_rows($result_s) > 0) {
                                      while ($row_S = mysqli_fetch_assoc($result_s)) {

                                        if ($rowe['c_service'] == $row_S['id']) {
                                          $selected = "selected";
                                        }else {
                                          $selected = "";
                                        }

                                        echo "<option {$selected} value='{$row_S['id']}'>{$row_S['sName']}</option>";
                                      }
                                    }
                                     ?>
                </select>
                <input type="hidden" name="c_serviceOLD" class="form-control mb-3"  value="<?php echo $rowe['c_service']; ?>">
              </div>
              <div class="col-xl-6">

              <label for="exampleFormControlSelectarea">এরিয়া</label>
              <select name="c_area" class="form-control " id="exampleFormControlSelectarea">
                <option value="" selected>একটি এরিয়া সিলেক্ট করুন</option>
                <?php
                                  include 'config.php';
                                  $query_a = "SELECT * FROM area";
                                  $result_a = mysqli_query($connection,$query_a)or die("সার্ভিস ডাটাবেজ সমস্যা !");

                                  if (mysqli_num_rows($result_a) > 0) {
                                    while ($row_a = mysqli_fetch_assoc($result_a)) {

                                      if ($rowe['c_area'] == $row_a['id']) {
                                        $selected = "selected";
                                      }else {
                                        $selected = "";
                                      }

                                      echo "<option {$selected} value='{$row_a['id']}'>{$row_a['area_name']}</option>";
                                    }
                                  }
                                   ?>
               </select>
               <input type="hidden" name="c_areaOLD" class="form-control mb-3"  value="<?php echo $rowe['c_area']; ?>">


            </div>
            </div>
            <label class="pt-3" for="exampleFormControlTextarenote">নোট</label>
           <input maxlength="40" name="note" class="form-control" id="exampleFormControlTextarenote" type="text" placeholder="যদি কোন নোট থাকে" value="<?php echo $rowe['note']; ?>"/>
           <input type="hidden" name="noteOLD" class="form-control mb-3"  value="<?php echo $rowe['note']; ?>">

            <div class="pt-5">

                    <a href="parcel.php" class="btn btn-dark" type="button"><i class="fas fa-reply"></i>&nbsp;&nbsp;পার্সেল-এ ফিরব</a>
               <input class="btn btn-primary m-3"  type="submit" name="submit" value="সেভ">
             </div>
               </form>
             <?php }

 }else {
 echo "Result Not Found !";
 }
 ?>
             </div>
           </div>
           <!-- Account details card-->

         </div>



       </div>
    </div>
 </main>

 <?php include 'footer.php';?>
