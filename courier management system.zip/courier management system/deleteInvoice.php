<?php ob_start(); ?>
<?php
if (!$_SESSION['role']== '5') {
  header("location: index.php");
}
 ?>
<?php
$parcel_id = $_GET['id'];
$ser_id = $_GET['sta'];
$action = $_GET['act'];

include 'config.php';
$query = "DELETE FROM invoice WHERE id_invoice = {$parcel_id};";
$query .= "UPDATE in_status  SET in_parcel	 = in_parcel	 - 1 WHERE 	in_id = '$action';";
$query .= "UPDATE merchant  SET invoice= invoice - 1 WHERE id = {$ser_id}";

if (mysqli_multi_query($connection,$query)) {
  header("location: invoice.php");
    bo_enf_fluch();

}else{
  echo "Delete Fail!";
}
 ?>
