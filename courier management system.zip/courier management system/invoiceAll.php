<?php ob_start();
$title = "সকল ইনভয়েস";
 include 'menu.php';
 ?>
<?php
   if (isset($_POST['submit'])) {
   include 'config.php';
 $query1 =   "UPDATE invoice SET
   status_invoice ='{$_POST["status_invoice"]}',
   totalPrice ='{$_POST["totalPrice"]}',
   comment ='{$_POST["commnet"]}'
   WHERE invoice.id_invoice = {$_POST["pid"]}";


$result1 = mysqli_query($connection,$query1) or die("ডাটা সেন্টার কানেক্ট হয়নি !".mysqli_error());
if ($result1) {
  if ($_POST["status_invoice"] == 2) {

    $to = $_POST["mobileno"];
    $token = "69a9e1162ef97e9cc0f314fe26475048";
    $message = "আসসালামু আলাইকুম ! সন্মানিত স্বজন, পিয়ন কুরিয়ার লিঃ থেকে আপনার একটি পেমেন্ট পাঠানো হয়েছে । বিস্তারিত- https://beta.peonbd.com/viewInvoice.php?id=".$_POST["pid"];


    $url = "http://api.greenweb.com.bd/api.php?json";


    $data= array(
    'to'=>"$to",
    'message'=>"$message",
    'token'=>"$token"
    ); // Add parameters in key value
    $ch = curl_init(); // Initialize cURL
    curl_setopt($ch, CURLOPT_URL,$url);
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $smsresult = curl_exec($ch);

  }
    }
}

   ?>

<main>
  <header class="page-header page-header-compact page-header-light border-bottom bg-white">
    <div class="container-fluid">
        <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
                <div class="col-auto mb-3">
                    <h1 class="page-header-title">
                        <div class="page-header-icon"><i class="fas fa-boxes"></i></div>
                        ইনভয়েস । সকল ম্যানেজমেন্ট
                    </h1>
                </div>
            </div>
        </div>
    </div>
</header>
   <header class="page-header page-header-dark  pb-5">
      <div class="container">
        <div class="page-header-content pt-4">
          <nav class="nav nav-borders">
            <a class="nav-link active" href="invoiceAll.php"> <i class="fas fa-boxes"></i> &nbsp;&nbsp;সবগুলো </a>
             <a class="nav-link" href="invoiceGenerated.php"><i class="fas fa-magic"></i> &nbsp;&nbsp;জেনারেটেড</a>
             <a class="nav-link" href="invoicePay.php"><i class="far fa-paper-plane"></i> &nbsp;&nbsp;পেমেন্ট সেন্ড</a>
         </nav>
          <hr class="mt-0 mb-3" />
      </div>
   </header>
   <!-- Main page content-->
   <div class="container mt-n10">
      <div class="card mb-4">

         <div class="card-header">সকল ইনভয়েস &nbsp;
              <?php if ($_SESSION['role'] =='5') {?>
            <a href="addInvoice.php" class="btn btn-outline-primary btn-icon btn-sm">
            <i class="fas fa-plus-circle"></i>
            </a>
          <?php } ?>
         </div>

         <div class="card-body">
            <div class="datatable">
               <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
                 <?php
                    include 'config.php';
                    if ($_SESSION['role']== '5') {
                    $query = "SELECT * FROM invoice
                    LEFT JOIN merchant ON invoice.merchant = merchant.id
                    LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
                    ORDER BY invoice.id_invoice DESC";
                    }elseif ($_SESSION['role']== '1') {
                      $query = "SELECT * FROM invoice
                      LEFT JOIN merchant ON invoice.merchant = merchant.id
                      LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
                      WHERE invoice.merchant = {$_SESSION['id']}
                      ORDER BY invoice.id_invoice DESC";
                    }else {
                 ?>
                  <div class="container p-5">
                     <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        <strong>দুঃখিত!</strong> আপনার অ্যাকাউন্টটি এখনও অ্যাক্টিভ হয় নি!
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                     </div>
                     <div class="alert alert-success" role="alert">
                        <h4 class="alert-heading">প্রিয় মার্চেন্ট !</h4>
                        <p>পিয়ন কুরিয়ারে স্বাগতম! আপনার মার্চেন্ট অ্যাকাউন্টটি এখনও পর্যন্ত ডিঅ্যাক্টিভ রয়েছে। আমরা প্রতিটি মার্চেন্ট অনুরোধ নির্দিষ্ট টিমের দ্বারা রিভিউ করি। এটি রিভিউ হতে সর্বোচ্চ ৩ কর্মদিবস সময় সময় লাগতে পারে।</p>
                        <hr>
                        <p class="mb-0">অনুগ্রহপূর্বক অপেক্ষা করুন। অথবা আপডেট জানতে লাইভ চ্যাটে নক দিন।</p>
                     </div>
                  </div>
                  <?php
                     die;
                     }
?>

<?php include 'INtABLE.PHP';?>
<?php include 'footer.php';?>
