<?php ob_start(); ?>
<?php
session_start();
if (isset($_SESSION['username'])) {
  header('location: dashboard.php');
  bo_enf_fluch();
}?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<script src="smartLogcustom.js"></script>
<link rel="stylesheet" href="smartLogcustom.css">

<!-- All the files that are required -->
<link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
<link href='https://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.13.1/jquery.validate.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<title>Login | SPEEDY ALADDIN</title>
<link rel="icon" type="image/x-icon" href="assets/img/favicon.png" />


<!-- Where all the magic happens -->
<!-- LOGIN FORM -->
<div class="text-center" style="padding:50px 0">
	<div class="logo">Login</div>
	<!-- Main Form -->
	<div class="login-form-1">
    <!-- Login Php -->
    <?php
            if (isset($_POST['login'])) {
            include "config.php";
            $username = mysqli_real_escape_string($connection,$_POST['username']);
            $password = mysqli_real_escape_string($connection,$_POST['password']);

            $query ="SELECT * FROM merchant WHERE username='{$username}' AND password='{$password}'";
            $result= mysqli_query($connection,$query) or die("There is a problem with the data center.");
            if (mysqli_num_rows($result) > 0) {

              while ($row = mysqli_fetch_assoc($result)) {

                session_start();

              $_SESSION['id'] =  $row['id'];
              $_SESSION['name'] =  $row['name'];
              $_SESSION['business'] =  $row['business'];
              $_SESSION['number'] =  $row['number'];
              $_SESSION['username'] =  $row['username'];
              $_SESSION['p_photo'] =  $row['p_photo'];
              $_SESSION['address'] =  $row['address'];
              $_SESSION['role'] =  $row['role'];
              $_SESSION['current_timestamp'] = time();
              header('location: dashboard.php');
                bo_enf_fluch();
              }


            }else {
              echo 'Username or password is incorrect.';
            }
            }

     ?>
    <!-- Login Php -->

		<form id="login-form" class="text-left" action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
			<div class="login-form-main-message"></div>
			<div class="main-login-form">
				<div class="login-group">
					<div class="form-group">
						<label for="lg_username" class="sr-only">Username</label>
						<input type="text" class="form-control" id="lg_username" name="username" placeholder="Username">
					</div>
					<div class="form-group">
						<label for="lg_password" class="sr-only">Password</label>
						<input type="password" class="form-control" id="lg_password" name="password" placeholder="Password">
					</div>
					<div class="form-group login-group-checkbox">
						<input type="checkbox" id="lg_remember" name="lg_remember">
						<label for="lg_remember">Save</label>
					</div>
				</div>
				<input type="submit" name="login" class="login-button" value="&#10097;">
			</div>
			<div class="etc-login-form">

				<p>New merchant? <a href="signUP.php">Create a new account</a></p>
        <p>Forgot password? <a href="reset.php">Recover</a></p>
        <p>Want parcel updates? <a href="tracking.php"> Truck</a></p>
        <div class="btn-group btn-sm" role="group" aria-label="Basic example">
          <a type="button" href="../index.php" class="btn btn-secondary  ">বাংলা</a>
          <a type="button" href="en/index.php" class="btn btn-secondary active">English</a>
        </div>

			</div>
		</form>
	</div>
	<!-- end:Main Form -->
</div>
<div class="footer fixed-bottom">
	<img src="footer.png" class="footer-img">
</div>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5e6e963aeec7650c33202caf/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
