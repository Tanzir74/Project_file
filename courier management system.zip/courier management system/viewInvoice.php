<?php
$title = "ইনভয়েস";
 include 'menu.php'; ?>
<?php $id_invoice =$_GET['id'];
include 'config.php';
 if ($_SESSION['role']== '5') {
$querye = "SELECT * FROM invoice
LEFT JOIN merchant ON invoice.merchant = merchant.id
LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
WHERE invoice.id_invoice = {$id_invoice}";
}elseif ($_SESSION['role']== '1') {
  $querye = "SELECT * FROM invoice
  LEFT JOIN merchant ON invoice.merchant = merchant.id
  LEFT JOIN in_status ON invoice.status_invoice = in_status.in_id
  WHERE invoice.id_invoice = {$id_invoice} and invoice.merchant = {$_SESSION['id']}";
}


$resulte = mysqli_query($connection,$querye) or die("Query Faield.11");
$counte = mysqli_num_rows($resulte);

if ($counte>0) {

while ($rowe = mysqli_fetch_assoc($resulte)) {


 ?>

<main>
   <header class="page-header page-header-compact page-header-light border-bottom bg-white mb-4">
      <div class="container-fluid">
         <div class="page-header-content">
            <div class="row align-items-center justify-content-between pt-3">
               <div class="col-auto mb-3">
                  <h1 class="page-header-title">
                     <div class="page-header-icon"><i class="fas fa-scroll"></i></div>
                     ইনভয়েস  | PONEY<?php echo $rowe['id_invoice']; ?>
                  </h1>
               </div>
            </div>
         </div>
      </div>
   </header>
   <!-- Main page content-->

   <div class="container mt-4">
     <div class="card card-header-actions mx-auto">
    <div class="card-header">
        PONEY<?php echo $rowe['id_invoice']; ?> <h3>
<?php
      if ($rowe['status_invoice'] == 1) {
        echo "<span class='badge badge-red'>".$rowe['in_name']."</span>";
      }else if($rowe['status_invoice'] == 2){
          echo "<span class='badge badge-success'>".$rowe['in_name']."</span>";
      }else {
        echo "<span class='badge badge-dark'>".$rowe['in_name']."</span>";
      }


 ?>


        </h3>
        <div>
<?php if (!$rowe['link']== "") { ?>
          <a href="<?php echo $rowe['link']; ?>" class="btn btn-primary btn-icon mr-2">
            <i class="fas fa-download"></i></a>
          <?php } ?>
          <a href="editInvoice.php?edit=<?php echo $rowe['id_invoice']; ?>" class="btn btn-primary btn-icon mr-2">
            <i class="fas fa-pen"></i></a>



        </div>
    </div>

<div class="row">
   <div class="col-xl-12">
      <!-- Account details card-->
      <div class="card card-waves">

         <div class="card-body">
           <div class="row">
              <div class="col-xl-4">
                <h6 class="text-success">পেমেন্ট তথ্যঃ</h6>
                টোটাল মূল্যঃ <span class="font-weight-900"> <?php echo $rowe['totalPrice']; ?></span><br>
                ট্রানজেকশন আইডিঃ <span class="font-weight-900"> <?php echo $rowe['Trxid']; ?></span><br>

              </div>
              <div class="col-xl-4">
                    <h6 class="text-success">অন্যান্য তথ্যঃ</h6>
                মার্চেন্টঃ <span class="font-weight-900"> <?php echo $rowe['business']; ?></span><br>
                কমেন্টঃ <span class="font-weight-900"> <?php echo $rowe['comment']; ?></span><br>
              </div>
  <div class="col-xl-4">


    <h6 class="text-success">ট্রাকিং আইডিঃ</h6>
    <?php echo $rowe['PEONID']; ?>
  </div>

         </div>

<hr>
<?php
if ($rowe['status_invoice'] == 1) {
  echo '<div class="step">
      <div class="step-item">
          <a class="step-item-link">জেনারেট</a>
      </div>
      <div class="step-item active">
          <a class="step-item-link">ডিউ</a>
      </div>
      <div class="step-item">
          <a class="step-item-link disabled" tabindex="-1" aria-disabled="true">পরিশোধ</a>
      </div>
  </div>';
}else if($rowe['status_invoice'] == 2){
    echo '<div class="step">
        <div class="step-item">
            <a class="step-item-link">জেনারেট</a>
        </div>
        <div class="step-item">
            <a class="step-item-link">ডিউ</a>
        </div>
        <div class="step-item active">
            <a class="step-item-link disabled" tabindex="-1" aria-disabled="true">পরিশোধ</a>
        </div>
    </div>';
}else {
  echo "<span class='badge badge-dark'>".$rowe['in_name']."</span>";
}

 ?>

         </div>
       </div>
       <!-- Account details card-->
     </div>
   </div>
</div>
</div>
<?php }} ?>
</main>
<?php include 'footer.php';?>
