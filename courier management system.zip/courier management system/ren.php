<?php if ($rowe['c_action']=='5') {?>
  <a title="আপডেট"  class="btn btn-dark btn-icon"><i class="fas fa-cogs"></i>
  </a>
<?php }else if($rowe['c_action']=='9'){ ?>
  <a title="আপডেট"  class="btn btn-dark btn-icon"><i class="fas fa-cogs"></i>
  </a>
<?php  } else { ?>
  <a title="এটি আর আপডেট করা যাবে না" data-toggle="modal" data-target="#exampleModalCenter<?php echo $rowe['parcel_id']; ?>"  class="btn btn-dark btn-icon"><i class="fas fa-cogs"></i>
  </a>
<?php } ?>
