<?php ob_start(); ?>
<?php
$notification_id = $_GET['id'];

include 'config.php';
$query = "DELETE FROM `notification` WHERE notification_id = {$notification_id}";
$result = mysqli_query($connection,$query) or die("Query Faield.");
if ($result) {
  header('location: addNotification.php');
  bo_enf_fluch();
}else{
echo   "<div class='alert alert-primary' role='alert'>
    Delete Fail!
</div>";
}

 ?>
