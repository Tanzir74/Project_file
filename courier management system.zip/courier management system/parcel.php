<?php ob_start();?>
 <?php  $title = "All parcels";?>
  <?php include 'menu.php';?>
    <script>
       window.onload=function(){
             document.getElementById('loder').style.display="none";
             document.getElementById('content').style.display="block";
       };
    </script>
    <style>
       #content {display: none;}
       #content img{width: 100%;}
       #loder{
       position: absolute;
       margin: auto;
       top: 0;
       right: 0;
       bottom: 0;
       left: 0;
       width: 300px;
       height: 300px;
       }
       #loder img{width: 300px;}
    </style>
    <div id="loder">
       <img src="https://1.bp.blogspot.com/-Ue7D8CxXeO4/WJA7tE90AAI/AAAAAAAAAG0/SBd-D7baPikWLd8MTvQdRH-ppbp6rpnGACPcB/s320/loader.gif">
    </div>
    <script type="text/javascript">
       $(document) .ready(function(){
         $("#form1 #select-all").click(function(){
           $("#form1 input[type='checkbox']").prop('checked',this.checked);
         });
       });
    </script>
    <style media="screen">
    #count-checked-checkboxes {
      color:blue;
    }
    </style>
    <head>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    </head>
    <?php
       include 'json.php';

        ?>
    <link href="css/coustome.css" rel="stylesheet" />
       <main id="content">
          <header class="page-header page-header-dark bg-gradient-primary-to-secondary pb-10">
             <div class="container">
                <div class="page-header-content pt-4">
                   <div class="row align-items-center justify-content-between">
                      <div class="col-auto mt-4">
    <form class="" action="" method="post">
    </div>
    <div class="col-md-12">
    <div class="row">
    <?php    if ($_SESSION['role']== '5') { ?>
    <div class="col-md-2">
    <select name="merchant" class="form-control js-example-responsive" >
    <option selected value="">Select Merchant                </option>
    <?php
       include 'config.php';
       $query_fil = "SELECT * FROM merchant";
       $result_fil = mysqli_query($connection,$query_fil)or die("ERROR");

       if (mysqli_num_rows($result_fil) > 0) {
         while ($row_fil = mysqli_fetch_assoc($result_fil)) {


           echo "<option value='{$row_fil['id']}'>{$row_fil['business']}</option>";
         }
       }
        ?>
    <option value='merchant.id'>All</option>
    </select>
    </div>
    <?php } ?>
    <div class="col-md-2">
    <select name="filtAction" class="form-control js-example-basic-single" >
    <?php
       include 'config.php';
       $query_fil = "SELECT * FROM action";
       $result_fil = mysqli_query($connection,$query_fil)or die("ERROR");

       if (mysqli_num_rows($result_fil) > 0) {
         while ($row_fil = mysqli_fetch_assoc($result_fil)) {

           echo "<option value='{$row_fil['action_id']}'>{$row_fil['action_name']}</option>";
         }
       }
        ?>
    <option value='action.action_id'>All</option>
    </select>
    </div>
    <div class="col-md-2">
    <select name="services" class="form-control  js-example-basic-single1" id="exampleFormControlSelect2">
    <option selected value="">Choose a service</option>
    <?php
       include 'config.php';
       $query_fil = "SELECT * FROM services";
       $result_fil = mysqli_query($connection,$query_fil)or die("ERROR");

       if (mysqli_num_rows($result_fil) > 0) {
         while ($row_fil = mysqli_fetch_assoc($result_fil)) {


           echo "<option value='{$row_fil['id']}'>{$row_fil['sName']}</option>";
         }
       }
        ?>
    <option value='services.id'>All</option>
    </select>
    </div>
    <div class="col-md-2">
    <button title="Filter"  class="btn btn-warning  btn-icon" type="submit" name="filters"><i class="fas fa-filter"></i></button>
    <button title="Reset" class="btn btn-black  btn-icon" href="parcel.php"><i class="far fa-times-circle"></i></button>
    </form>
    </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </header>

       <form id="form1" class="devel-generate-content-form" action="print.php" method="post">

    <?php
    $merchantF = "merchant.id";
    $actoionF = "action.action_id";
    $servicesF = "services.id";

       include 'config.php';
       if (isset($_POST['filters'])) {
         if ($_SESSION['role']== '5') {
         if ($_REQUEST['merchant'] == "") {
          $merchantF = "merchant.id";
        }else{
          $merchantF = $_REQUEST['merchant'];
        }
       }


         if ($_REQUEST['filtAction'] == "") {
          $actoionF = "action.action_id";
        }else{
          $actoionF = $_REQUEST['filtAction'];
        }

         if ($_REQUEST['services'] == "") {
          $servicesF = "services.id";
        }else{
          $servicesF = $_REQUEST['services'];
        }

       if ($_SESSION['role']== '5') {
       $query = "SELECT * FROM parcel
       LEFT JOIN services ON parcel.c_service = services.id
       LEFT JOIN area ON parcel.c_area = area.id
       LEFT JOIN merchant ON parcel.c_m_business = merchant.id
       LEFT JOIN action ON parcel.c_action = action.action_id
       LEFT JOIN hero ON parcel.c_hero = hero.hero_id
       LEFT JOIN pay ON parcel.p_Pay = pay.payID
       WHERE parcel.c_action = {$actoionF} and (parcel.c_m_business = {$merchantF} and parcel.c_service = {$servicesF})
       ORDER BY parcel.parcel_id  DESC LIMIT 500";
       }elseif ($_SESSION['role']== '1') {
       $query = "SELECT * FROM parcel
       LEFT JOIN services ON parcel.c_service = services.id
       LEFT JOIN area ON parcel.c_area = area.id
       LEFT JOIN merchant ON parcel.c_m_business = merchant.id
       LEFT JOIN action ON parcel.c_action = action.action_id
       LEFT JOIN hero ON parcel.c_hero = hero.hero_id
       WHERE parcel.c_m_business = {$_SESSION['id']} and (parcel.c_action = {$actoionF} and parcel.c_service = {$servicesF})
       ORDER BY parcel.parcel_id DESC LIMIT 500";
       }else {
       ?>
    <div class="container p-5">
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
    <strong>Sorry!</strong>Your account has not yet been activated!
    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
    </button>
    </div>
    <div class="alert alert-success" role="alert">
    <h4 class="alert-heading">Dear Merchant!</h4>
    <p>Welcome to SPEEDY ALADDIN Courier! Your merchant account is still inactive. We review each merchant request by a specific team. It may take a maximum of 3 working days from review.</p>
    <hr>
    <p class = "mb-0"> Please wait. Or knock on the live chat to get updates. </p>
    </div>
    </div>
    <?php
       die;
       }
?>
<!-- Main page content-->
<!-- <form id="form1" class="devel-generate-content-form" action="" method="post"> -->
<div class="container  mt-n10">
<div class="card mb-4">
<div class="card-header">
<!-- Multi Select -->
<div class="row">
<div class="col-xl-5">
<a title="Add new parcel" href="addParcel.php" class="btn btn-outline-primary btn-icon">
<i class="fas fa-plus-circle"></i>
</a>
<a title="Upload new bulk files" href="X2!dswsDsfb.php?action=<?php echo $actoionF; ?>&merchant=<?php echo $merchantF; ?>&service=<?php echo $servicesF; ?>" class="btn btn-red btn-icon">
<i class="fas fa-arrow-alt-circle-down"></i>
</a>
</div>

<?php




       }else {
       if ($_SESSION['role']== '5') {
       $query = "SELECT * FROM parcel
       LEFT JOIN services ON parcel.c_service = services.id
       LEFT JOIN area ON parcel.c_area = area.id
       LEFT JOIN merchant ON parcel.c_m_business = merchant.id
       LEFT JOIN action ON parcel.c_action = action.action_id
       LEFT JOIN hero ON parcel.c_hero = hero.hero_id
       LEFT JOIN pay ON parcel.p_Pay = pay.payID
       WHERE parcel.c_action = 1
       ORDER BY parcel.parcel_id  DESC LIMIT 500";
       }elseif ($_SESSION['role']== '1') {
       $query = "SELECT * FROM parcel
       LEFT JOIN services ON parcel.c_service = services.id
       LEFT JOIN area ON parcel.c_area = area.id
       LEFT JOIN merchant ON parcel.c_m_business = merchant.id
       LEFT JOIN action ON parcel.c_action = action.action_id
       LEFT JOIN hero ON parcel.c_hero = hero.hero_id
       WHERE parcel.c_m_business = {$_SESSION['id']}
       ORDER BY parcel.parcel_id DESC LIMIT 500";
       }else {
       ?>
       <div class="container p-5">
       <div class="alert alert-warning alert-dismissible fade show" role="alert">
       <strong>Sorry!</strong>Your account has not yet been activated!
       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
       <span aria-hidden="true">&times;</span>
       </button>
       </div>
       <div class="alert alert-success" role="alert">
       <h4 class="alert-heading">Dear Merchant!</h4>
       <p>Welcome to SPEEDY ALADDIN Courier! Your merchant account is still inactive. We review each merchant request by a specific team. It may take a maximum of 3 working days from review.</p>
       <hr>
       <p class = "mb-0"> Please wait. Or knock on the live chat to get updates. </p>
       </div>
       </div>
    <?php
       die;
       }
       ?>
       <!-- Main page content-->

       <div class="container  mt-n10">
       <div class="card mb-4">
       <div class="card-header">
       <!-- Multi Select -->
       <div class="row">
       <div class="col-xl-5">
       <a title="Add a new parcel" href="addParcel.php" class="btn btn-outline-primary btn-icon">
       <i class="fas fa-plus-circle"></i>
       </a>
       <a title="Download Excel file" href="X2!dswsDsfb.php?action=<?php echo $actoionF; ?>&merchant=<?php echo $merchantF; ?>&service=<?php echo $servicesF; ?>" class="btn btn-red btn-icon">
  <i class="fas fa-arrow-alt-circle-down"></i>
       </a>
       </div>
       <?php
       }
       ?>
    <?php
       $result = mysqli_query($connection,$query) or die("Query Faield.");
       $count = mysqli_num_rows($result);
       ?>
    <!-- Main page content-->

    <div class="col-xl-5">
    <div class="row">
    <div class="col-xl-6">
    <?php if ($_SESSION['role'] =='5') {?>
    <select name="c_actions" class="form-control" id="exampleFormControlSelect2">
    <option selected value="">Choose a status</option>
    <?php
       include 'config.php';
       $query_s = "SELECT * FROM action";
       $result_s = mysqli_query($connection,$query_s)or die("ERROR");

       if (mysqli_num_rows($result_s) > 0) {
         while ($row_S = mysqli_fetch_assoc($result_s)) {

           if ($row['c_action'] == $row_S['action_id']) {
             $selected = "selected";
           }else {
             $selected = "";
           }

           echo "<option {$selected} value='{$row_S['action_id']}'>{$row_S['action_name']}</option>";
         }
       }
        ?>
    </select>
    </div>
    <div class="col-xl-6">
    <select name="c_heros" class="form-control" id="exampleFormControlSelecth">
    <option selected value="">Choose a rider</option>
    <?php
       include 'config.php';
       $query_h = "SELECT * FROM hero";
       $result_h = mysqli_query($connection,$query_h)or die("ERROR");

       if (mysqli_num_rows($result_h) > 0) {
         while ($row_h = mysqli_fetch_assoc($result_h)) {

           if ($row['c_hero'] == "2") {
             $selected = "selected";
           }else {
             $selected = "";
           }

           echo "<option {$selected} value='{$row_h['hero_id']}'>{$row_h['hero_name']}</option>";
         }
       }
        ?>
    </select>
    </div>
    </div>
    </div>
    <div class="col-xl-2">
    <input required class="btn btn-primary" type="submit" name="subaction" value="Change">
    <input class="btn btn-warning" type="submit" name="print" value="Print">
    <?php } ?>
    </div>
    </div>
    <!-- Multi Select -->
    </div>
    <div class="card-body">
    <div class="datatable">
    <table class="table table-bordered table-hover" id="dataTable" width="100%" cellspacing="0">
    <thead>
    <tr>
    <?php if ($_SESSION['role'] =='5') {?>
    <th>
    <label class="checkbox path">
    <input type="checkbox" id="select-all"  value="<?php echo $row['parcel_id']; ?>">
    <svg viewBox="0 0 21 21">
    <path d="M5,10.75 L8.5,14.25 L19.4,2.3 C18.8333333,1.43333333 18.0333333,1 17,1 L4,1 C2.35,1 1,2.35 1,4 L1,17 C1,18.65 2.35,20 4,20 L17,20 C18.65,20 20,18.65 20,17 L20,7.99769186"></path>
    </svg>
    </label>
    </th>
    <?php } ?>
    <th>ID</th>
    <th>Sender</th>
    <th>Recipient </th>
    <th>Note</th>
    <th>Status</th>
    <th>Action</th>
    </tr>
    </thead>
    <tfoot>
    <tr>
    <?php if ($_SESSION['role'] =='5') {?>
    <th>
    <label class="checkbox path">
    <input type="checkbox" id="select-all"  value="<?php echo $row['parcel_id']; ?>">
    <svg viewBox="0 0 21 21">
    <path d="M5,10.75 L8.5,14.25 L19.4,2.3 C18.8333333,1.43333333 18.0333333,1 17,1 L4,1 C2.35,1 1,2.35 1,4 L1,17 C1,18.65 2.35,20 4,20 L17,20 C18.65,20 20,18.65 20,17 L20,7.99769186"></path>
    </svg>
    </label>
    </th>
    <?php } ?>
    <th>ID</th>
    <th>Sender</th>
    <th>Recipient</th>
    <th>Note</th>
    <th>Status</th>
    <th>Action</th>
    </tr>
    </tfoot>
    <tbody>
    <?php
       if ($count>0) {
       while ($row = mysqli_fetch_assoc($result)) {
         ?>
    <tr>
    <?php if ($_SESSION['role'] =='5') {?>
    <td class="th-sm">
    <label class="checkbox path">
    <input type="checkbox" name="foo[]" value="<?=htmlspecialchars(json_encode($row))?>">
    <svg viewBox="0 0 21 21">
    <path d="M5,10.75 L8.5,14.25 L19.4,2.3 C18.8333333,1.43333333 18.0333333,1 17,1 L4,1 C2.35,1 1,2.35 1,4 L1,17 C1,18.65 2.35,20 4,20 L17,20 C18.65,20 20,18.65 20,17 L20,7.99769186"></path>
    </svg>
    </label>
    </td>

    <?php } ?>
    <td class="th-sm">
    <?php
       if ($row['trId']=="") {
         echo "<span class='text-'>PEON786592". $row['parcel_id']."</span><br>";
       }else {
         echo "<span class='text-'>". $row['trId']."</span><br>";
       }
        ?>
    MI:<?php echo $row['c_Inv']; ?><br>
    <?php echo $row['Ptime']; ?> <br>
    <?php echo $row['Pdate']; ?>
    <?php if (!$row['lastAction']=="") {
        if ($row['c_action']=="5") {
        echo "<br><span class='text-'>Deliverd:". $row['lastAction']."</span><br>";
      }else if ($row['c_action']=="9") {
          echo "<br><span class='text-muted'>Returned:". $row['lastAction']."</span><br>";
      }?>
      <?php   } ?>
    </td>
    <td class="th-sm cb">
    <span class="font-weight-bolder"><?php echo $row['business']; ?></span><br>
    <?php echo $row['number']; ?>  <br>
    <?php echo $row['address']; ?>
    <div class="row ">
    <div class="col-md-12">
    <div class="row">
    <div class="col-md-6">
    <span class="text font-weight-900"> Weight: <?php echo $row['weight']; ?> Kg</span>
    </div>
    <div class="col-md-6">
    <span class="text font-weight-900">
    Charge:  <?php
       echo $row['c_charge'];

          ?> &#2547;
    </span>
    </div>
    </div>
    </div>
    </div>
    <div class="row ">
    <div class="col-md-12">
    <div class="row">
    <div class="col-md-6">
    <span class="text font-weight-900"> COD: <?php echo $row['c_price']; ?>&#2547;</span>
    </div>
    <div class="col-md-6">
    <span class="text font-weight-900">
    Payable:  <?php echo $payble =  $row['c_price'] - $row['c_charge']; ?> &#2547;
    </span>
    </div>
    </div>
    </div>
    </div>
    </td>
    <td class="th-sm cb">
    <?php echo $row['c_name'];?> <br>
    <?php echo $row['c_number']; ?>,  <?php echo $row['c_b_number']; ?>  <br>
    <?php echo $row['c_address']; ?>
    <div class="row ">
    <div class="col-md-12">
    <div class="row">
    <div class="col-md-12">
    <span class="text"> Area: <?php echo $row['area_name']; ?></span>
    </div>
    </div>
    </div>
    </div>
    </td>
    <td class="th-sm cbNote">
    <?php echo $row['note'];?>
    </td>
    <td>
    <?php
       if ($row['c_action']==1) {
           echo "<div class='badge badge-yellow badge-pill'><i class='fas fa-spinner'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
       }
       else if($row['c_action']==2){
           echo "<div class='badge badge-info badge-pill'><i class='fas fa-biking'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
       }
       else if($row['c_action']==3){
           echo "<div class='badge badge-secondary badge-pill'><i class='fas fa-warehouse'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
       }
       else if($row['c_action']==4){
           echo "<div class='badge badge-dark badge-pill'><i class='fas fa-shipping-fast'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
       }
       else if($row['c_action']==5){
           echo "<div class='badge badge-green badge-pill'><i class='fa fa-check-circle'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
       }
       else if($row['c_action']==6){
           echo "<div class='badge badge-dark badge-pill'><i class='fas fa-history'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
       }
       else if($row['c_action']==7){
           echo "<div class='badge badge-blue badge-pill'><i class='fas fa-exchange-alt'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
       }
       else if($row['c_action']==8){
           echo "<div class='badge badge-blue badge-pill'><i class='fas fa-file-import'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
       }
       else {
         echo "<div class='badge badge-red badge-pill'><i class='fas fa-window-close'></i>&nbsp;&nbsp;".$row['action_name']."</div>";
       }
       ?>
    <br>
    <?php
       if ($row['c_service']==1) {
           echo "<div class='badge badge-orange badge-pill'>".$row['sName']."</div>";
       }
       else if($row['c_service']==2){
           echo "<div class='badge badge-primary badge-pill'>".$row['sName']."</div>";
       }
       else {
         echo "<div class='badge badge-warning badge-pill'>".$row['sName']."</div>";
       }
       ?>
    <?php if ($_SESSION['role'] =='5') {?>
    <br>
    <div class="bg-light rounded mt-2"><?php echo $row['hero_name'];?></div>
    <?php } ?>
    </td>
    <td>
    <?php if ($row['c_action']=='5') {?>
    <a target="_blank" href="viewParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="fas fa-eye"></i></a>
    <?php if ($_SESSION['role'] =='5') {?>
    <a  class="btn btn-primary btn-icon btn-sm"><i class="far fa-edit"></i></a>
    <?php } ?>
    <a class="btn btn-outline-primary btn-icon btn-sm" target="_blank" href="print_parcel.php?id=<?php echo $row['parcel_id']; ?>"><i class="fas fa-print"></i></a>

  <?php }else if($row['c_action']=='9'){ ?>
    <a target="_blank" href="viewParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="fas fa-eye"></i></a>
      <?php if ($_SESSION['role'] =='5') {?>
      <a  class="btn btn-primary btn-icon btn-sm"><i class="far fa-edit"></i></a>
      <?php } ?>
      <a class="btn btn-outline-primary btn-icon btn-sm" target="_blank" href="print_parcel.php?id=<?php echo $row['parcel_id']; ?>"><i class="fas fa-print"></i></a>

      <?php  } else { ?>
    <a target="_blank" href="viewParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="fas fa-eye"></i></a>
    <?php if ($_SESSION['role'] =='5') {?>
    <a target="_blank" href="updateParcel.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="far fa-edit"></i></a>
    <?php } ?>
    <?php if ($_SESSION['role'] =='1' and $row['c_action']=='1') {?>
    <a target="_blank" href="updateParcelpending.php?id=<?php echo $row['parcel_id']; ?>" class="btn btn-outline-primary btn-icon btn-sm"><i class="far fa-edit"></i></a>
    <?php } ?>
    <a class="btn btn-outline-primary btn-icon btn-sm" target="_blank" href="print_parcel.php?id=<?php echo $row['parcel_id']; ?>"><i class="fas fa-print"></i></a>
    <?php if ($row['action_id']=='10') {?>
      <a title="Re-request" class="btn btn-red btn-icon btn-sm" href="re-request.php?id=<?php echo $row['parcel_id']; ?>"><i class="fas fa-arrow-circle-left"></i></a>
    <?php } ?>

    <?php } ?>


    </td>
    </tr>
    <?php } ?>
    </tbody>
    <?php } ?>
    </table>
    <?php if ($_SESSION['role'] =='5') {?>
        <div class="count-checkboxes-wrapper">
        <span id="count-checked-checkboxes">0</span> Has been selected


        </div>
      <?php } ?>
    </form>
    </div>
    </div>
    </div>
    </div>
    </main>
    <script type="text/javascript">
    $(document).ready(function(){

      var $checkboxes = $('.devel-generate-content-form td input[type="checkbox"]');

      $checkboxes.change(function(){
          var countCheckedCheckboxes = $checkboxes.filter(':checked').length;
          $('#count-checked-checkboxes').text(countCheckedCheckboxes);
      });

    });
    </script>

    <?php include 'footer.php';?>
