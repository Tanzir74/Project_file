-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 18, 2022 at 08:25 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Database: `curiar_management_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `Admin_id` int(255) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Number` int(11) NOT NULL DEFAULT 0,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Area`
--

CREATE TABLE `Area` (
  `Area_id` int(11) NOT NULL,
  `Area_name` varchar(30) NOT NULL DEFAULT 'N/A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Delivered_product`
--

CREATE TABLE `Delivered_product` (
  `Product_id` int(11) NOT NULL,
  `Cash_collection` int(11) NOT NULL DEFAULT 0,
  `product_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Delivery_asssign`
--

CREATE TABLE `Delivery_asssign` (
  `product_id` int(11) NOT NULL,
  `Rider_id` int(11) NOT NULL,
  `contact_number` int(11) NOT NULL,
  `Delivery_adress` varchar(80) NOT NULL DEFAULT '0',
  `Delivery_area` int(11) NOT NULL,
  `Cash_colletion` int(11) NOT NULL DEFAULT 0,
  `Product_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Merchant`
--

CREATE TABLE `Merchant` (
  `merchant_id` int(11) NOT NULL,
  `merchant_name` varchar(30) NOT NULL,
  `Merchant_phonenumber` int(11) NOT NULL,
  `Merchant_email` varchar(80) NOT NULL,
  `merchent_adress` varchar(100) NOT NULL DEFAULT 'N/A',
  `Area` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Merchant_payment`
--

CREATE TABLE `Merchant_payment` (
  `Merchant_id` int(11) NOT NULL,
  `Paymenter_id` int(11) DEFAULT NULL,
  `Payment_by` int(11) NOT NULL,
  `Total_payment` int(11) NOT NULL DEFAULT 0,
  `payment_Date` timestamp NOT NULL DEFAULT current_timestamp(),
  `payment_due` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Payment_method`
--

CREATE TABLE `Payment_method` (
  `Method_id` int(11) NOT NULL,
  `Method_name` varchar(30) NOT NULL DEFAULT 'N/A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Percel`
--

CREATE TABLE `Percel` (
  `Percel_id` int(11) NOT NULL,
  `Customar_name` varchar(40) NOT NULL DEFAULT 'N/A',
  `Customar_phone` int(11) NOT NULL DEFAULT 0,
  `Customar_adress` varchar(80) NOT NULL DEFAULT 'N/A',
  `Customar_area` int(11) NOT NULL,
  `Weight` int(11) NOT NULL DEFAULT 1,
  `Price` int(11) NOT NULL DEFAULT 0,
  `cash_collection` int(11) NOT NULL DEFAULT 0,
  `merchant_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pickup_assign`
--

CREATE TABLE `pickup_assign` (
  `Merchant_id` int(11) NOT NULL,
  `Merchant_phone` int(11) NOT NULL DEFAULT 0,
  `Rider_id` int(11) NOT NULL,
  `Rider_phone` int(11) NOT NULL DEFAULT 0,
  `pickup_adress` varchar(80) NOT NULL DEFAULT 'N/A',
  `pick_up_area` int(11) NOT NULL,
  `total_percel` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Product_status`
--

CREATE TABLE `Product_status` (
  `Status_id` int(11) NOT NULL,
  `status_name` varchar(30) NOT NULL DEFAULT 'N/A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `Rider`
--

CREATE TABLE `Rider` (
  `Rider_id` int(11) NOT NULL,
  `Rider_name` varchar(50) NOT NULL DEFAULT 'N/A',
  `Rider_contact` int(11) NOT NULL DEFAULT 0,
  `Rider_adress` varchar(80) NOT NULL,
  `Rider_area` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Admin_id`);

--
-- Indexes for table `Area`
--
ALTER TABLE `Area`
  ADD PRIMARY KEY (`Area_id`);

--
-- Indexes for table `Delivered_product`
--
ALTER TABLE `Delivered_product`
  ADD KEY `Product_id` (`Product_id`),
  ADD KEY `product_status` (`product_status`);

--
-- Indexes for table `Delivery_asssign`
--
ALTER TABLE `Delivery_asssign`
  ADD KEY `product_id` (`product_id`),
  ADD KEY `Rider_id` (`Rider_id`),
  ADD KEY `Delivery_area` (`Delivery_area`),
  ADD KEY `Product_status` (`Product_status`);

--
-- Indexes for table `Merchant`
--
ALTER TABLE `Merchant`
  ADD PRIMARY KEY (`merchant_id`);

--
-- Indexes for table `Merchant_payment`
--
ALTER TABLE `Merchant_payment`
  ADD KEY `Merchant_id` (`Merchant_id`),
  ADD KEY `Paymenter_id` (`Paymenter_id`),
  ADD KEY `Payment_by` (`Payment_by`);

--
-- Indexes for table `Payment_method`
--
ALTER TABLE `Payment_method`
  ADD PRIMARY KEY (`Method_id`);

--
-- Indexes for table `Percel`
--
ALTER TABLE `Percel`
  ADD PRIMARY KEY (`Percel_id`),
  ADD KEY `Customar_area` (`Customar_area`),
  ADD KEY `merchant_id` (`merchant_id`);

--
-- Indexes for table `pickup_assign`
--
ALTER TABLE `pickup_assign`
  ADD KEY `Merchant_id` (`Merchant_id`),
  ADD KEY `Rider_id` (`Rider_id`),
  ADD KEY `pick_up_area` (`pick_up_area`);

--
-- Indexes for table `Product_status`
--
ALTER TABLE `Product_status`
  ADD PRIMARY KEY (`Status_id`);

--
-- Indexes for table `Rider`
--
ALTER TABLE `Rider`
  ADD PRIMARY KEY (`Rider_id`),
  ADD KEY `Rider_area` (`Rider_area`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `Admin_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Area`
--
ALTER TABLE `Area`
  MODIFY `Area_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Merchant`
--
ALTER TABLE `Merchant`
  MODIFY `merchant_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Payment_method`
--
ALTER TABLE `Payment_method`
  MODIFY `Method_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Percel`
--
ALTER TABLE `Percel`
  MODIFY `Percel_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Product_status`
--
ALTER TABLE `Product_status`
  MODIFY `Status_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `Rider`
--
ALTER TABLE `Rider`
  MODIFY `Rider_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Delivered_product`
--
ALTER TABLE `Delivered_product`
  ADD CONSTRAINT `Delivered_product_ibfk_1` FOREIGN KEY (`Product_id`) REFERENCES `Delivery_asssign` (`product_id`),
  ADD CONSTRAINT `Delivered_product_ibfk_2` FOREIGN KEY (`product_status`) REFERENCES `Product_status` (`Status_id`);

--
-- Constraints for table `Delivery_asssign`
--
ALTER TABLE `Delivery_asssign`
  ADD CONSTRAINT `Delivery_asssign_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `Percel` (`Percel_id`),
  ADD CONSTRAINT `Delivery_asssign_ibfk_2` FOREIGN KEY (`Rider_id`) REFERENCES `Rider` (`Rider_id`),
  ADD CONSTRAINT `Delivery_asssign_ibfk_3` FOREIGN KEY (`Delivery_area`) REFERENCES `Product_status` (`Status_id`),
  ADD CONSTRAINT `Delivery_asssign_ibfk_4` FOREIGN KEY (`Delivery_area`) REFERENCES `Area` (`Area_id`),
  ADD CONSTRAINT `Delivery_asssign_ibfk_5` FOREIGN KEY (`Product_status`) REFERENCES `Product_status` (`Status_id`);

--
-- Constraints for table `Merchant_payment`
--
ALTER TABLE `Merchant_payment`
  ADD CONSTRAINT `Merchant_payment_ibfk_1` FOREIGN KEY (`Merchant_id`) REFERENCES `Merchant` (`merchant_id`),
  ADD CONSTRAINT `Merchant_payment_ibfk_2` FOREIGN KEY (`Paymenter_id`) REFERENCES `admin` (`Admin_id`),
  ADD CONSTRAINT `Merchant_payment_ibfk_3` FOREIGN KEY (`Payment_by`) REFERENCES `Payment_method` (`Method_id`);

--
-- Constraints for table `Percel`
--
ALTER TABLE `Percel`
  ADD CONSTRAINT `Percel_ibfk_1` FOREIGN KEY (`Customar_area`) REFERENCES `Area` (`Area_id`),
  ADD CONSTRAINT `Percel_ibfk_2` FOREIGN KEY (`merchant_id`) REFERENCES `Merchant` (`merchant_id`);

--
-- Constraints for table `pickup_assign`
--
ALTER TABLE `pickup_assign`
  ADD CONSTRAINT `pickup_assign_ibfk_1` FOREIGN KEY (`Merchant_id`) REFERENCES `Merchant` (`merchant_id`),
  ADD CONSTRAINT `pickup_assign_ibfk_2` FOREIGN KEY (`Rider_id`) REFERENCES `Rider` (`Rider_id`),
  ADD CONSTRAINT `pickup_assign_ibfk_3` FOREIGN KEY (`pick_up_area`) REFERENCES `Area` (`Area_id`);

--
-- Constraints for table `Rider`
--
ALTER TABLE `Rider`
  ADD CONSTRAINT `Rider_ibfk_1` FOREIGN KEY (`Rider_area`) REFERENCES `Area` (`Area_id`);
COMMIT;

