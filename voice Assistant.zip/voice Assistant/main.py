import pyttsx3
import datetime
import speech_recognition as sr
import wikipedia
import webbrowser
import os
import smtplib
import pyaudio
import winshell
import pyjokes
import json
import smtplib
import datetime 
import requests
from twilio.rest import Client
from bs4 import BeautifulSoup
import win32com.client as wincl
from urllib.request import urlopen
import random
import subprocess


# sapi5- voices api form windows 

engine = pyttsx3.init('sapi5')
voices = engine.getProperty('voices')
print(voices[0].id)
engine.setProperty('voice', voices[1].id)

def speak(audio):
    engine.say(audio)
    engine.runAndWait()

def wishMe():
    hour = int(datetime.datetime.now().hour)

    if hour>=12 and hour<18:
        speak("good after noon")
    
    elif hour>=0 and hour<12:
        speak("Good Morning")

    elif hour>=18 and hour<20:
        speak("Good Evening")
    else:
        speak("good Night")

def takeCommand():

    r = sr.Recognizer() 
    with sr.Microphone() as source:
        print("Listening...")
        r.pause_threshold = 1
        audio = r.listen(source)
    try:
        print("Recognizing...")    
        query = r.recognize_google(audio, language='en-us')
        print(f"User said: {query}\n")
    except Exception as e:
        # print(e)    
        print("Say that again please...")  
        return "None"
    return query

if __name__ =="__main__":
    wishMe()
    speak(" hey darling how are you . i think you ar well because i love you . so tell me how can i help you  ")
    while True:
        query= takeCommand().lower()

        if 'wikipedia' in query:
            speak('searching wikipedia')
            results=wikipedia.summary(query,sentences=2)
            speak("according to wikipidea")
            print(results)
            speak(results)
        elif 'open youtube' in query:
            webbrowser.open("youtube.com")
        elif 'open google' in query:
            webbrowser.open("google.com")


        elif 'open stack over flow' in query:
            webbrowser.open("stackoverflow.com")
        elif 'play music' in query:
            music_dir = 'D:\\Music playlist'
            songs = os.listdir(music_dir)    
            os.startfile(os.path.join(music_dir, songs[1]))

        elif 'the time' in query:
            strTime = datetime.datetime.now().strftime("%H:%M:%S")    
            speak(f"Sir, the time is {strTime}")
        elif 'how are you' in query:
            speak("I am fine, Thank you")
            speak("How are you, ")
        
        elif 'fine' in query or "good" in query:
            speak("It's good to know that your fine")

        elif 'open code' in query:
            codePath = "C:\\Users\\ASUS\\AppData\\Local\\Programs\\Microsoft VS Code\\Code.exe"
            os.startfile(codePath)  

        elif 'open zoom' in query:
            codePath = "C:\\Users\\ASUS\\AppData\\Roaming\\Zoom\\bin\\Zoom.exe"
            os.startfile(codePath)

        elif 'search' in query:
            query = query.replace("search", "")
            webbrowser.open(query)
        
        elif 'joke' in query:
            speak(pyjokes.get_joke())
        
        elif 'exit' in query or 'bye' in query:
            speak("Thanks for giving me your time")
            exit()
        
        elif 'restart system' in query:
                speak("Hold On a Sec ! Your system is on its way to shut down")
                subprocess.call('shutdown / p /f')

        
        elif "sleep" in query:
            speak("Setting in sleep mode")
            subprocess.call("shutdown / h")
        
        elif "a note" in query:
            speak("What should i write, sir")
            note = takeCommand()
            file = open('PA.txt', 'w')
            speak("Sir, Should i include date and time")
            snfm = takeCommand()
            if 'yes' in snfm or 'sure' in snfm:
                strTime = datetime.datetime.now().strftime("%H:%M:%S")
                file.write(strTime)
                file.write(" :- ")
                file.write(note)
            else:
                file.write(note)
        else:
            speak("Sorry, I am not able to understand you")