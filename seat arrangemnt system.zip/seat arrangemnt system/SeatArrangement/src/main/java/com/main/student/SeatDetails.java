package com.main.student;

public class SeatDetails {

}
