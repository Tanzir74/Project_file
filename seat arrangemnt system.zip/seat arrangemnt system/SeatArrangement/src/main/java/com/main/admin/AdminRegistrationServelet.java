package com.main.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AdminRegistrationServelet
 */
public class AdminRegistrationServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		if (username == null || username.equals("") || password == null || password.equals("")) {
			request.setAttribute("status", "failed");
			RequestDispatcher dispatcher1 = request.getRequestDispatcher("secret.jsp");
			dispatcher1.forward(request, response);
		}
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/seat", "root", "112233");
			PreparedStatement pst = con.prepareStatement("insert into admins(username, password) values(?,?)");
			pst.setString(1, username);
			pst.setString(2, password);
			int row = pst.executeUpdate();
			RequestDispatcher dispatcher = request.getRequestDispatcher("secret.jsp");
			if (row > 0) {
				request.setAttribute("status", "success");
			}else {
				request.setAttribute("status", "failed");
			}
			dispatcher.forward(request, response);
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}
