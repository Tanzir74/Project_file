package com.main.student;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddNewSeat
 */
public class AddNewSeat extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idn = request.getParameter("idn");
		String room = request.getParameter("room");
		String seat = request.getParameter("seat");
		String course = request.getParameter("course");
		String date = request.getParameter("date");
		RequestDispatcher dispatcher = request.getRequestDispatcher("dashboard.jsp");
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/seat", "root", "112233");
			PreparedStatement pst = con.prepareStatement("insert into seat(idn, room, seat, course, date) values(?,?,?,?,?)");
			pst.setString(1, idn);
			pst.setString(2, room);
			pst.setInt(3, Integer.valueOf(seat));
			pst.setString(4, course);
			pst.setDate(5, java.sql.Date.valueOf(date));
			
			int row = pst.executeUpdate();
			
			if (row > 0) {
				request.setAttribute("status2", "success");
			}else {
				request.setAttribute("status2", "failed");
			}
			dispatcher.forward(request, response);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
