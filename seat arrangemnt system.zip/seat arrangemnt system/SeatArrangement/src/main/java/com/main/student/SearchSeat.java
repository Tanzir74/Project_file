package com.main.student;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SearchSeat
 */
public class SearchSeat extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idn = request.getParameter("idn");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/seat", "root", "112233");
			PreparedStatement pst = con.prepareStatement("select * from seat where idn=? and date=CURRENT_DATE()");
			pst.setString(1, idn);
			ResultSet rs = pst.executeQuery();
			RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
			if (rs.next()) {
				request.setAttribute("found", "true");
				request.setAttribute("id", rs.getString("idn"));
				request.setAttribute("course", rs.getString("course"));
				request.setAttribute("room", rs.getString("room"));
				request.setAttribute("seat", rs.getString("seat"));
				request.setAttribute("date", rs.getString("date"));
			}else {
				request.setAttribute("status", "failed");
			}
			dispatcher.forward(request, response);
		}catch (Exception e) {
			RequestDispatcher dispatcher2 = request.getRequestDispatcher("index.jsp");
			request.setAttribute("status", "failed");
			dispatcher2.forward(request, response);
			e.printStackTrace();
		}

		
	}

}
